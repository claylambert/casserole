# EN-IR pointer

This file is not the standard. It is a signpost, so a reader who opens `en-ir/` does not mistake the directory for the baseline.

The baseline is [../aa-sdd/aa-sdd-enir-spec.md](../aa-sdd/aa-sdd-enir-spec.md), EN-IR/1.0, copied whole. Do not edit that file. A clarification typed into it is an amendment, whatever the commit message calls it. Every conforming instance has to share one text. A local edit forks that text.

The operator manual is [../aa-sdd/enir-suit-man.md](../aa-sdd/enir-suit-man.md). Read it to learn the format. If the manual and the baseline disagree, the baseline wins and the manual is repaired. The manual must not be cited as permission to edit the baseline.

Do not take `NOW.ACTION` from this file. Do not start the project from this file. A copy that still says this pointer is the whole law is a snapshot of an older reading. The baseline wins. Startup may open the baseline and the manual. It must not treat either of them, or this pointer, as the status panel.
