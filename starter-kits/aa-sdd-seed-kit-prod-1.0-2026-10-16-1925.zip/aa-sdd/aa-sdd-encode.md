# AA-SDD encode

**Token:** `[ENCODE]`
**Baseline:** [aa-sdd-enir-spec.md](aa-sdd-enir-spec.md)
**Manual:** [enir-suit-man.md](enir-suit-man.md)

This file selects which of the two interchange jobs a turn is doing. It does not restate the standard. The standard is the baseline, including its frame and sections 4 and 5. Read the operator manual for that standard when you need the format. Obey the baseline when the manual and the baseline disagree.

EN-IR is the data protocol unless the owner names another encoding for that turn. Another encoding is a boundary format the owner named in the sentence, such as JSON at an integration edge. It does not become the project protocol. The project protocol stays EN-IR on the next turn unless the owner names the other encoding again.

The two paths must not be written as each other.

**Requirement file.** Serial Markdown. A human reads it as the specification, and it carries one of the version classes in the operator manual. When the owner asks to encode a specification from raw prose, the session that performs the encode compiles the headings. The owner's prose stays quoted, so a later reader can see the source sentence and the heading that was compiled from it. One family per file: project, code, or video. Mixing families in one file makes the version class ambiguous, because a video serial and a code serial do not freeze on the same day for the same reason. The encode is not approval. Approval is the owner's sentence, or a decision token spoken in the same sentence as this file.

**Data packet.** Transfer or persistence. Every structure and every value survives. Pack only as far as a later session can still rebuild the packet in full. A packing that drops a field, renames a key the owner did not rename, or flattens a nested value into a sentence, has failed, even when the result is shorter. Intent is embedded only when the owner requests it on that turn. Omitting intent is the default, not an error. A packet that always carries intent will be read as if the owner had asked for the intent, and the next session will treat a transport note as a requirement.

The requirement text, the role names, and the headings are the interchange. A text a human cannot read has failed. The failure is practical. The next fresh session has to execute from the file. If the file is only readable by a parser you did not ship, the session does not have the requirement.

Not JSON. Not XML. Not embeddings as the record. Not a second catalog of the same keys. Those forms may appear at a boundary the owner named. They are not the source of truth inside this tree. A search index of the same keys, or a ticket mirror of the same rows, is the second catalog rule L20 prohibits.

The baseline is copied whole. Do not edit it. A clarification typed into the baseline is an amendment, whatever the commit message calls it. The manual explains the baseline. The manual is not a second law. An extension the standard mentions and this kit does not ship, including orbital intent, is not in this folder. It lives with the application that needs it. Do not create the missing path so that an example in the standard will resolve. A path you create locally to satisfy an example is a fork, and the next clean copy of the kit will not have it.

Do not take `NOW.ACTION` from the baseline, the manual, or the pointer under `en-ir/`. Do not start the project from any of them. Startup reads them so the session knows the protocol. It does not obey them as the status panel.
