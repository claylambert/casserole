# AA-SDD - conversation modes

A conversation is not yet a ledger and not yet a plan. These four modes keep it that way. Use one mode at a time. A message that mixes two modes will be read as the mode with the stricter write rule, and the file effect you expected from the other mode will not happen. Say the mode in the same sentence as its object.

The stamped plan is the door into a build. It is not one of these four. Reaching a build still requires the stage cadence: a working spec, a pre-plan you were allowed to reject, and a plan you asked for and stamped.

| Owner says | Mode | Writes | Code |
|---|---|---|---|
| `[BRAINSTORM]` | Intake. Ideas may be heard. | Nothing, unless the same message lists the files to write. | No |
| `[BRAINSTORMING]` | One named document. | Draft serials of that file only. | No |
| `[CHEW]` | Notes on a specification already in play. | Notes in that specification. | No, until `[PUFF]` on that object. |
| `[AD-HOC]` | A one-off ledger row. | A bug row, or a feature row when the message says feature. | Only if the owner asked for that change in the same turn. |

A bare `[AD-HOC]`, with no feature mark, is a bug. It is not a brainstorm. The bug index receives a row in that same turn. Treating it as an open discussion drops the row, and the next session will not know the defect was ever named.

`[BRAINSTORMING]` requires a filename. If the owner forgets the filename, ask. Do not invent a path. An invented path becomes a document the next session will treat as requested.

Chew notes stay notes. They must not be copied into `plans/`, and they must not be implemented, until the owner approves the named object. Approval of a different object does not release these notes.
