# AA-SDD - serial history

**Laws:** L15, L17.

Only the live serial stays beside the files that link to it. Earlier serials move to a sibling history directory. The move keeps the live name easy to open, and it keeps the closed text findable. A closed serial is never overwritten. Replacing its bytes is an overwrite even when the new text is the accepted next serial. Write the next serial as its own file and leave the closed file in place, then move the closed file into history in that same turn if it is no longer the live head.

- Directory: `{stem}.history/` next to the live file.
- Keep the full filename inside that directory, so a search still finds the closed serial by the name it had when it was accepted.
- Never overwrite a file that has been moved into history. History is the citable record. A correction is a new file, not a quieter edit of the old one.
- Do not put the active serial into history. The active file moves only when a successor replaces it as the live head. Parking the file you are still editing makes the next session edit history and believe it is current.

Inbound links move to the new live file in that same turn (L17). A link left on the closed file is a stale edge. The next session will edit the closed file thinking it is live.

| Live | History |
|---|---|
| `{stem}.draft.002.md` | `{stem}.history/{stem}.draft.001.md` |
| `{stem}.finalize.md` | `{stem}.history/` holds the drafts and release candidates |

The index names the live file. After the move, the index row is the new path, not the history path. A history path that becomes the index row has promoted a closed serial back to live, which is the overwrite this rule exists to prevent.
