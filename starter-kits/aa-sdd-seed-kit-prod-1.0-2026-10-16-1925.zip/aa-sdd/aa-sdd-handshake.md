# AA-SDD - handshake

**Manual:** decision words in [`../README.md`](../README.md) section 9. If a sentence there and a row here disagree about puff, lock, chew, or open, repair the manual. This file is the effect list for every token below, including tokens the manual does not repeat.

Tokens are directives. Each one has one file effect. You speak the token in the same sentence as its object. A token spoken beside a different object does not bind this one. Tone does not add a second effect. If the room sounded like approval and the token was an exploration, the file effect is the exploration. A later session will apply the row, not the mood.

The tables are the requirement. The sentences between them tell a new reader how to apply the row. If a sentence and a row disagree, follow the row and repair the sentence.

## Approval

| Token | Means | Do |
|---|---|---|
| `[PUFF]` | Approval of the named object. | Treat that object as locked unless a later serial reverses it. Stop offering alternatives on that item. |
| `[PUFFED]` | The owner read the note. | Mark it understood. Do not explain it again. |
| `[LOCK]` | Frozen. | Implement or specify exactly this, and nothing adjacent that was not named. |
| `[REFINED]` | Same intent, tighter language, on the next serial. | Carry the intent forward. Do not overwrite the prior serial. |

A puff that does not name an artifact does not authorize an edit and does not create a file. Enthusiasm is not a request to edit. A comparison is not acceptance, and a story is not acceptance. A serial advances only when the owner says `SERIAL-ACK` in the same sentence as that serial. The ladder is draft, then release candidate, then final. The word does not skip the release candidate. The new rung is a new file. This file does not define a second word for that yes. The syntax row is the effect.

## Not yet

| Token | Means | Do |
|---|---|---|
| `[CHEW]` / `[CHEWING]` | Still thinking. | Notes on the page only. Not a plan. Not code. |
| `[OPEN]` | The question has no answer yet. | Do not plan it and do not code it. Work that depends on the answer waits. |
| `[SCRATCHED]` | Withdrawn. | Remove it from the live spec. |
| `[PROPOSED_LOCK]` | A seat thinks a section is ready. | Wait. The section locks only on `[PUFF]` or `[LOCK]` from the owner. |
| `LAW_VIOLATION` | The work conflicts with a rule that is in force. | Stop that slice. Name the rule. |
| `[PRESERVE-ALL]` | Accepted text stays. Spoken lines under this mark stay byte-identical. | Add description around those lines. Do not paraphrase them. |
| `[PRESERVE-DOC]` | A document body stays unless the owner calls for a precise edit. | Do not edit the body because a puff approved something nearby. |
| `[ENCODE]` | The next artifact is data or intent. | Use EN-IR unless the owner named another encoding for that turn. |
| `[PRIME-DIRECTIVE]` | A law above every other rule and above the product document. Rule L23. Default row of [`../global/prime-directives.md`](../global/prime-directives.md). | Stop if the work needs a forced entry or a private file that was not offered. A named row is that row. |
| `[CLERK-SWEEP]` | An integrity pass across the file graph. | Not a startup. Not a rewrite of the specs into another form. |

Chew keeps an exploration in notes. Those notes must not be copied into `plans/` and must not be compiled into a product. Open is how you stop a false ending. Scratched is how you take an item back out of the live file after it has been written there. A proposed lock is a suggestion that a section is ready. The suggestion is not the lock. The owner's puff or lock is the lock.

Preserve-all is the rule for text that already shipped, and for spoken lines that must survive every later draft character for character. Description around those lines may grow. The lines themselves may not be paraphrased. Preserve-doc is the same instinct for a document body: approval of a neighboring object is not permission to edit this body. The precise-edit seat acts only when you call for that edit.

## Forbid

- Do not treat a joke as acceptance.
- Do not invent a token. A new token gets a row in the syntax reference and, when the token is a repeated sequence, a procedure file in this directory, in the same turn.
- Do not treat a narrative as a stamp. Approval is the owner's sentence, or one of the tokens above spoken in the same sentence as its object.
