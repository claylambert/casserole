# EN-IR(7) — Operator manual

**Name:** `enir`  
**Section:** 7. Operator manual.  
**Standard:** EN-IR/1.0  
**Normative source:** [`aa-sdd-enir-spec.md`](aa-sdd-enir-spec.md), amended 2026-10-15 20:54  
**This file:** instructional. It explains that spec. It is not a second baseline, not an extension, and not a version line.  
**Audience:** an engineer or operator standing up a Garage, and any system that emits or receives EN-IR.  
**Date:** 2026-10-15 20:54

If a sentence here and a sentence in the spec disagree, follow the spec. Do not edit the spec so that it matches this manual. Send a defect back to the authoring instance.

---

## NAME

enir — English-Native Intermediate Representation. English as locked bytecode. The interchange format for spec files and for data packets.

## SYNOPSIS

Choose one path before you write. If the human did not name the path, ask. Do not guess.

**Spec file.** A markdown document. One heading per decision. The first sentence under the heading is the requirement. State starts at `draft`.

**Data packet.** Plain text. Hatches in this order:

```text
HEADER
STRUCTURED-DATA
PACKED-TEXT
PACKED-INTENT      # required only when the human requested intent this turn
CARRIER-ANCHOR
SHOW-STATE         # optional
INTEGRITY
```

Default packet: `HEADER.intent` is `omitted`. `PACKED-INTENT` is absent. See the worked default in [Intent omitted](#15-worked-packet-intent-omitted).

## DESCRIPTION

EN-IR is the on-disk and on-the-wire representation used between a human, a language model, and another system. The record is headed English. A human can read it aloud. A later session seeks a heading and executes the first sentence under it.

There is no schema registry, no protobuf compiler, and no embedding file. The headings are the addresses. The sentence under a heading is the instruction. What is not in the file is not in the program.

The format has two paths. They share the name EN-IR. They do not share a job.

| Path | Use it when | Do not use it when |
|---|---|---|
| Spec file | You are writing a requirement a later session must seek and obey. | You are moving or storing a record that must round-trip. |
| Data packet | You are transferring data to another system, or persisting it so a later read can rebuild it. | You are writing a spec, a serial, or a design note. |

If one turn needs both, write both files and link them. Do not encode a spec as a packet. Do not encode a transfer as a serial.

AA-SDD (Architecture-Augmented Spec-Driven Development) is the sister practice: freeze the architecture and the spec before orchestration. EN-IR is the language those specs and payloads are written in. The two names are not synonyms.

The expansion is locked.

- **EN-IR** = English-Native Intermediate Representation = English as locked bytecode.
- **AA-SDD** = Architecture-Augmented Spec-Driven Development.

Do not publish a different expansion.

## 1. How to use this manual

Read [Choose a path](#3-choose-a-path), then the procedure for that path, then [English CRC](#17-english-crc) and [Operator checklist](#21-operator-checklist).

| You are about to | Read |
|---|---|
| Accept the standard | [Conformance](#8-conformance) |
| Copy the standard into another Garage | [Immutability](#7-immutability-and-change-control) |
| Encode a requirement from prose | [Spec file procedure](#9-spec-file-procedure) and [Families](#10-spec-file-families) |
| Move or store a record | [Data packet procedure](#11-data-packet-procedure) through [Intent omitted](#15-worked-packet-intent-omitted) |
| Check a packet you received | [English CRC](#17-english-crc) |
| Add an application hatch | [Extensions](#19-extensions) |
| Ignore local names and ceremony | [What you may ignore](#22-what-you-may-ignore) |

Spec section numbers below are written `Spec §`. Those numbers are the law's addresses. This manual's numbers are this manual's.

## 2. Terms

Use these words with these meanings. The same definitions are normative in Spec §0B.

| Term | Meaning |
|---|---|
| EN-IR | This interchange language. |
| Baseline | `aa-sdd-enir-spec.md`. Version line `EN-IR/1.0` until the authoring instance locks a newer `HEADER.en-ir-version`. |
| Path | Spec file, or data packet. |
| Spec file | Markdown. A later reader seeks one heading and obeys the first sentence. Not a packet. |
| Data packet | Headed-English record for transfer or for storage. A later read rebuilds the original from the packet alone. |
| Hatch | A named block in a packet: `HEADER`, `STRUCTURED-DATA`, `PACKED-TEXT`, `PACKED-INTENT`, `CARRIER-ANCHOR`, `SHOW-STATE`, `INTEGRITY`. |
| Rehydration | Rebuild of the original structure and every original value, using only the packet. |
| Intent | An instruction: what must happen because the text exists. |
| Purpose | What a field is, in the source's own words. Not an instruction. |
| English CRC | The recount in Spec §7. Counts and witnesses. Not a hash. |
| Authoring instance | The Garage that amends the baseline. The directory that holds the live spec is that instance. |
| Instance | Any Garage that holds a copy of the baseline. |
| Extension | A named addition in another file. Version line form `EN-IR/1.x-{NAME}`. It does not edit the baseline. |
| Cut | A copy frozen at a stamp and handed over. It stays that stamp. |
| Live baseline | The spec file as amended in the authoring instance. The amendment stamp in its version line identifies it. |
| Requirement owner | The human who owns the requirement. The authoring instance calls this role Hannibal. |
| Encoding seat | The seat that compiles headings from prose when asked. The authoring instance calls this role Radar. |
| Conformance | The four statements in [Conformance](#8-conformance). |
| Receiver | The system or the person who accepts a packet and runs the English CRC. |
| Sender | The system or the person who emits a packet. |

## 3. Choose a path

Run this before writing.

1. The human asked to encode a spec, or handed raw prose and asked for a spec. Use the spec-file path. Spec §4.
2. The human asked to transfer, persist, packetize, or hand the data to another system. Use the data-packet path. Spec §5.
3. The human did not name a path. Ask which path. Do not guess.
4. Emit headed English. Do not wrap either path in JSON.
5. Do not add files the human did not name.
6. The same input on the same path yields the same headings and the same field names. On a spec, explanatory sentences may tighten on a later encode. On a packet, values do not tighten.
7. A packet writes `INTEGRITY`. The receiver recounts. A mismatch is not trusted.
8. Do not add `ORBITAL-INTENT` unless the human named that extension.

Encode is not approval. It does not stamp a spec accepted, and it does not start a build, a deploy, a render, or a stitch.

## 4. What the encoding is

Six rules. Spec §2.

1. **Source.** Ordinary English and headed English fields. A human writes it. A human can read it back.
2. **Bytecode.** That English, locked. Headings are stable. Chat that produced the file is not left in the file. The same input yields the same hatch names.
3. **Seek.** The heading is an address. The next session lands on it. It does not recover the requirement by searching an old chat or a retrieval index.
4. **No hidden bus.** The path you wrote is the encoding. A missing sentence is a missing requirement.
5. **Packing depends on the path.** On a spec, a shorter file is not the goal. On a packet, pack only while a full rebuild is still possible. If a human cannot read the result, the encode failed. Embeddings, coordinates, and vector blobs fail both paths.
6. **Intent depends on the path.** On a spec, the encoding seat compiles intent into the headings when asked to encode prose. The requirement owner remains the author of the requirement. The encoding seat does not add a requirement the prose did not carry. On a packet, intent is present only when the human requested it in that turn. Do not invent intent. Do not attach it later.

## 5. Prohibited substitutes

Do not emit any of the following and call it EN-IR. Spec §3.

| Substitute | Rule |
|---|---|
| JSON as the system of record | Forbidden. JSON may exist downstream, after EN-IR is locked, at an integration boundary the human named. That JSON is not EN-IR. |
| XML, `<Node:ID>`, AST dumps, protobuf, base64, YAML as source of truth | Forbidden. |
| Vector dumps, embedding tables, coordinate lists | Forbidden. |
| A summary with a format name on it | Forbidden. A summary drops values. A packet that drops a value has failed. |
| A compression contest | Forbidden. Readability is mandatory on both paths. |
| A lecture that is not an instruction | Forbidden in a spec heading. The first sentence is executable. |
| A binary CRC, hash, or checksum in place of `INTEGRITY` | Forbidden. Use the English CRC. |
| `ORBITAL-INTENT` inside the baseline | Forbidden. That hatch is an application extension. |

## 6. Requirement words and local names

The spec does not import an outside keyword RFC. Read its verbs this way. Spec §0C.

| Wording in the spec | Operator meaning |
|---|---|
| is, does, survives, the default is | Requirement. Do that sentence. |
| Do not, is not, fails, a CRC fail | Prohibition. |
| optional | You may omit it. `SHOW-STATE` is optional. |
| may | Permitted. |
| upon request | Present only after the human asked, in that turn. Otherwise absent. |

`PACKED-INTENT` is required after a request for intent. It is forbidden when nobody requested intent. "Optional upon request" is that pair of rules. The encoding seat does not invent the request. A mood is not a request. A request is a sentence in the turn.

The spec also uses names that belong to the authoring instance. Translate them as follows. Spec §0D.

| Spec word | Read it as |
|---|---|
| Hannibal | requirement owner |
| Radar | encoding seat |
| puff, when it locks a change | the requirement owner locked the amendment, in that turn, out loud |
| Y, RC, Final | the authoring instance's acceptance ceremony for a spec file |

The requirement that travels with the ceremony words: the spec file shows a state, and a locked file is not rewritten in place. A new truth is a new file. A metaphor is not an acceptance.

You may keep your own role names. You still perform the requirement.

## 7. Immutability and change control

The baseline text is the same in every conforming instance. Spec §0E.

- Copy `aa-sdd-enir-spec.md`. Do not edit the copy. Do not paraphrase it. Do not clean it up.
- The words match the authoring instance. A newline convention (LF versus CRLF) is not an amendment. A changed sentence is a rewrite.
- A rewrite is not `EN-IR/1.0`. Two files that both claim `EN-IR/1.0` and differ in their sentences are not the same standard.
- `EN-IR/1.0` is one version line. A dated amendment replaces the previous text of that line in the authoring instance. An older stamp is an older amendment. It is not a second baseline.
- A newer version line exists only when 1.x cannot hold the law, and only when the requirement owner of the authoring instance locks it. Instances then copy that new file.
- An extension does not change the baseline. It lives in another file, under its own version line.
- A defect or a clearer sentence goes back to the authoring instance. Do not patch your copy and keep the version line.
- A cut is frozen, and it is not the live baseline. Seed kit prod 001, cut 2026-10-15 19:36, is that cut. A holder of the kit holds the kit. The current standard is the live spec. This manual is not inside that kit.

Identify the live baseline by the version line at the top of `aa-sdd-enir-spec.md`. This manual matches amendment stamp 2026-10-15 20:54. If the stamp in the spec has moved and this line has not, read the spec.

## 8. Conformance

Accept EN-IR by meeting the statement that matches the work. Meeting one statement does not require the other three. Local names are not a fifth statement. Spec §0F.

**Conforming spec file.**

- Follows Spec §4.
- States what it is, what it is not, and a token.
- One heading per decision. The first sentence is the requirement.
- One family in that file.
- An existing head is linked, not pasted.
- The spec is not wrapped as a data packet.
- State is visible. A locked file is not improved in place.

**Conforming data packet.**

- Follows Spec §5. Hatches appear in the synopsis order.
- Every source structure and every source value survives, under the source name, in the source order.
- `CARRIER-ANCHOR` is sufficient to rebuild the original form.
- `HEADER.intent` is `omitted` unless the human requested intent in that turn.
- When intent was not requested, `PACKED-INTENT` is absent.
- English CRC passes.
- `INTEGRITY.orbital` is `0` unless a named extension defines hops.
- JSON, XML, and a vector dump are not the record.

**Conforming receiver.**

- Reads a conforming packet.
- Recounts Spec §7.
- On a CRC fail, does not execute.
- Preserves an unknown hatch and still checks the baseline hatches.
- Does not treat `ORBITAL-INTENT` as law unless that extension was named.
- Does not require the authoring instance's seat names.

**Conforming Garage instance.**

- Holds the baseline text, or declares the cut it holds and does not call that cut the live baseline.
- Does not edit the baseline.
- Names extensions `EN-IR/1.x-{NAME}` and keeps them outside the baseline file.
- May keep its own seats and its own speech. Those are not required for conformance.

A yes to the matching statement is acceptance of the standard.

## 9. Spec file procedure

Use this path when the artifact is a requirement. The file is markdown. It is not a fenced data packet. Spec §4.

The authoring instance's acceptance ceremony is draft, then an explicit acceptance, then a release-candidate state, then an explicit acceptance, then final. Never overwrite a locked file. Roll the next number. Your instance may use other state words. The file still shows a state, and a lock is still not rewritten in place.

A paper serial in the authoring instance also keeps the fences in [`aa-sdd-white-paper-workflow.md`](aa-sdd-white-paper-workflow.md). A build serial keeps the loop in [`aa-sdd-q18-cadence.md`](aa-sdd-q18-cadence.md). Those files are local procedure. They are not a second EN-IR. Open them only when your work is that family inside an instance that uses them.

### 9.1 Why the spec has this shape

A spec that cannot say these six things is notes. Spec §4.1.

1. The next session lands on a heading. It does not replay the chat that produced the file.
2. A requirement is a sentence that can be executed. A tour is not a heading.
3. The lock is a file with a state. Editing a locked file in place does not create a new truth.
4. Raw prose is the wish. The encoding seat's headings are the compile. The prose remains quoted so the requirement owner can find the original sentence.
5. A citation is a link. Pasting another spec into this file hides two heads. The next session will obey the paste and miss the lock.
6. The encode does not accept the spec, and it does not authorize a build or a render.

### 9.2 Steps

When the requirement owner says to encode a spec from raw prose, the encoding seat does this, in order. Spec §4.2.

1. Name the path. This is a spec. It is not a data packet.
2. Name the family in [Families](#10-spec-file-families), or ask. Do not guess a project, a repository, or a video bay.
3. Open the file with what it is, what it is not, and the token. That opening is the encoding seat's intent for the file.
4. One heading per decision. The heading is the seek address. The first sentence under it is the requirement.
5. Quote the requirement owner's prose under the heading it fed, enough that the sentence can be found. A line marked `[PRESERVE-ALL]` stays byte-identical. Do not paraphrase it.
6. Link a head that already has a file. Do not paste that file. Do not repeat its law.
7. Keep it readable aloud. Concise means no leftover lecture.
8. Leave the state at `draft`. The same prose, encoded again for the same family, yields the same headings. Sentences may tighten. The structure does not drift.
9. Keep product nouns out of a protocol file. An extension lives in the bay that needs it.

Skeleton:

```text
# <name> — <what this file is>

**What it is not:** <one sentence>
**Token:** <token>
**State:** draft
**Depends:** <linked heads. Not pasted.>

## <seek address>
<one sentence: what must happen>
> <requirement owner's prose, quoted, when this heading came from those words>
```

If a spec cannot state what must happen because it exists, it is notes. It is not locked.

### 9.3 While encoding a spec, do not

Spec §4.4.

- Paraphrase a preserved line.
- Invent a character, a clip, a database, a thread model, or a law the prose did not carry.
- Wrap the spec in JSON and call it encoded.
- Pack the spec into a data packet unless the human also asked for a packet.
- Treat the encode as permission to build, deploy, render, or stitch.

## 10. Spec file families

A spec encoded from prose belongs to one family. The family chooses the headings. It does not choose a second protocol. One family per file. If the prose mixes families, split the files and link them. Spec §4.3.

### 10.1 Project

Building the work. The file states:

- what the work is, and what it is not
- which invariants are frozen
- which decisions have collapsed
- what is still allowed to move
- the head it cites

It does not paste another spec. The encoding seat's intent: the next session can seek the freeze and will not reopen it while emitting.

### 10.2 Code

The contract the living source must match. The source is not the spec. Name the realization language when this contract has one. When the method does not care, say that other languages remain permitted. The file states:

- the contract the source must match
- what a synthesis pass is forbidden to invent
- that a hand edit is observed and flagged, and is not a silent new spec

The encoding seat's intent: a synthesis pass can emit from the freeze without inventing a second architecture.

### 10.3 Video

A bay package. Core law for the authoring instance is [`aa-sdd-video-bay.md`](aa-sdd-video-bay.md). The package file holds instance values only: title, roster, voice map, clip count, palette, stamps. It does not re-encode clip, camera, token, or spoken-line law. A bay hatch is `EN-IR/1.x-{BAY}` inside that bay. It does not enter the baseline.

The encoding seat's intent: the next session can find the live clip, the locked plate, and the mouth that speaks the line, and will not render a still the requirement owner did not name.

## 11. Data packet procedure

Use this path to move data, or to store it so a later read can rebuild it. A packet is not a spec and not a serial. Spec §5.

Four bounds:

1. **Lossless.** Every field survives. A source name stays that name. A source order stays that order. A source value is not paraphrased. Nesting survives as headed English. Do not flatten it away.
2. **Pack inside that bound.** Headed English. No lecture. No leftover chat. Readable aloud. If the next cut would drop a value or a level of structure, stop.
3. **Rehydration test.** A receiver who has only the packet rebuilds the original structure and every value. `CARRIER-ANCHOR` holds the original form, or a headed English image from which the rebuild is complete. Witness head and tail are checks. They are not the data.
4. **Intent upon request.** Default is omitted. The sender does not decide that a record needs an instruction. The human requests intent in a sentence this turn, or the packet carries none.

A complete baseline packet is plain text. Omit a hatch only when the spec marks it optional (`SHOW-STATE`, and `PACKED-INTENT` when intent was not requested). Field `intent` and field `meta` are omitted when they have nothing to carry.

`ORBITAL-INTENT` is not in this grammar. A baseline receiver that sees it preserves the hatch and still validates the baseline hatches. It does not treat the hatch as law.

`from` does not invent application seats. Names such as mill or counter belong to a bay that has them. If your source has no such seat, do not add one.

## 12. Packet grammar, field by field

Hatches stay in this order. The grammar below is the normative shape. Spec §5.

```text
HEADER:
  en-ir-version: EN-IR/1.0
  id: <short unique token>
  from: <HUMAN | MODEL | RADAR | <named-seat>>
  state: LOCKED
  encoding: PURE-EN-IR
  struct-source: <prose | table | csv | pdf-text | image-caption | unknown>
  orig-encoding: <a normal-world encoding the human named, else none>
  purpose: <one English sentence: why this packet exists>
  intent: <present | omitted>

STRUCTURED-DATA:
  - field: <name>
    type: <token | number | flag | bound | enum | prose | timestamp | path>
    size: <hint: short | line | block>
    purpose: <plain English: what this field is for>
    intent: <optional. Only when intent was requested and this field carries an instruction>
    struct-source: <where it was found>
    orig-encoding: <if any>
    meta: <optional English>

PACKED-TEXT:
  <non-field material. Readable. No dropped values.>

PACKED-INTENT:
  <only when the human requested intent this turn. One compiled sentence.>

CARRIER-ANCHOR:
  <the original form, or a headed English image from which every value can be rebuilt.>

SHOW-STATE:
  <optional. Last beat for the next hop. Not a memoir.>

INTEGRITY:
  fields: <count of STRUCTURED-DATA fields>
  anchor-chars: <character count of CARRIER-ANCHOR>
  orbital: 0
  witness-head: <first ~24 characters of the original source>
  witness-tail: <last ~24 characters of the original source>
  seal: LOCKED
```

### 12.1 HEADER keys

| Key | Write | Notes |
|---|---|---|
| `en-ir-version` | `EN-IR/1.0` | The baseline version line. An extension does not change this value on a baseline packet. |
| `id` | a short unique token | Identifies this packet inside the exchange. The worked examples use `claim-A-19` and `claim-A-19-record`. A UUID is not required. |
| `from` | `HUMAN`, `MODEL`, `RADAR`, or a named seat | Who emitted the packet. `RADAR` is the authoring instance's encoding seat. Another instance uses `HUMAN`, `MODEL`, or its own seat name. |
| `state` | `LOCKED` | The packet is sealed by `INTEGRITY.seal`. This is not the draft state of a spec file. |
| `encoding` | `PURE-EN-IR` | The record is this grammar. |
| `struct-source` | `prose`, `table`, `csv`, `pdf-text`, `image-caption`, or `unknown` | Where the structure was found. |
| `orig-encoding` | `none`, or the encoding the human named | Records the source encoding. Naming JSON here does not make the packet JSON. |
| `purpose` | one English sentence | Why this packet exists. |
| `intent` | `present` or `omitted` | See [Intent on a packet](#13-intent-on-a-packet). |

### 12.2 STRUCTURED-DATA keys

One row per source field. Row order is source order.

| Key | Write | Notes |
|---|---|---|
| `field` | readable English token | The source name. Do not rename a key. |
| `type` | a word: `token`, `number`, `flag`, `bound`, `enum`, `prose`, `timestamp`, or `path` | Not a JSON Schema reference. A new type word is allowed only when one English sentence defines it, in the file that introduces it. |
| `size` | `short`, `line`, or `block` | A hint to the reader. Not a byte quota. |
| `purpose` | what the field is | Source's words. Not an instruction. A bare column name stays a bare column name. Do not invent a gloss the source does not support. |
| `intent` | omit, or one instruction | Present only under the rules in [Intent on a packet](#13-intent-on-a-packet). |
| `struct-source` | where this field was found | Same vocabulary as the header when that is the truth. |
| `orig-encoding` | source encoding, if any | Omit or set `none` when there is none. |
| `meta` | optional English | Omit when you have nothing to say. |

### 12.3 Remaining hatches

| Hatch | Rule |
|---|---|
| `PACKED-TEXT` | Material that is not a field. Still complete. Still readable. |
| `PACKED-INTENT` | The intent of the whole payload, compiled into one English sentence. Not a slogan. Absent unless intent was requested. |
| `CARRIER-ANCHOR` | The original form, or a headed English image from which the original structure and every value can be rebuilt. Not a sample. Not a summary. |
| `SHOW-STATE` | Optional. Use when a story or a session continues. Last beat only. |
| `INTEGRITY` | The English CRC inputs. See [English CRC](#17-english-crc). |

### 12.4 Field rules

Spec §5.2.

- `field` names are readable English tokens.
- `type` is a word.
- Counts in `INTEGRITY` are decimal integers. The receiver recounts. No hash algorithm.
- Baseline `orbital` is `0`. An extension may define hops. The baseline does not.

## 13. Intent on a packet

The human requests intent, or the packet carries none. The sender does not choose. Spec §5.1.

An earlier note said payload intent depends on the use. That note is withdrawn for this path. The rule is the table.

| This turn | `HEADER.intent` | Field `intent` | `PACKED-INTENT` |
|---|---|---|---|
| The human did not request intent | `omitted` | Omit | Omit |
| The human requested intent | `present` | On each field that carries an instruction the human named | Required. One compiled sentence. Not a slogan. |
| Intent was requested, and a field is only a name | `present` | Omit on that field | Still required for the payload |

`purpose` names what the field is. It is not an instruction.

Nothing in the source is dropped. Material that is not a field rides in `PACKED-TEXT` and in `CARRIER-ANCHOR`. When intent is present, it is compiled into the heading. It is not a second document.

Spec-file intent is a different rule. On a spec, the encoding seat compiles headings when asked to encode prose. That compile is not a `PACKED-INTENT` hatch. Do not put a spec's intent into a packet unless the human also asked for a packet.

## 14. Worked packet, intent requested

This packet exists because the human requested intent on this turn. Without that request, use [Intent omitted](#15-worked-packet-intent-omitted). The text is reproduced from Spec §5.3. Quote the spec if you need the normative copy.

Source fact that must survive: claim A-19 is pending, and the exception is on page 188.

```text
HEADER:
  en-ir-version: EN-IR/1.0
  id: claim-A-19
  from: HUMAN
  state: LOCKED
  encoding: PURE-EN-IR
  struct-source: prose
  orig-encoding: none
  purpose: bind this claim to the exception on page 188
  intent: present
STRUCTURED-DATA:
  - field: claim_id
    type: token
    size: short
    purpose: identifies the claim in the source narrative
    intent: join this row to the exception on page 188
    struct-source: prose
    orig-encoding: none
  - field: status
    type: enum
    size: short
    purpose: lifecycle of the claim
    intent: treat as pending until a human locks otherwise
    struct-source: prose
    orig-encoding: none
PACKED-TEXT:
  Claim A-19 is pending.
PACKED-INTENT:
  Join A-19 to page 188. Do not close the claim.
CARRIER-ANCHOR:
  Claim A-19 is pending. See the exception on page 188.
INTEGRITY:
  fields: 2
  anchor-chars: 54
  orbital: 0
  witness-head: Claim A-19 is pending
  witness-tail: exception on page 188.
  seal: LOCKED
```

How to read it:

- `intent: present` because the human asked.
- Two field rows, so `INTEGRITY.fields` is 2.
- Each field that carries an instruction has an `intent` line. `PACKED-INTENT` is one sentence for the whole payload.
- The anchor keeps page 188. A shorter sentence that drops page 188 is a failed packet.
- `witness-head` is the opening clause of the source, 21 code points, inside the "about 24 characters" window.
- `witness-tail` is the closing clause `exception on page 188.`, 22 code points.
- The anchor sentence `Claim A-19 is pending. See the exception on page 188.` is 53 Unicode code points with no trailing newline. The published `anchor-chars` value is 54. A receiver compares the integer in the packet to a fresh count of the anchor as pasted, including a newline if the paste included one. When you emit your own packet, write the count you just made. Do not copy 54 onto a different string.

These are failed encodings of the same source:

- `{"claim_id":"A-19","status":"pending"}`
- A paraphrase that drops page 188.

## 15. Worked packet, intent omitted

This is the default for transfer and for persistence. The text is reproduced from Spec §5.4.

```text
HEADER:
  en-ir-version: EN-IR/1.0
  id: claim-A-19-record
  from: HUMAN
  state: LOCKED
  encoding: PURE-EN-IR
  struct-source: prose
  orig-encoding: none
  purpose: hold the claim record
  intent: omitted
STRUCTURED-DATA:
  - field: claim_id
    type: token
    size: short
    purpose: the claim token as written
    struct-source: prose
    orig-encoding: none
PACKED-TEXT:
  Claim A-19 is pending.
CARRIER-ANCHOR:
  Claim A-19 is pending.
INTEGRITY:
  fields: 1
  anchor-chars: 22
  orbital: 0
  witness-head: Claim A-19 is pending
  witness-tail: Claim A-19 is pending.
  seal: LOCKED
```

How to read it:

- `intent: omitted`. There is no `PACKED-INTENT`. The field row has `purpose` and no `intent`.
- One field row, so `fields` is 1.
- The anchor value `Claim A-19 is pending.` is 22 Unicode code points. `anchor-chars` is 22. That is a clean recount with no trailing newline added.
- `witness-head` is the opening clause without the period (21 code points). `witness-tail` is the full sentence including the period (22 code points). Both sit inside the about-24 window.
- `purpose` repeats the source's name. It does not add an instruction such as "close the claim" or "join page 188". Those instructions are absent because nobody requested intent.

Ship this shape unless the human asked for intent on this turn.

## 16. Story, roster, and dialog

Apply this when the payload is a story, a roster, or a scene. Spec §6. The same rules apply on a spec heading that locks a spoken line.

- Character names and role lines are part of the bytecode. Keep them. Do not rename a character to "Agent 1".
- A local token such as `[ARAGORN]` is a semantic key. Bind it once. Every later use is that same row. Do not invent a second token for the same referent.
- Dialog is a bound: speaker, exact line, only that mouth. A specified line is spoken. A mouth that is not the speaker does not speak.
- Do not improve dialog. The string is exact.

The key is in the file. It is not in a hidden memory or a side channel.

## 17. English CRC

Not a cryptographic checksum. No hash algorithm. A tool is not required. Any character counter is permitted. Conformance does not depend on one. Spec §7.

Procedure for a receiver:

1. Count `STRUCTURED-DATA` rows. Compare to `INTEGRITY.fields`.
2. Count characters in `CARRIER-ANCHOR`. The unit is Unicode code points. Spaces count. Newlines count when they are part of the pasted anchor value. Compare to `anchor-chars`.
3. Compare `orbital` to the hops a named extension defined. On the baseline the value is `0`.
4. When the original source is present, check `witness-head` and `witness-tail` against it. The window is about the first 24 characters and about the last 24. When the original is absent, you cannot complete this check. You still complete steps 1, 2, 3, 5, and 6.
5. Fail if a required baseline hatch is missing. Fail if `HEADER.intent` is `present` and `PACKED-INTENT` is missing. Fail if `HEADER.intent` is `omitted` and `PACKED-INTENT` is present.
6. Fail if the packet drops a source field, renames a source key, reorders a source sequence, or paraphrases a value. Fail if the packet embeds intent when the human did not request it.
7. On a fail, do not execute. Ask the human to re-emit. A repair note may be headed English. The baseline does not define a ticket schema. A bay that uses tickets defines its own.

Isolate the anchor value before you count it. A two-space indent on the example line is markdown layout, not part of the sentence, unless your storage form kept those spaces inside the value. The sender and the receiver count the same span. State which span you counted if you are handing the packet to a person who will recount by hand.

Worked recount, default packet: `Claim A-19 is pending.` is 22. The packet says 22. Pass on that check.

Worked recount, intent-requested packet: the printed sentence is 53 with no trailing newline. The published integer is 54. Follow step 2 on the bytes you actually hold. Do not force a match by editing the baseline.

## 18. Model and receiver behavior

When the human says encode, says EN-IR, or pastes the spec, name the path before writing. Spec §8.

| Situation | Behavior |
|---|---|
| Spec, or encode a spec from raw prose | Spec §4. Serial form. The encoding seat's intent is the compile. Family is project, code, or video. |
| Transfer, persist, packet, or handoff | Spec §5. Preserve every structure and every value. Pack only as far as rehydration allows. Embed intent only if requested this turn. |
| Path not named | Ask. |
| Either path | Headed English. Human-readable. No JSON wrapper. |
| Files | Do not add files the human did not name. |
| Stability | Same input, same path, same headings, same field names. Spec sentences may tighten. Packet values do not. |
| Roles in the paste | Preserve them. |
| `INTEGRITY` | The sender writes it. The receiver recounts. A mismatch is not trusted. |
| `ORBITAL-INTENT` | Add it only when the human named that extension. |

Fail closed. A receiver that "fixes" a bad packet by guessing has not conformed.

## 19. Extensions

You may add an optional hatch in a later version line, documented in the bay that needs it. You may add a `type` word if one English sentence defines it. Spec §9.

You may not:

- Replace English with JSON, XML, or protobuf and keep the name EN-IR.
- Nest hatches inside JSON.
- Require a tool or a binary compiler.
- Drop human readability.
- Copy a bay hatch into the baseline.

A baseline receiver that sees an unknown hatch preserves it and still validates the baseline hatches.

| Extension | Where | What it adds |
|---|---|---|
| `EN-IR/1.x-OCOT` | [`OCOT.en-ir-orbital.md`](../../operation_cigar-on-the-table/spec/global/OCOT.en-ir-orbital.md) | `ORBITAL-INTENT`. One application. Not baseline. Open this only when your work is that application. |
| `EN-IR/1.1-KHAZAD` | the Khazad video package | Tokens and clip hatches for that bay only. |

`EN-IR/2.0` happens only when 1.x cannot hold the law, and only when the requirement owner of the authoring instance locks it. The 2026-10-15 amendments stay on 1.0. They did not mint 2.0.

Historical copies that require intent on every field, or that list `ORBITAL-INTENT` as a baseline hatch, are the 2026-09-26 snapshot. They do not win. The export directory is a stub. Pointers live under [`EN-IR/`](EN-IR/README.md). Give a model the baseline file, not the pointer.

## 20. Files, downstream JSON, and old copies

Markdown is a carrier. The headings are the grammar. Spec §10.

After EN-IR is locked, a downstream system may serialize to JSON at a boundary the human named. Mark that artifact as downstream. Do not call it EN-IR. Do not feed it back as the source of truth.

The baseline file is sufficient for a baseline packet. Do not fetch another product tree to finish one. Do not invent seats the human did not name.

| Artifact | Standing |
|---|---|
| `aa-sdd-enir-spec.md` | The law. Live baseline. |
| `enir-suit-man.md` | This manual. Instructional. |
| [`aa-sdd-encode.md`](aa-sdd-encode.md) | The authoring instance's encode order. It points at the spec. |
| [`EN-IR/`](EN-IR/README.md) | Pointers and 2026-09-26 snapshots. Not the law. |
| `docs/spec/export/EN-IR/` | Stub. The directory moved on 2026-10-15. |
| Seed kit prod 001, 2026-10-15 19:36 | Frozen cut. Not the live head. |
| Mill and counter blobs inlined 2026-10-13 | Snapshots. They do not win. |
| `aa-sdd/en-ir-tx-tail-log.pitted.md` | Closed brief. Not the protocol. |

## 21. Operator checklist

Name the path. Then run one list. A failed box means you do not call the artifact EN-IR. Say which path failed, and which box, in English. Passing a box does not amend the baseline. Spec §11.

**Spec file**

- [ ] The file says what it is, what it is not, and the token.
- [ ] The shape is a serial. State is `draft` until an explicit acceptance.
- [ ] One heading per decision. The first sentence is the requirement.
- [ ] A spec from raw prose names its family. Intent sentences are the encoding seat's compile. The requirement owner's prose is quoted. A preserved line is byte-identical.
- [ ] Heads are linked, not pasted.
- [ ] A human can read it aloud.

**Data packet**

- [ ] `HEADER.en-ir-version` is `EN-IR/1.0` and `encoding` is `PURE-EN-IR`.
- [ ] Every source field, name, order, and value survived.
- [ ] `CARRIER-ANCHOR` can rebuild the original form. It is not a sample.
- [ ] The pack stopped before a value or a level of structure would drop.
- [ ] `HEADER.intent` is `omitted` unless the human requested intent this turn.
- [ ] If intent was requested, `PACKED-INTENT` is one compiled sentence and is not a slogan.
- [ ] If intent was not requested, `PACKED-INTENT` is absent and no field carries an intent line.
- [ ] `INTEGRITY.orbital` is `0` unless a named extension defines hops.
- [ ] `INTEGRITY` counts match a recount.
- [ ] No `ORBITAL-INTENT` hatch unless that extension was named.
- [ ] No JSON or XML wrapper.
- [ ] A human can read the packet aloud.

## 22. What you may ignore

These are the authoring instance's speech. Set them aside and the four conformance statements still stand. Spec §0G.

- The names Hannibal and Radar, and any other seat name.
- Table talk: puff, chew, cigar, tea.
- The ceremony words Y, RC, and Final, provided your spec file shows a state and a lock is not rewritten in place.
- Cadence files and the video-bay core, until your work is that family inside an instance that uses them.
- Orbital intent and any bay hatch.
- The closed brief named by `HEADS.ENIR`.

You still implement the two paths, the packet grammar, the English CRC, and the ban on JSON as the record.

## SEE ALSO

- Normative spec: [`aa-sdd-enir-spec.md`](aa-sdd-enir-spec.md). Read the standard frame first, then Spec §0 through §3, then the path you are implementing.
- Encode order for the authoring instance: [`aa-sdd-encode.md`](aa-sdd-encode.md).
- Pointer directory: [`EN-IR/README.md`](EN-IR/README.md).
- Orbital extension, application-specific: [`OCOT.en-ir-orbital.md`](../../operation_cigar-on-the-table/spec/global/OCOT.en-ir-orbital.md).

**— End of operator manual.**
