# Corkboard

**Sort:** reverse chrono. Unique key = **date-time**. Newest at the **top**. The operator starts at line 1. To trace a fault, read the pins from the bottom upward. Do not reorder the board.

**Voice:** pin **as yourself**. The clerk is the clerk. The owner is the owner. A named seat is that seat. No one writes in another voice.

**Alerts:** [`system-report.md`](system-report.md). Grid clear. When an alert is OPEN, this line becomes **`[RED-ALERT] SYSTEM REPORT`** and the link stays.

Only what a person **chooses** to pin. Pinning is a narrated event. The clerk pins a key action: the state, and what occurred. The owner may pin a note back to the team. A named seat may pin in that seat's own voice. A private note stays off this board.

The next line is the shape of a pin. It is not a pin. Do not delete it. Do not treat it as a log of a turn.

`**YYYY-MM-DD HH:mm — Name.** The state. What occurred.`

A real pin uses that shape, then `[NEW ON ...]` with the date of the turn. Leave the board empty until there is a pin to write.

---
