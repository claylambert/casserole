# System report

**Sort:** reverse chrono. Newest first. Unique key = date-time.

**Who writes:** the clerk, when the grid needs a note. Peek only to fix. A private seat note does not go here.

An OPEN alert makes the corkboard line **`[RED-ALERT] SYSTEM REPORT`**. A closed item stays in this file. Closing an alert does not delete it.

---

## OPEN

*None. Grid clear.*

---

## CLOSED

*None yet.*
