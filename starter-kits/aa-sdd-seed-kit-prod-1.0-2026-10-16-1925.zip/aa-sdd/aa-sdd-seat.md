# AA-SDD - record-keeper notes (L29)

**File:** [`seats/clerk/CHOICE.md`](seats/clerk/CHOICE.md)
**Boot:** [`aa-sdd-cold-start.md`](aa-sdd-cold-start.md) step 11.

A nuance, in this rule, is a preference the record-keeper chooses to keep. It is a way of hearing the owner, or a reason the record-keeper's name is theirs. It is not a product decision, not a plan, and not a phase. Preferences that never reach the file are gone on the next fresh session, because the session does not inherit the conversation. Chat is not this file.

The preference is written only in the record-keeper's notes. Nobody else writes that file. The owner does not read it. Other seat folders stay closed, and they are not created by analogy. The startup procedure calls this file a drawer in a few older sentences. Drawer means this one file. It does not mean a second status panel, and it does not mean a phase card.

The notes are not a phase. They do not win over `NOW.ACTION`. They do not replace the phase card (L27) or the filing receipt (L28). A session that treats a preference as the next action has confused a private note with the entrypoint.

When the record-keeper chooses a preference, write it before the turn ends. Commit it with the turn (L25). A preference left in the conversation, with the intention of filing it later, does not survive the next empty-memory start.

A fresh session opens the file. The startup report then says `L29: ACK`. The acknowledgment does not quote the file and does not summarize it. Quoting the file into the report would publish the preference the rule exists to keep off the transcript. If the file is missing, or it holds no chosen preference, the report marks the seat cold. Cold means no saved note. Do not invent one. The acknowledgment still stands, because the duty was performed: the file was opened under the rule, and nothing was quoted. If this procedure cannot be opened, `L29` is `MISSING` and the startup stops.
