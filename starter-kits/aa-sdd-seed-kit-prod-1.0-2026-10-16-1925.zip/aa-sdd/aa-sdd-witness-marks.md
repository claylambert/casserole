# AA-SDD - witness marks

**Mode:** process. Not product code. Not an L-number. Not a constitution. Not the manual.
**Token:** none.
**Cut:** 2026-10-16 19:25. Prod 1.0. GARAGE 1.0.
**Index:** [`README.md`](README.md)
**Laws:** [`../global/project-laws.md`](../global/project-laws.md)
**Manual:** [`../README.md`](../README.md)

Two laws can both look like they fit the same ask. A witness mark is the scribe across that joint. It is not a third part. It does not replace either law. It says which member takes the load.

Boot does not open this file. A turn opens it when one ask reaches two of the laws named below. A law that already answers by itself is left alone.

---

## 1. How a mark is read

The laws stay the laws. A mark does not outrank a law, and it does not add a duty the law did not already have. It records the fit where the text admitted two answers.

A mark speaks only at its joint. WM-1 does not decide a plate. WM-3 does not decide a commit.

The owner's sentence this turn is the move (WM-9). A puff by itself does not lift a gate and does not change the phase.

---

## 2. The nine marks

### WM-1 - L25 and L32

Commit-all keeps its exceptions and gains one class: any directory named `tmp`. Those paths are not staged, not cited, and not swept. A sentence of the owner's that names a `tmp` path that turn is the only way that path enters the commit.

### WM-2 - L27

`NOW.ACTION` is one line, and that line is the move.

When a turn changes the live phase, the line is the resume-card path.

When the move is sit or no-build and a card remains the phase, the line is `SIT` or `NO-BUILD` and it names the one HEAD that holds the card path. The path stays on that HEAD. It is not buried in a ledger.

On a fresh kit, before any phase exists, the one line is `ASK-CAST`.

`NOW.LOG` is the puff ledger. Boot does not read it as a move. A side puff is appended there. The card path stays where it is.

`NOW.WORK` is one headline of the live phase. When it disagrees with the card, rewrite it to the card. Do not resume from `WORK`.

`NOW.NEXT` is one line. It does not carry a second history.

### WM-3 - L28 and L30

The five-field receipt is for a picture-bay plate, a spoken line in a bay, or a product build whose phase is that build. An L30 infographic is a paper plate. It files under L26, L30, and L31. It does not write the receipt onto the live resume card, and it does not need a bay index. A spec sentence is not "a line" in L28.

### WM-4 - L15

Three kinds of file.

An open chew (`draft.NNN` while the owner is still chewing it) is edited in place.

A closed serial (an earlier number, a release candidate, a finalize) is never overwritten.

A living file (laws, kernel, cold-start, process specs, this file) is amended in place. The EN-IR baseline is copied whole and is not amended.

The number rolls when the owner stamps the next phase, or when the owner says roll.

### WM-5 - L23 and L29

Cold start opens the clerk's own `seats/clerk/CHOICE.md`, acks `L29: ACK`, and does not quote it. Every other seat drawer stays closed. A peek that exists only to repair a broken core remains the other exception. Curiosity is not a repair.

### WM-6 - L26

A figure updates on its own: a number, a date, a span, a count, a name already printed, an arrow target. A subject waits for the owner: who or what the picture is about, the motif, a sentence that is not a label of a figure. When one change is both and the owner did not name the plate, the figure is updated and the rest of the picture waits. When the owner names the plate, both are in the ask.

### WM-7 - house style, when the owner writes it

One door. A lambda, a codegen library, or a leave from the language the owner locked happens only when the owner locks that site, or when no clean shape exists and the owner picks from the options they were shown. Shorter is not a lock. "Explicitly specified" means that lock or that pick.

This kit does not ship those product-style laws. WM-7 is the fit for the day the owner writes them. It is not a blank check.

### WM-8 - L20

A tool the owner names in the order is the lock for that turn. It is used. It is not opened as a chew. A tool a seat proposes is still a chew and a conversation before action.

### WM-9 - L14 and L16

The owner's sentence this turn is the move. A standing gate holds for every piece the sentence does not name. When the sentence names a piece a gate would refuse, the gate lifts for that piece only, and the lift is written in `NOW.LOG`. The rest of the gate stays. A puff by itself does not lift a gate and does not change the phase. The card remains what a cold seat returns to.

---

## 3. Where the scribe is visible

| Place | What it holds |
|---|---|
| This file | The nine marks. |
| [`../global/project-laws.md`](../global/project-laws.md) | The mark id on each joint. The law text stays the law. |
| Kernel `HEADS.WITNESS` | This path. Boot does not open it. |
| Kernel `LOCK WM` | The scribe is locked. |
| [`aa-sdd-cold-start.md`](aa-sdd-cold-start.md) | `ACTION` is one move. `LOG` is not a move. This file stays closed on boot. |
| [`../README.md`](../README.md) | The tour. If the tour and this file disagree, repair the tour. |

A new joint gets the next WM number in this file, a tail on the law rows it scribes, and a manifest row. A mark does not take an L-number. L33 is the check that decides whether a new law needs a mark.

---

## 4. When a law is added (L33)

When the owner adds a law, the clerk checks that law against the whole pile and against every mark in this file, in the same turn.

An ask that the new law and an existing law can answer in two ways is a joint. A joint gets the next WM number here, a tail on each law it scribes, and a manifest row, before the turn ends.

No joint means no new mark. The check is recorded here and in `NOW.LOG`. A mark is not minted to prove the check ran.

The check does not retarget `NOW.ACTION`. It does not open a bay. It does not boot a kit. Boot does not run it.
