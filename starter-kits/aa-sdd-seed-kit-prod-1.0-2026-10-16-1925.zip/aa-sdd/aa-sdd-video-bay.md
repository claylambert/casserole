# AA-SDD - picture pipeline

**Token:** `[VIDEO-BAY]`
**Frame:** [`aa-sdd-enir-spec.md`](aa-sdd-enir-spec.md)

This file is the root process for a picture pipeline. The startup report and older notes call that pipeline a bay. A bay is this pipeline, not a second project and not a theme. An instance of the pipeline lists only what is specific to that instance: title, names, looks, voices, clip count, and file paths. It does not restate this file. Do not fork this process into a second copy so that one instance can drift. Drift is how two pipelines start claiming the same frame and filing different stills under one name.

The pipeline runs only when the owner names it. The presence of this file is not that naming. A fresh session does not open a pipeline and does not generate a still.

## Order

The order is the requirement. A later step that runs before the earlier step has an input does not yet exist, and the file it produces cannot be tied back to a decision.

1. The narrative is accepted before any picture is made. Pictures illustrate a text that already exists. They do not discover the text.
2. Each frame is bound in EN-IR, so the frame has a requirement a later session can read without the conversation.
3. The storyboard. One still per frame, filed where the board can see it.
4. Clips, one at a time, only when the owner names that clip. Naming the pipeline is not naming every clip inside it.
5. Joined output, called a stitch in older notes, only when the owner names the join. Adjacent clips do not join themselves because they sit in the same directory.

A puff that does not name a frame is not an order for a new still. A locked still stays locked until the owner names that still. Approving the picture is not a request to edit it. The precise edit waits until the owner calls for the edit.

Spoken lines marked `[PRESERVE-ALL]` stay byte-identical. Description of the camera and the room may be added around those lines. The lines themselves are not paraphrased, tightened, or given a clearer reading. A clearer reading is a different line.

## Receipt

A filed storyboard frame carries the five-field receipt from [`aa-sdd-continuity.md`](aa-sdd-continuity.md) on the live phase card. A failed match is not filed. The missed attempt waits under a `.temp` name until the owner decides. It does not replace the live file. An infographic does not take this receipt. The receipt is for the storyboard frame, for a spoken line, and for a product build whose phase is that build.
