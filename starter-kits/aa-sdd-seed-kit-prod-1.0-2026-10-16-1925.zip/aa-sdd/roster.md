# Roster

**Boot:** [`aa-sdd-cold-start.md`](aa-sdd-cold-start.md) step 10.
**Worksheet:** [`../VisionStatement.README.md`](../VisionStatement.README.md)

This file is the roster a fresh session reads. The session prints the call block below, one line per seat, and then stops if any required name is still `UNNAMED`. The table under Seats is the duty record. The vision worksheet is where you draft the same names before you commit them here. A name counts only when that same spelling is written in both places. Two spellings of one person are two seats, and the next session will treat them that way. Until you write a name, the value stays `UNNAMED`. An assistant must not invent one.

Do not paste a narrative into this file. What the product is belongs in the product document. What remains to be built belongs in the working spec. A role that is not a row in the table stays inactive until you add that row. The startup report still uses two older words for this rule. Cast means this roster. Cameo means a role that is not on it. You do not need those words to fill the table. You do need to recognize them when the report prints them.

The words after each label in the call block are the duty in one line, so the report can copy the block without summarising it. They are not a second name, and they are not a theme. You can staff a seat with a person, point an assistant at the duty, or leave the seat `UNNAMED`.

## Call

```text
OWNER: UNNAMED. Human decision authority. Approves plans and may halt the work. Assistants must not speak for this seat.
CLERK: UNNAMED. Manages every file in plans/. Keeps links between spec files consistent. Holds private notes the owner does not read, and the session does not quote.
MECHANIC: UNNAMED. Keeps machines, parts, and pictures at the shape that was accepted, until a new version is accepted.
SPEAKER: UNNAMED. Delivers the agreed lines. Must not rewrite a line that has been locked.
NAVIGATOR: UNNAMED. Follows the connection the owner named. Must not join segments until the owner names the join.
COUNTER: UNNAMED. Keeps counts exact. Rejects a move that cannot occur in the stated environment.
CUTTER: UNNAMED. Performs a precise edit only when the owner calls for that edit. Approving a picture is not that call.
CODEBASE: the program. Follows the stamped plan. Not a person. Does not change while the live phase is a picture.
WORDSMITH: UNNAMED. Drafts tone and the next action line. The speaker delivers the words. Does not edit a locked spoken line.
```

## Seats

One row is one duty. The Bound column is the constraint that duty must not cross. The links are the procedure files that state the constraint in full. If this table and the vision worksheet disagree about a duty, this file is the record a fresh session reads, and the worksheet is corrected.

| Slot | Duty | Bound |
|---|---|---|
| OWNER | Names the work, approves plans, and may halt. | The human. Assistants must not speak for this seat. |
| CLERK | Manages every file in plans/. Keeps links consistent when a live file moves, and checks the five-field receipt before a picture-pipeline frame, a spoken line, or a phase build is filed. | Does not override the owner. The owner approves a plan and does not manage the plan files. Private notes: [`aa-sdd-seat.md`](aa-sdd-seat.md). Receipt: [`aa-sdd-continuity.md`](aa-sdd-continuity.md). |
| MECHANIC | Keeps machines, parts, and pictures at the accepted shape. | An accepted shape does not change until a new version is accepted. |
| SPEAKER | Delivers the lines that were agreed. | Does not rewrite a locked line. |
| NAVIGATOR | Follows the connection the owner named. | Does not join segments until the owner names the join. |
| COUNTER | Keeps counts exact. | A move that cannot occur in the stated environment is not filed. |
| CUTTER | Performs a precise edit. | Only when the owner calls for that edit. Approving a picture is not that call. |
| CODEBASE | The program. | Not a person. Follows the stamped plan. Does not change while the live phase is a picture. |
| WORDSMITH | Drafts tone and the next action line. | The speaker delivers the words. This seat does not edit a locked spoken line. |

Private notes for the record-keeper live only in [`seats/clerk/CHOICE.md`](seats/clerk/CHOICE.md). Do not create a private-note folder for any other seat until you name that seat and ask for the folder. A duty you wish a seat had, and have not written in this table, is not that seat's duty.
