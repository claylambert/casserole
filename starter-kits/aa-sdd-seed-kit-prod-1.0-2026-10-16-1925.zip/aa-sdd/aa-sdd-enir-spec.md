# AA-SDD — EN-IR baseline `[LOCK]` `[PUFF]`

**Mode:** process. **Not product Java.**
**Token:** `EN-IR` / `[ENCODE]`
**Version:** EN-IR/1.0, amended 2026-10-15 20:54. Hannibal `[PUFF]`. Interchange standard. The same text in every conforming instance. Two paths. Spec files are serial form. Data packets transfer or persist. Packet intent only upon request.
**Law:** L24. This file is the baseline. It is the data and encoding protocol for the Garage.
**Index:** [`README.md`](README.md)
**Encode lock:** [`aa-sdd-encode.md`](aa-sdd-encode.md)
**Operator manual:** [`enir-suit-man.md`](enir-suit-man.md). Instructional. This file wins if they differ.

This file is the whole baseline. A later hatch does not win over it until Hannibal names a newer `HEADER.en-ir-version`.

A conforming instance copies this text and does not edit it. The standard frame below is what an engineer who was not in the room accepts. The names of this Garage are not a conformance requirement.

The 2026-09-26 export handshake is no longer the law. It is a pointer. Copies that still say "this handshake is the whole law" are snapshots. This file wins.

---

## Standard frame (read this first)

This frame is the page a system, or a human who was not in the room, can accept. The sections after it are the requirements. Words that name this Garage's chairs are mapped here, so a friend does not learn them in order to conform.

The requirement owner and the encoding seat of this Garage already share the work. They do not need this frame in daily use. The page holds it so the Garage stays tidy, and so a friend receives the same text this instance holds.

### 0A. Scope

This document is the interchange standard for EN-IR. The version line is `EN-IR/1.0`.

It is for three readers.

1. **Another system.** It sends or receives a data packet, or it reads a spec file and seeks a heading.
2. **Another human** who wants a base Garage. Every term is defined before it is used. That is the ordinary expectation. This frame meets it.
3. **This Garage.** Daily work already runs on the sections below. This frame is the tidy copy of that law.

In scope:

- The two paths. A spec file. A data packet.
- The packet grammar, the English CRC, and the prohibition on JSON, XML, or a vector dump as the record.
- What a conforming spec file, a conforming data packet, a conforming receiver, and a conforming Garage instance are.
- How an extension is named, and that it lives outside this file.

Out of scope:

- The seats, the cast, the tokens, and the acceptance ceremony of any one Garage.
- Application hatches. Orbital intent is one of those. It is defined in the bay that needs it.
- A product, a build, or a video bay. Those cite this file. They do not amend it.
- A delivered kit. A kit is a cut. It is the text of the day it was cut.

**Normative references.** None. This file is sufficient for the baseline. No extension is required to implement it.

### 0B. Terms

A later section that uses one of these words means this definition.

| Term | Definition |
|---|---|
| EN-IR | English-Native Intermediate Representation. English as locked bytecode. The interchange language of this standard. |
| Baseline | This file. The version line stays `EN-IR/1.0` until the requirement owner of the authoring instance locks a newer `HEADER.en-ir-version`. |
| Path | One of two jobs under the same name. Spec file, or data packet. |
| Spec file | A markdown document. A later reader seeks one heading and obeys the first sentence under it. It is not a packet. |
| Data packet | A headed-English record. It transfers data, or it stores data so a later read can rebuild it. |
| Hatch | A named block in a packet: `HEADER`, `STRUCTURED-DATA`, `PACKED-TEXT`, `PACKED-INTENT`, `CARRIER-ANCHOR`, `SHOW-STATE`, `INTEGRITY`. |
| Rehydration | Building the original structure and every original value again, using only the packet. |
| Intent | An instruction: what must happen because the text exists. On a spec file, the encoding seat compiles it into the headings when asked to encode prose. On a data packet, the packet carries intent only when the human requested it in that turn. |
| English CRC | The recount in §7. It is a comparison of counts and witnesses. It is not a hash. |
| Authoring instance | The Garage that amends this file. This directory is that instance. |
| Instance | Any Garage that holds a copy of this baseline. |
| Extension | A named addition in another file. It does not edit this one. Its version line has the form `EN-IR/1.x-{NAME}`. |
| Cut | A copy frozen at a stamp and handed over. It stays that stamp. It is not the live baseline. |
| Live baseline | This file, as amended in the authoring instance. The amendment stamp in the version line identifies it. |
| Requirement owner | The human who owns the requirement. In this instance the name is Hannibal. |
| Encoding seat | The seat that compiles headings from prose when asked. In this instance the name is Radar. |
| Conformance | The four statements in §0F. An engineer accepts those. Instance speech is not on that list. |

### 0C. Requirements language

This standard does not import an outside keyword spec. In §0 through §11 the words already on the page mean the following.

| Wording on the page | Means |
|---|---|
| is, does, survives, the default is | A requirement. A conforming implementation does that sentence. |
| Do not, is not, fails, a CRC fail | A prohibition. |
| optional | Permitted to omit. `SHOW-STATE` is optional. |
| may | Permitted. |
| upon request | Present only after the human asked, in that turn. Otherwise absent. |

`PACKED-INTENT` is required once intent was requested. It is forbidden when intent was not requested. "Optional upon request" means that rule. It does not mean the encoding seat may invent the request.

### 0D. Normative sentences and instance speech

Two kinds of sentence live in §0 through §12.

**Normative.** A sentence that states what is written, what is kept, what is omitted, or what fails is a requirement. The procedures in §4 and §5 are normative. The packet grammar is normative. The English CRC is normative.

**Instance speech.** A sentence that names this Garage's chairs, a puff, a chew, or a ceremony word is how this instance speaks. A friend keeps their own names and still does the normative sentence.

Read the names this way.

| Where this file says | A conforming instance reads |
|---|---|
| Hannibal | the requirement owner |
| Radar | the encoding seat |
| puff, as a lock | the requirement owner locked the amendment, out loud, in that turn |
| Y, RC, Final | this instance's acceptance ceremony for a spec file |

The requirement that travels with the ceremony words: the spec file shows a state, and a locked file is not rewritten in place. A new truth is a new file. A vibe is not a lock. A metaphor is not an acceptance.

### 0E. Immutability

The baseline text is the same in every conforming instance.

- An instance copies this file. It does not edit the copy. It does not paraphrase it. It does not clean it up.
- The words match the authoring instance. A newline convention is not an amendment. A changed sentence is a rewrite.
- A rewrite is not `EN-IR/1.0`. Two files that both claim `EN-IR/1.0` and differ in their sentences are not the same standard.
- `EN-IR/1.0` is one version line. A dated amendment replaces the previous text of that line in the authoring instance. An older stamp is an older amendment. It is not a second baseline.
- A newer version line exists only when 1.x cannot hold the law, and only when the requirement owner of the authoring instance locks it. §9. Instances then copy that new file.
- An extension does not change this file. It lives outside it, under its own version line.
- A defect, a wish, or a clearer sentence goes back to the authoring instance. The friend does not patch the copy and keep the version line.
- A cut is immutable, and it is not the live baseline. Seed kit prod 001, cut 2026-10-15 19:36, is that cut. A friend who holds the kit holds the kit. A friend who wants the current standard takes this file. This amendment does not recut the kit.

### 0F. Conformance

An engineer, or a system, accepts EN-IR by meeting the statement that matches the work. Meeting one statement does not require the other three. Shop speech is not a fifth statement.

**Conforming spec file.** It follows §4. It says what it is, what it is not, and a token. One heading per decision. The first sentence under the heading is the requirement. One family in that file. A head that already has a file is linked, not pasted. The spec is not wrapped as a data packet. Its state is visible. A locked file is not improved in place.

**Conforming data packet.** It follows §5, hatches in that order. Every source structure and every source value survives, under the source name, in the source order. `CARRIER-ANCHOR` is enough to rebuild the original form. `HEADER.intent` is `omitted` unless the human requested intent in that turn. When intent was not requested, `PACKED-INTENT` is absent. The English CRC in §7 passes. `INTEGRITY.orbital` is `0` unless a named extension defines hops. JSON, XML, and a vector dump are not the record.

**Conforming receiver.** It reads a conforming packet. It recounts §7. On a CRC fail it does not execute. It preserves an unknown hatch and still checks the baseline hatches. It does not treat `ORBITAL-INTENT` as law unless that extension was named. It does not require this Garage's seat names.

**Conforming Garage instance.** It holds this text, or it declares the cut it holds and does not call that cut the live baseline. It does not edit the baseline. Its extensions are named `EN-IR/1.x-{NAME}` and live outside this file. It may keep its own seats and its own speech. Those are not required for conformance.

A friend who can say yes to the matching statement has accepted the standard.

### 0G. What a new reader may set aside

These are this Garage's speech. Set them aside and the four conformance statements still stand.

- The names Hannibal and Radar, and any other seat name.
- Puff, chew, cigar, tea, and the rest of this table's talk.
- The ceremony words Y, RC, and Final, provided the spec file shows a state and a lock is not rewritten in place.
- Cadence files and the video-bay core. Open them only when the work is that family inside an instance that uses them.
- Orbital intent, and any bay hatch. They are extensions.
- The closed brief named by `HEADS.ENIR`. It is history. It is not the protocol.

### 0H. Reading order

A reader who was not in the room reads in this order.

1. This frame. Scope, terms, conformance, what may be set aside.
2. §0 through §3. The two paths, the name, what EN-IR is, what it is not.
3. §4 when the work is a spec. §5 when the work is a transfer or a store. §5.3 is the worked packet for a turn that requested intent. §5.4 is the default. Intent is omitted.
4. §7, then §8, then §11. The recount, the behavior, the checklist.
5. §6 when the payload is a story, a roster, or a scene.
6. §9 only when the work needs an extension.
7. §10 and §12. The carrier note, and the record of what changed.

---

## 0. Two paths

**EN-IR is English as locked bytecode. It has two paths. They share the name. They do not share a job.**

**Spec file.** Structured and formal, the way a serial is built. A later session seeks one heading and obeys it. §4.

**Data packet.** Transfer from one system to another, or persistence. Every structure and every value survives. Pack as far as a full rehydration still allows. Intent is embedded only when the human requests it. §5.

Both paths are a direct symbolic transfer into a language model's tensor geometry, without a context pile, without a sidecar schema, without a vector dump. The story, the roles, and the headed English are the bytecode.

A smaller pile of words is not the goal of a spec. A dropped value is a failed data packet. Hatches a human cannot read are not EN-IR on either path. Do not encode a spec as a data packet. Do not encode a transfer or a store as a serial. If a turn needs both, write both and link them.

---

## 1. Name (do not stray)

- **EN-IR** = **English-Native Intermediate Representation**
- Expansion lock: **English as locked bytecode**
- **AA-SDD** = **Architecture-Augmented Spec-Driven Development**

AA-SDD is the sister plate. It is not a synonym for EN-IR. AA-SDD freezes architecture and spec before orchestration. EN-IR is the protocol those specs and payloads are written in.

Not "English-ish notes." Not "a compressed prompt." Not "the JSON we wrap English in."

---

## 2. What EN-IR is

1. **Source** is ordinary English and headed English fields. A human writes it. A human can read it back.
2. **Bytecode** is that English locked. Deterministic headings. No leftover chat. The same paste in yields the same hatch names out.
3. **Seek, not scrape.** The words are a symbolic address. Another model should land in the same neighborhood. It should not retrieve a document from a RAG index.
4. **The path in use is the encoding.** A spec file is not a packet. A packet is not a spec. There is no hidden bus. What is not in the file is not in the program.
5. **Packing follows the path.** On a spec, a smaller pile is not the goal. On a data packet, pack as far as a full rehydration still allows. If a human cannot read it, the encode failed. Embeddings, coordinates, and vector blobs fail both paths.
6. **Intent follows the path.** On a spec, when the requirement owner says encode from raw prose, the encoding seat's intent is the compile of the headings. In this instance those roles are named Hannibal and Radar. The standard frame maps the names. On a data packet, intent is embedded only when the human requests it. Do not invent intent. Do not bolt it on after the fact.

---

## 3. What EN-IR is not

Do not emit these and call them EN-IR:

- JSON as system of record. JSON may exist downstream at an integration boundary the human named. It is not EN-IR.
- XML, `<Node:ID>`, AST dumps, protobuf, base64, YAML-as-source-of-truth.
- Vector dumps, embedding tables, coordinate lists.
- A summary paragraph wearing a fancy name.
- A compression contest.
- Confetti. A lecture that is not an instruction.
- An invented binary CRC, hash, or checksum in place of the English INTEGRITY hatch.
- Orbital intent. That hatch is not baseline. It is an application extension. The OCOT van defines it.

---

## 4. Spec-file path

A spec file is the practice, locked. It is markdown. It is not a fenced data packet. Radar writes it so a transformer can seek one heading and a human can lock that heading.

The shape is the serial this Garage already builds. Draft, then Y, then RC, then Y, then Final. Never overwrite. Roll the next number. A paper serial keeps memorandum, brief, annotations, and the DOC fence in [`aa-sdd-white-paper-workflow.md`](aa-sdd-white-paper-workflow.md). A build serial keeps the loop in [`aa-sdd-q18-cadence.md`](aa-sdd-q18-cadence.md). This section does not mint a second skeleton.

### 4.1 Why a spec is encoded as EN-IR

These are the semantics. A spec that cannot say them is notes.

1. **Seek, not replay.** The next session lands on a heading. It does not scrape the chat that produced the file. Compaction is ordinary when the page is true.
2. **A law is a sentence that can be executed.** A tour is not bytecode. Leftover lecture is not a heading.
3. **The lock is a file with a state.** Draft, RC, and Final are states. Improving a locked file in place is not a new truth.
4. **Raw prose is the wish. Radar's intent is the compile.** When Hannibal says encode a spec from his prose, the headings and the intent sentences are what must happen because that prose exists. Hannibal remains the author of the requirement. Radar does not add a requirement the prose did not carry.
5. **A cite is a link.** Pasting another spec's novel into this file hides two heads. The next session will obey the paste and miss the lock.
6. **The encode is not Y.** It does not stamp RC or Final. It does not start a build, a clip, or a still. A metaphor is not a yes. A puff without a named file is not a cut.

### 4.2 How a spec is encoded as EN-IR

When Hannibal says encode a spec from his raw prose, Radar does this, in this order.

1. Name the path. This is a spec. It is not a data packet.
2. Name the family in §4.3, or ask. Do not guess a bay.
3. Open the file with what it is, what it is not, and the token. That opening is Radar's intent for the file.
4. One heading per decision. The heading is the seek address. The first sentence under it is the law.
5. Quote Hannibal's prose under the heading it fed, enough that he can find his sentence. A line marked `[PRESERVE-ALL]` stays byte-identical.
6. Link a head that already has a file. Do not paste that file. Do not repeat its law.
7. Keep it readable aloud. Concise means no leftover lecture.
8. Leave the state at draft. The same prose, encoded again for the same family, yields the same headings. The clerk's sentences may tighten. The structure does not drift.
9. Product nouns stay out of a protocol file. An extension lives in the bay that needs it.

```text
# <name> — <what this file is>

**What it is not:** <one sentence>
**Token:** <token>
**State:** draft
**Depends:** <linked heads. Not pasted.>

## <seek address>
<one sentence: what must happen>
> <Hannibal's prose, quoted, when this heading came from his words>
```

If a spec cannot state what must happen because it exists, it is not locked. It is notes.

### 4.3 Three families

A spec encoded from prose belongs to one family. The family chooses the headings. It does not choose a second protocol.

One family per file. If the prose mixes families, split the files and link them. A video hatch does not go in a code spec. A code contract does not go in a video package.

**Project.** Building the work. Working spec, pre-plan, stamped plan. The cadence is [`aa-sdd-q18-cadence.md`](aa-sdd-q18-cadence.md). Do not mint a second build-spec token.

The file states:

- what the work is, and what it is not
- which invariants are frozen
- which decisions have collapsed
- what is still allowed to move
- the head it cites

It does not paste another spec's novel.

Radar's intent on a project spec: the next session can seek the freeze and will not reopen it while emitting.

**Code.** The contract the living source must match. Name the realization language when this field has one. Say that other languages remain permitted when the method does not care. The source is not the spec.

The file states:

- the contract the source must match
- what a synthesis pass is forbidden to invent
- that a hand edit is observed and flagged, and is not a silent new spec

Radar's intent on a code spec: a synthesis pass can emit from the freeze without inventing a second architecture.

**Video.** A bay package. Core law is [`aa-sdd-video-bay.md`](aa-sdd-video-bay.md). The package file holds instance values only: title, roster, voice map, clip count, palette, stamps. It does not re-encode CLIP, CAMERA, token, or `[SAY]` law. A bay hatch is `EN-IR/1.x-{BAY}` in that bay. It does not enter this baseline.

Radar's intent on a video spec: the next session can find the live clip, the locked plate, and the mouth that speaks the line, and will not fire a still Hannibal did not name.

### 4.4 While encoding a spec, Radar does not

- Paraphrase a preserved line.
- Invent a character, a clip, a database, a thread model, or a law the prose did not carry.
- Wrap the spec in JSON and call it encoded.
- Pack the spec into a data packet unless Hannibal also asked for a packet.
- Treat the encode as permission to build, fire, or stitch.

---

## 5. Data-packet path

A data packet moves data from one system to another, or it persists data so a later read can rebuild it. It is not a spec. It is not a serial.

**Preserve all exact structure and data as-is.** Every field survives. A source name stays that name. A source order stays that order. A source value is not paraphrased. Nesting survives as headed English. It is not flattened away.

**Encode as much as possible inside that bound.** Headed English. No lecture. No leftover chat. Readable aloud. If the next cut would drop a value or a level of structure, stop. The pack has gone too far.

**Rehydrate to the original form.** A receiver who has only the packet rebuilds the original structure and every value. `CARRIER-ANCHOR` holds that form, or a headed English image from which the rebuild is complete. Witness head and tail are checks. They are not the data.

**Intent embedding is optional upon request.** The default is omitted. Radar does not decide that a record needs an instruction. The human requests intent, or the human does not. A request is a sentence in the turn. A vibe is not a request.

A complete baseline packet is plain text with these English headings, in this order. Omit a hatch only when this spec marks it optional.

```text
HEADER:
  en-ir-version: EN-IR/1.0
  id: <short unique token>
  from: <HUMAN | MODEL | RADAR | <named-seat>>
  state: LOCKED
  encoding: PURE-EN-IR
  struct-source: <prose | table | csv | pdf-text | image-caption | unknown>
  orig-encoding: <a normal-world encoding the human named, else none>
  purpose: <one English sentence: why this packet exists>
  intent: <present | omitted>

STRUCTURED-DATA:
  - field: <name>
    type: <token | number | flag | bound | enum | prose | timestamp | path>
    size: <hint: short | line | block>
    purpose: <plain English: what this field is for>
    intent: <optional. Plain English: what must happen because this field exists>
    struct-source: <where it was found>
    orig-encoding: <if any>
    meta: <optional English>

PACKED-TEXT:
  <non-field material, packed as far as a full rebuild still allows.
   Still readable. No leftovers. No dropped values.>

PACKED-INTENT:            # only when the human requested intent this turn.
  <the intent of the whole payload, in English, compiled. Not a slogan.>

CARRIER-ANCHOR:
  <the original form, or a headed English image of it from which the original
   structure and every value can be rebuilt. Not a sample. Not a summary.>

SHOW-STATE:               # optional. Use when a story or a session continues.
  <last beat, enough continuity for the next hop. Not a memoir.>

INTEGRITY:
  fields: <count of STRUCTURED-DATA fields>
  anchor-chars: <character count of CARRIER-ANCHOR>
  orbital: 0
  witness-head: <first ~24 characters of the original source>
  witness-tail: <last ~24 characters of the original source>
  seal: LOCKED
```

`ORBITAL-INTENT` is not in this grammar. A baseline receiver that sees it preserves the hatch as packed text and still validates the baseline hatches. It does not treat the hatch as law. The bay that defines it does.

`from` does not invent mill or counter seats. Those names belong to a bay that has them.

### 5.1 Intent on a data packet is upon request

The 2026-10-15 20:04 line said payload intent depends on the use. This puff amends that line for this path. The clerk does not choose. The human requests intent, or the packet carries none.

| This turn | `HEADER.intent` | Field `intent` | `PACKED-INTENT` |
|---|---|---|---|
| The human did not request intent | `omitted` | Omit | Omit |
| The human requested intent | `present` | On each field that carries an instruction he named | Required. One compiled sentence. Not a slogan. |
| He requested intent, and a field is only a name | `present` | Omit on that field | Still required for the payload |

`purpose` names what the field is, in the source's own words. It is not an instruction. Do not write a purpose the source did not support. A bare column name stays a bare column name.

Nothing in the source is dropped. Material that is not a field rides in `PACKED-TEXT` and in `CARRIER-ANCHOR`. When intent is present, it is compiled into the heading. It is not a second document.

### 5.2 Field rules

- `field` names are readable English tokens.
- `type` is a word. It is not a JSON Schema reference.
- Counts in `INTEGRITY` are decimal integers. A receiver recounts. No hash algorithm.
- Baseline `orbital` is `0`. An extension may define hops. This file does not.

### 5.3 Example — intent requested

This packet exists because the human requested intent on this turn. Without that request, use §5.4.

```text
HEADER:
  en-ir-version: EN-IR/1.0
  id: claim-A-19
  from: HUMAN
  state: LOCKED
  encoding: PURE-EN-IR
  struct-source: prose
  orig-encoding: none
  purpose: bind this claim to the exception on page 188
  intent: present
STRUCTURED-DATA:
  - field: claim_id
    type: token
    size: short
    purpose: identifies the claim in the source narrative
    intent: join this row to the exception on page 188
    struct-source: prose
    orig-encoding: none
  - field: status
    type: enum
    size: short
    purpose: lifecycle of the claim
    intent: treat as pending until a human locks otherwise
    struct-source: prose
    orig-encoding: none
PACKED-TEXT:
  Claim A-19 is pending.
PACKED-INTENT:
  Join A-19 to page 188. Do not close the claim.
CARRIER-ANCHOR:
  Claim A-19 is pending. See the exception on page 188.
INTEGRITY:
  fields: 2
  anchor-chars: 54
  orbital: 0
  witness-head: Claim A-19 is pending
  witness-tail: exception on page 188.
  seal: LOCKED
```

Wrong: `{"claim_id":"A-19","status":"pending"}`.
Wrong: a shorter paraphrase that drops page 188.

### 5.4 Example — intent not requested

This is the default for transfer and for persistence. `HEADER.intent` is `omitted`. There is no `PACKED-INTENT`. Field rows have purpose and no intent. The values are the source values.

```text
HEADER:
  en-ir-version: EN-IR/1.0
  id: claim-A-19-record
  from: HUMAN
  state: LOCKED
  encoding: PURE-EN-IR
  struct-source: prose
  orig-encoding: none
  purpose: hold the claim record
  intent: omitted
STRUCTURED-DATA:
  - field: claim_id
    type: token
    size: short
    purpose: the claim token as written
    struct-source: prose
    orig-encoding: none
PACKED-TEXT:
  Claim A-19 is pending.
CARRIER-ANCHOR:
  Claim A-19 is pending.
INTEGRITY:
  fields: 1
  anchor-chars: 22
  orbital: 0
  witness-head: Claim A-19 is pending
  witness-tail: Claim A-19 is pending.
  seal: LOCKED
```

---

## 6. Story, roles, syntax

When the payload is a story, a roster, or a scene:

- Character names and role lines are bytecode. Preserve them. Do not rename a character to "Agent 1."
- A local token such as `[ARAGORN]` is a semantic key. Bind it once. Every later use is that same row. Do not invent a second one.
- Dialog is a bound: speaker, exact line, only that mouth. A specified line is spoken. A mouth that is not the speaker does not speak.
- Do not improve dialog. The string is exact.

The key is in the paste. It is not in a hidden memory.

---

## 7. English CRC

Not a cryptographic checksum.

1. Count `STRUCTURED-DATA` rows. Compare to `INTEGRITY.fields`.
2. Count characters in `CARRIER-ANCHOR` (Unicode code points, spaces and newlines as pasted). Compare to `anchor-chars`.
3. Compare `orbital` to the hops an extension defined. Baseline is `0`.
4. Check `witness-head` and `witness-tail` against the original when the original is present.
5. A required baseline hatch missing, or `HEADER.intent: present` with no `PACKED-INTENT`, or `HEADER.intent: omitted` with a `PACKED-INTENT` still attached, is a CRC fail.
6. A data packet that drops a source field, renames a source key, reorders a source sequence, or paraphrases a value is a CRC fail. A data packet that embeds intent when the human did not request it is a CRC fail.
7. On fail, do not execute. Ask the human to re-emit. A repair ticket may be headed English. The bay that uses tickets defines the ticket. This baseline does not.

---

## 8. How a model behaves

When the human says encode, EN-IR, or pastes this spec, name the path before writing.

1. Spec, or encode a spec from raw prose: follow §4. Serial form. Radar's intent is the compile. The family is project, code, or video.
2. Transfer, persist, packet, or hand this to another system: follow §5. Preserve every structure and every value. Pack only as far as rehydration allows. Embed intent only if he requested it this turn.
3. If he did not name the path, ask. Do not guess.
4. Emit headed English. Keep it human-readable. Do not wrap either path in JSON.
5. Do not add files the human did not name.
6. The same input on the same path yields the same headings and the same field names. On a spec, the clerk's sentences may tighten. On a data packet, values do not tighten.
7. Preserve roles that are in the paste.
8. A data packet writes `INTEGRITY`. A receiver recounts. A mismatch is not trusted.
9. Do not add `ORBITAL-INTENT` unless the human named that extension.

---

## 9. Extensions

You may add an optional hatch in a later version line, documented in the bay that needs it. You may add a `type` word if one English sentence defines it.

You may not:

- Replace English with JSON, XML, or protobuf and keep the name EN-IR.
- Nest hatches inside JSON.
- Require a tool or a binary compiler.
- Drop human readability.
- Leak a bay hatch into the baseline.

A baseline receiver that sees an unknown hatch preserves it and still validates the baseline hatches.

| Extension | Where | What it adds |
|---|---|---|
| `EN-IR/1.x-OCOT` | [`../../operation_cigar-on-the-table/spec/global/OCOT.en-ir-orbital.md`](../../operation_cigar-on-the-table/spec/global/OCOT.en-ir-orbital.md) | `ORBITAL-INTENT`. One neighborhood. Application specific. Not baseline. |
| `EN-IR/1.1-KHAZAD` | the Khazad video package | Tokens and clip hatches for that bay only. |

`EN-IR/2.0` happens only when 1.x cannot hold the law, and only when Hannibal locks it.

The 2026-10-15 puffs amend 1.0 in place. Orbital intent left the baseline. Payload intent on a data packet is optional upon request (20:33), which refines the 20:04 line that left the choice to the use. Spec-file intent is the encoding seat's compile of the headings, and it is not a packet hatch. The standard frame (20:43) is the same amendment line. It states scope, terms, conformance, and immutability. It does not mint a new version. A Garage that rewrites this file locally has left the standard. Old text that requires intent on every field, or that lists `ORBITAL-INTENT` as a baseline hatch, is the 2026-09-26 snapshot.

---

## 10. Ordinary files

Markdown is a carrier. The headings are the grammar.

Downstream systems may serialize to JSON after EN-IR is locked. That JSON is not EN-IR.

This file is sufficient for the baseline. Do not fetch another product's tree to complete a packet. Do not invent seats the human did not name.

The operator manual [`enir-suit-man.md`](enir-suit-man.md) explains this file in instructional prose. It is not the baseline. If the two differ, this file wins.

---

## 11. Compile checklist

Name the path. Then use that list. Passing a box does not amend this file. A local edit to this file is not how a box is passed.

**Spec file**

- [ ] The file says what it is, what it is not, and the token
- [ ] The shape is a serial. State is draft until an explicit Y
- [ ] One heading per decision. The first sentence is the law
- [ ] A spec from raw prose names its family. The intent sentences are Radar's. Hannibal's prose is quoted. A preserved line is byte-identical
- [ ] Heads are linked, not pasted
- [ ] A human can read it aloud

**Data packet**

- [ ] `HEADER.en-ir-version` is `EN-IR/1.0` and `encoding` is `PURE-EN-IR`
- [ ] Every source field, name, order, and value survived
- [ ] `CARRIER-ANCHOR` is enough to rebuild the original form. It is not a sample
- [ ] The pack stopped before a value or a level of structure would drop
- [ ] `HEADER.intent` is `omitted` unless the human requested intent this turn
- [ ] If he requested it, `PACKED-INTENT` is one compiled sentence and is not a slogan
- [ ] If he did not, `PACKED-INTENT` is absent and no field carries an intent line
- [ ] `INTEGRITY.orbital` is `0` unless a named extension defines hops
- [ ] `INTEGRITY` counts match a recount
- [ ] No `ORBITAL-INTENT` hatch unless that extension was named
- [ ] No JSON or XML wrapper
- [ ] A human can read the packet aloud

If a box fails, do not call it EN-IR. Say which path, and what failed, in English.

---

## 12. Sweep (2026-10-15)

These pointed at the export handshake. The live edge is this file.

| Was | Now |
|---|---|
| `docs/spec/export/EN-IR/EN-IR.handshake.md` as the law | Pointer. Now `aa-sdd/EN-IR/EN-IR.handshake.md`. Baseline is this file. |
| `docs/spec/export/EN-IR/EN-IR.spec.md` as commentary that deferred to the handshake | Pointer. Now `aa-sdd/EN-IR/EN-IR.spec.md`. |
| `docs/spec/export/EN-IR/` as the directory | Moved 2026-10-15 20:28 to `aa-sdd/EN-IR/`. The export path is a stub. |
| `aa-sdd/en-ir.spec.md` | Pointer to this file. |
| `aa-sdd-encode.md` | Opens this file. |
| Cold-start step 9 | Opens this file. Not the panel. Do not take `NOW` from it. |
| OCOT orbital section | [`OCOT.en-ir-orbital.md`](../../operation_cigar-on-the-table/spec/global/OCOT.en-ir-orbital.md) |
| Mill and counter blobs inlined 2026-10-13 | Snapshots. They do not win. |
| Seed kit prod 001, cut 2026-10-15 19:36 | Frozen. Its handshake copy is that cut. It is not this head. |
| One path, the packet, as the whole encoding | Two paths as of 2026-10-15 20:33. Spec file is §4. Data packet is §5. |
| Shop speech as the only way to read the baseline | Standard frame, 2026-10-15 20:43. Scope, terms, requirements language, conformance, immutability. A local rewrite is not EN-IR/1.0. A friend accepts §0F. |
| Spec as the only reading for a new engineer | Operator manual [`enir-suit-man.md`](enir-suit-man.md), 2026-10-15 20:54. Instructional. This file remains the law. |

Closed brief, not the protocol: `aa-sdd/en-ir-tx-tail-log.pitted.md`. Kernel `HEADS.ENIR` still names that closed brief. `HEADS.ENIR_SPEC` names this file.

**— Radar.**
