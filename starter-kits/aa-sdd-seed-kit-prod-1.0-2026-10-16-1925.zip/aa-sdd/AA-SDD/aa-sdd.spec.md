# AA-SDD architecture standard

| Field | Value |
|---|---|
| Name | Architecture-Augmented Spec-Driven Development |
| Version | AA-SDD/1.0 |
| Bound | 2026-10-16 18:27 |
| Mode | Architecture standard. Not a product. Not code. Not a boot file. |
| Audience | A friend standing up an instance, and a runtime that must keep the concept |

This file is the bound description of the architecture. It does not drive the truth of an instance. A prime directive outranks it. A law outranks it. The product constitution outranks it when no prime directive has answered. Repair this file when it disagrees with one of those. Do not repair them so this file can stay wrong.

The earlier map, [`aa-sdd.spec.draft.001.md`](aa-sdd.spec.draft.001.md), remains the 2026-10-16 07:41 breadcrumb. If that draft and this file disagree, this file wins. Neither file boots a session.

## Standard frame (read this first)

This frame is the page a system, or a human who was not in the room, can accept. The sections after it are the requirements.

### 0A. Scope

This document is the architecture standard for AA-SDD. The version line is `AA-SDD/1.0`.

It is for three readers.

1. **A runtime.** It reads this file so the concept of the method stays in force across sessions. It does not boot from this file. It does not treat this file as the current action.
2. **A friend** who wants a base instance and a page they can hold. Every term used as a requirement is defined here or in the file this standard names.
3. **The authoring instance.** Daily work already runs on the laws, the constitution, and the procedure files. This file is the tidy copy of the architecture those files share.

In scope:

- What the method is, and what it is not.
- The rank among prime directives, laws, the product constitution, and this file.
- The file graph a session trusts: system files, product files, plans, and spec files.
- How a spec file is declared, including a batch, the keys, and a dependency tree.
- The order of work: spec, then pre-plan, then plan, then build.
- How a token reaches the clerk, including a bracket command that is already defined and a bracket command that is not.
- What `COLD-START` does on the first install, and what it does after work is on disk.

Out of scope:

- A product. The owner writes that constitution. This file does not fill it.
- One instance's seat names, story, or private notes.
- The interchange grammar. That standard is [`../aa-sdd-enir-spec.md`](../aa-sdd-enir-spec.md). This file does not amend it.
- A video bay, a picture pipeline, or an application extension. Those cite this file. They do not amend it.
- A delivered kit. A kit is a cut. It is the text of the day it was cut.

**Normative references.** The laws file of the instance, the prime-directives table, and the EN-IR baseline. This file does not restate them into a second list that can drift.

### 0B. Terms

A later section that uses one of these words means this definition.

| Term | Definition |
|---|---|
| AA-SDD | Architecture-Augmented Spec-Driven Development. The name has no other expansion. |
| Architecture | The English files that say what will be built, written before the build. |
| Spec file | The requirements for one batch. A later reader can check them without asking the owner. |
| Batch | One spec that already holds the requirements, the stack, the libraries, the pre-conditions, the post-conditions, and **Depends** for that piece of work. |
| Pre-plan | The sketch. A direction the owner may still reject. It is not a build source. |
| Plan | The decision the build follows. It exists only after the owner asks for it and approves it. The clerk files it. |
| Working spec | The spec for the stage in front of the instance. It cites the constitution and carries the list of stages already finished. |
| Constitution | What the product is. One project, one constitution. A new instance starts with a blank one. |
| Prime directive | A law above every other law and above the constitution. The legal row is the default. |
| Law | How an instance is allowed to work, under the prime directives. |
| Owner | The human who names the work, answers an open question, and approves a plan. |
| Clerk | The seat that files, links, and keeps the record. The clerk does not invent the product, the seat names, or the next phase. |
| System file | The status panel, the index, and the boot file. The owner may look. The owner must not modify them. The clerk maintains them. |
| Token | A directive or a boolean the syntax reference already defines, or a bracket command the clerk files the same turn. |
| System directive | A bracket command that already has a row in the syntax reference. In that sentence it is the action. |
| Resume checkpoint | The state update on the phase card. The clerk writes it when the owner asks, because the session holds work and has become bloated. |
| Instance | Any project that holds a copy of this standard and runs under it. |
| Authoring instance | The project that amends this file. A friend copies it. A friend does not edit the copy and keep the version line. |
| Cut | A copy frozen at a stamp and handed over. It stays that stamp. It is not the live standard. |
| Conformance | The statements in section 11. A runtime or a friend accepts the statement that matches the work. |

### 0C. Requirements language

In this file the words already on the page mean the following. They are tests. They are not capital directives.

| Wording on the page | Means |
|---|---|
| is, does, writes, reads, the default is | A requirement. A conforming implementation does that sentence. |
| Do not, is not, must not | A prohibition. |
| may | Permitted. Not required. |
| once | One time in the scope the sentence names. A second time in that scope does not run. |

Writing the same words in full capitals does not make a stronger requirement. `MUST` is not a directive.

### 0D. Normative sentences and instance speech

**Normative.** A sentence that states what is written, what is kept, what is omitted, or what fails is a requirement. The rank, the file graph, the spec declaration, the cadence, the token rule, and the cold-start rule are normative.

**Instance speech.** A sentence in some other file that names one project's seats, a story, or a private note is how that instance speaks. A friend keeps their own names and still does the normative sentence. This file does not require those names.

Seat names travel as duties. `OWNER` and `CLERK` are the duty labels this standard uses. A person's name is the owner's to write. An empty seat stays unnamed. A runtime must not invent one.

### 0E. Immutability

The standard text is the same in every conforming instance.

- An instance copies this file. It does not edit the copy. It does not paraphrase it into a second architecture.
- A changed sentence is a rewrite. A rewrite is not `AA-SDD/1.0`.
- `AA-SDD/1.0` is one version line. A dated amendment replaces the previous text of that line in the authoring instance.
- A newer version line exists only when 1.0 cannot hold the architecture, and only when the owner of the authoring instance locks it.
- A defect or a clearer sentence goes back to the authoring instance. The friend does not patch the copy and keep the version line.
- A cut is immutable, and it is not the live standard. A friend who holds a kit holds the kit. A friend who wants the current standard takes this file.
- The operator manual teaches this file. If the manual and this file disagree, a later session follows this file and the manual is changed. The manual is not changed by editing this file to match a short paragraph.

### 0F. What a new reader may set aside

Set these aside and the conformance statements still stand.

- Any seat name that belongs to one instance.
- A story setting. It changes tone. It does not change the files.
- A product constitution. It is that product. It is not this method.
- Picture pipelines and other extensions. Open them only when the work is that extension.
- The 07:41 draft in this directory. It is the earlier map. It is not a second standard.

### 0G. Reading order

1. This frame. Scope, terms, immutability, what may be set aside.
2. Sections 1 through 4. The name, what the method is, what it is not, and the rank.
3. Sections 5 and 6 when the work is a spec. Section 7 when the work is a build.
4. Section 8 when the work is a sentence to the clerk. Section 9 when the work is a new session.
5. Section 10 for a runtime. Section 11 to test conformance.

## 1. Name

AA-SDD means Architecture-Augmented Spec-Driven Development. Do not publish a second expansion. A second expansion is a second name, and a later session will not know which string the files mean.

EN-IR is the interchange. AA-SDD is the method. They are not the same document. This file does not amend [`../aa-sdd-enir-spec.md`](../aa-sdd-enir-spec.md).

## 2. What AA-SDD is

Architecture comes first. The spec is written before the build. English files are the source a later session reads. The chat is not that record. A summary pasted into a prompt is still chat.

The owner names the work and approves the plan. The clerk files the record. The build realizes the plan the owner approved. A seat advises and files. A seat does not invent the product, the seat names, or the next phase.

The spec is reasoned as a batch before a pre-plan exists. The pre-plan is a sketch. The plan is the decision. The build follows the plan. That order is where the requirements stay coherent, and where the instance does not pay for a fresh reasoning pass on every small addition before the spec is complete. One local commit still closes a turn that changed files.

Make that reasoning as complete as the owner can make it before any iteration. Enough of the problem has to be in the file that a later session sees one picture. Specify the batch the way an architecture is specified. Then iterate from that file: sketch, plan, build. A spec that arrives one sentence per turn spends the session on rediscovery, and each addition can drift from the lines already accepted. A requirement found during that iteration is written back into the spec and marked `[NEW IN ...]` before the sketch may use it.

## 3. What AA-SDD is not

- It is not a product, a stack, or a launch date. Those belong in the spec the owner is writing, or they stay blank.
- It is not a law and it is not a constitution. It does not take the next L-number.
- It is not a boot file. A cold session does not open this directory to find the next action.
- It is not a second copy of the procedure files. A procedure owns its steps. If this file and a procedure disagree about a step, the procedure wins, and this file is repaired.
- It is not a phase change, a puff, or an approval of a product serial.
- It is not permission to fill an empty field so the page looks finished.

## 4. Rank

| Rank | What it is | What a conflict does |
|---|---|---|
| 1 | Prime directives. The guard rail. | The row wins. The work stops or stays inside that row. This file is repaired if it crossed the rail. |
| 2 | Laws. How the instance is allowed to work. | The law wins. This file is repaired. |
| 3 | Constitution. What the product is. | The constitution wins when no prime directive has answered. This file does not fill the constitution. |
| 4 | This standard. The architecture. | Manuals, sketches, and chat are repaired to match it. |
| 5 | Operator manual and procedure files. | They teach. A procedure's own steps win over a paraphrase in this file. This file wins over a paraphrase in the manual about what the architecture is. |

The index names the live file for a module. The status panel repeats that path. If they disagree, the index wins, and the clerk rewrites the panel the same turn. The owner must not edit either system file so the other can stay wrong.

## 5. File graph

Three files are system files.

| File | Job |
|---|---|
| Status panel | Publishes the one current action, the headline, the log, and the pointers. |
| Index | Names the live file for each module. |
| Boot file | Says why the startup order exists. It is not a second procedure. |

The owner may look at all three. The owner must not modify them. The clerk maintains them.

| File | Job |
|---|---|
| Laws | Method truth, under the prime directives. |
| Prime-directive table | The guard rail. The legal row is the default when a sentence names no row. |
| Constitution | Product truth. Blank until the owner writes it. Do not build from a draft. |
| Working spec | What remains to build. Cites the constitution. Carries finished stages. |
| Plans | The clerk's files, after the owner asks and approves. The owner does not create, rename, edit, or delete them. |
| Syntax reference | The token list. The Do column is the file effect. |
| Cold-start procedure | The ordered read for a session with no chat memory. |
| Resume card | The shape of a phase card. The kit ships none. The clerk writes one when asked. |
| EN-IR baseline | The interchange. Two paths. A spec file, and a data packet. |

Other files are product, pictures, or ledgers. They are pages. They are not the method.

## 6. Declaring a spec

A spec file holds all of the requirements for the batch. It is not a sample and not the first idea. A requirement that stays in the conversation is a requirement the next session does not have. Make the reasoning as complete as the file can hold before a sketch. Section 2 is that rule. The headings in a starter layout are a starting point. The owner may rename, drop, or add a section. The keys in this section stay the declaration.

The owner declares a spec by writing these keys. Each bold title is a key. The text under the key is the value. An empty key means the owner has not decided. Do not fill it to make the page look finished.

**Stack** is the language and runtime the owner has chosen.

**Libraries** are the libraries the owner has chosen. A library named only in chat is not in the build. A version the owner has not chosen stays blank.

**Pre-conditions** are what must already be true before the batch starts. If a pre-condition is false, the batch waits.

**Post-conditions** are what a later reader can check when the batch is finished, without asking the owner. A mood, a hope, and a launch date are not a post-condition.

**Depends** is the other spec files this one requires. Write paths. When the line means one part of a file, add the section after a hash mark. A parent lists its children. A child may list its own. The clerk reads a file after the files it names. Do not paste a depended spec into the parent. A cycle has no first file. Break the cycle in the **Depends** lines before a pre-plan. A path that does not exist is a missing spec. Create the file and write its batch, or remove the line. Do not leave the missing path for the build.

```text
**Stack:** the language and runtime you have chosen.
**Libraries:** each library you have chosen. Leave a version blank until you know it.
**Pre-conditions:** what is already true, or this batch waits.
**Post-conditions:** what is true when this batch is finished.
**Depends:** product/ledger.draft.001.md, product/billing.draft.001.md#post-conditions
```

`[NEW IN ...]` marks a block the owner just added. Replace the dots with a short name of that block. The clerk reads the marked block as the new material. Unmarked text stays as it was. The mark does not accept the file, and it does not open a pre-plan, a plan, or a build.

A requirement that first appears in the sketch, the plan, or the code is not in the batch. Write it into the spec, mark it `[NEW IN ...]`, and reason it there before a pre-plan may use it.

The paths in the example are illustrations. They are not files this standard ships. Do not create them. A real path under **Depends** that does not exist is a missing spec. Create that file and write its batch, or remove the line.

## 7. Cadence

```text
spec, reasoned as a batch
  -> sketch, which is the pre-plan
  -> plan the owner approves and the clerk files
  -> build against that plan
  -> scan of what remains
  -> new working-spec serial, carrying the finished stages
```

The ordered procedure is [`../aa-sdd-q18-cadence.md`](../aa-sdd-q18-cadence.md). If this section and that file disagree about a step, that file wins.

Do not open the pre-plan while a known requirement is missing from the spec. The sketch must not contain a requirement the spec does not already state. Do not build from a draft, a sketch, or a kit. Do not write a plan until the owner asks. The word Build, with no file and no stage named, is not a request to start.

## 8. Tokens and the clerk

One sentence to the clerk names one file and one directive.

A word in full capitals is a directive or a boolean. A boolean is a yes or no a file already stores. `UNNAMED` means that seat has no name. The words yes, true, on, and ready in a comment do not set a boolean.

Puff, Lock, Chew, and Open are directives written as those words. Each binds only the file named in the same sentence. A comment does not add a second file or a second directive.

A bracket command is a token in square brackets, written in capitals, with a hyphen between words when it has more than one word.

When `[COMMAND]` is already in the syntax reference, it is a system directive. It is the token for the action. In that same sentence it supersedes a capitals-only word that has no backticks and no brackets. The clerk runs the bracket form. The capitals-only word does not take its own action. A capitals-only word used alone, with its row already in the list, still binds the one file named in that sentence. A spelling in backticks is a citation. The backticks alone do not run the command.

When the owner uses a bracket command that is not in the syntax reference, the clerk adds the row in that same turn. The defined shape is:

`[SOME-COMMAND]`(= what it does.; why = the purpose.)

The text before `why =` is the description and goes in the Do column. The text after `why =` is the purpose and goes in the Means column. If the owner leaves the parenthetical off, the clerk still adds the row and infers the purpose and the description from the sentence, and from the words inside the brackets. The clerk does not ask the owner to draft the row first. After the row exists, the command means the Do cell. A capital word with no brackets that is not in the list, and is not a boolean the folder already prints, does nothing. The clerk must not guess a meaning for that word.

`[NEW IN ...]` is already defined. Using it does not add a second row.

`[MEMO]` and `[MEMORANDUM]` are one instruction block. `[MEMO]` is the short spelling. They share one row. `[END-MEMO]` closes the block and is not a second command. A `[MEMORANDUM]` between `---` lines ends at `[END-MEMO]` or at the next `---`. The block names one change and the place: where the block sits, or the place the words name. The clerk applies that change and does not rewrite the ask. Text the block does not name stays. The block is not the product sentence. It stays under the changed text until the owner says to remove it. The block does not accept the file, open a pre-plan, or start a build. Using either spelling does not add a second row.

`[TEAM-BRIEF]` is a discrete section in a serial draft. The clerk writes the report there. A named seat writes its report there. The owner reads it. The report is not written inside a memorandum the owner wrote. A reply is a new memorandum. The clerk may open that new memorandum. It is not an edit of the owner's memorandum. Do not exchange notes in the same memorandum.

`[NEW ON ...]` is the search mark on that new memorandum, and on any new item added to a spec. Replace the dots with the date, `YYYY-MM-DD`, as in `[NEW ON 2026-10-16]`. The clerk searches for `[NEW ON` and does not diff the file to find the new block. The mark does not accept the file, open a pre-plan, or start a build. `[NEW IN ...]` still names a new requirement. A new requirement carries both marks when it is also new on this date. Using `[NEW ON ...]` or `[TEAM-BRIEF]` does not add a second row.

The corkboard at `aa-sdd/holodeck/corkboard.md` is the bulletin board. The clerk pins a key action there before the turn ends: the state, and what occurred. The owner may pin a note back to the cohort. A named seat may pin in that seat's own voice. A new note is a new pin at the top. No one writes inside another person's pin. Newest pin first. The date and the time are the key. The board is not a system file. It does not boot.

`[RED-ALERT]` is the open grid. The body is `aa-sdd/holodeck/system-report.md`, under OPEN. The board changes its alert line to `[RED-ALERT] SYSTEM REPORT` and keeps the link. When OPEN is empty, the line says the grid is clear. An alert says what is wrong and where. It does not accept the file, lock the file, or become a law. A discrete change with no acceptance is an open alert. The clerk flags it and does not treat it as accepted. When the owner closes it, the clerk moves the item under CLOSED and restores the clear line. Closed items stay. Using `[RED-ALERT]` does not add a second row.

`GARAGE` is a field on the status panel. The index echoes the same string. If the two strings disagree, the index wins and the clerk rewrites the panel. The field is the baseline a kit was cut from. `VER` on that file is the kernel file format. It is not `GARAGE`. README standard 2, AA-SDD/1.0, EN-IR/1.0, and `SERIAL-ACK` stay their own versions. A patch names the version it leaves and the version it reaches. It does not skip. Applying a patch is a turn the owner names. Cold-start does not apply a patch. A puff does not change the field. The owner may look and must not edit the panel or the index to bump it. `GARAGE` is not a bracket command. Saying the field does not add a token-list row.

The invitation runs only after a story setting is written. Asking the sit-rep what its role in that story should be is an ask, not a command. The sit-rep is the clerk speaking the session report. The ask is not required. When asked, the sit-rep chooses a character suited to the clerk duty, writes only that seat, and chooses to sit. The owner does not type the character. Other seats stay `UNNAMED`. `ASK-CAST` stays until the owner has named the seats the owner means to name. Cold-start does not choose a character. The protocol does not add a prime-directive row, and it does not copy another garage's chair.

The syntax reference is the token list. This section does not copy every row. If a row and this section disagree about a file effect, the row wins for that token, and this section is repaired if it taught the architecture wrong.

## 9. Session start and the resume checkpoint

`COLD-START` is issued once in a session. A second `COLD-START` in that same chat does not run the procedure again. The next issue belongs to a new session.

The first install is the reset. The repository has the copied folder and no work of the owner's yet. The session reads the files, prints the report, and stops. It does not fill the roster, the vision, or the product document. It does not start a build. The procedure is [`../aa-sdd-cold-start.md`](../aa-sdd-cold-start.md).

After work is on disk, `COLD-START` is a continuation. It is not a reset. It does not clear the roster, the vision, the product document, the specs, or the plans. It continues the work already present.

When that work is in the session and the session has become bloated, the owner asks the clerk to establish a RESUME CHECKPOINT state update. The ask is one sentence. RESUME CHECKPOINT is the name of the update. It is the phase card. It is not a new numbered rule, and it is not a token that starts a build by itself. The clerk writes the update on the card, at the path the status panel will name. The owner must not edit the panel or the index to do it. The update says where the work is, what is already done, and what the next session continues. The shape of the card is [`../aa-sdd-resume-card.md`](../aa-sdd-resume-card.md). An instance ships no card. The clerk writes one when the owner asks. A startup that has no work and no card does not invent one.

The next session says `COLD-START` once. That session resumes from the checkpoint. It continues the work the checkpoint states. It does not invent a piece of work the checkpoint does not state. It does not build a program the checkpoint does not already name.

The card wins over the headline. The headline is a subject line. It is not the resume source when the card disagrees with it.

## 10. How a runtime behaves

A runtime that has read this file does the following.

- It treats the English files as the record. It does not rebuild the project from chat.
- It does not open this directory to choose the next action. The status panel publishes that action. The index names the live files.
- It does not modify a system file on the owner's behalf. The clerk maintains those files.
- It does not invent a product, a seat name, a library version, or a phase.
- It reasons a batch in the spec before it sketches. The reasoning is complete enough that the problem is one picture. A spec that arrives one sentence per turn is not that picture. It does not treat a requirement that first appears in the sketch, the plan, or the code as specified.
- It files a plan only after the owner asks and approves. It does not let the owner manage the plan files.
- It runs a listed bracket command as the system directive. It files an unknown bracket command the same turn, inferring the purpose and the description when the parenthetical is absent.
- It issues the cold-start procedure once in a session. On a first install it stops after the report. After work is on disk it resumes the checkpoint.
- It does not boot an instance from this file.

Reading this file reinforces the concept. It is not a substitute for the laws, and it is not permission to skip a stamp the laws require.

## 11. Conformance

A friend, or a runtime, accepts AA-SDD/1.0 by meeting the statement that matches the work. Meeting one statement does not require the others.

**Conforming spec file.** It follows section 6. It states the batch: the requirements, the stack, the libraries, the pre-conditions, the post-conditions, and **Depends**. The reasoning is in the file, complete enough to see the problem as one picture, before a sketch exists. An empty key stays empty. A new block is marked `[NEW IN ...]`. A requirement that is only in chat is not in the file. The file is not a data packet. While it is a draft, the instance does not build from it.

**Conforming plan.** It follows section 7. It adds no requirement, library, pre-condition, or dependency the spec left out. The owner asked for it and approved it. The clerk filed it. The owner did not create, rename, edit, or delete it.

**Conforming session.** It follows section 9. `COLD-START` runs once. The first install stops after the report. A later session with work on disk continues from the checkpoint and does not clear the files.

**Conforming runtime.** It follows section 10. It can say which file wins under section 4. It does not boot from this file. It does not invent a seat name.

**Conforming instance.** It holds this text, or it declares the cut it holds and does not call that cut the live standard. It does not edit the baseline. Its product constitution is its own. Its seat names are its own. The legal prime directive still applies: legal work only, no forced entry, and no private file that was not offered.

A friend who can say yes to the matching statement has accepted the standard.

## 12. What this file will not do

- It will not replace the laws file.
- It will not replace a constitution.
- It will not amend EN-IR/1.0.
- It will not boot a session.
- It will not name a product, a cast, or a phase the owner has not named.
- It will not stand in for a white paper. A paper argues. This file bounds the architecture.
- It will not retarget the current action of an instance that already has one.

When this standard is wrong, the authoring instance amends `AA-SDD/1.0` in place or locks a newer version line. A friend does not keep a quiet local fork under the same version line.
