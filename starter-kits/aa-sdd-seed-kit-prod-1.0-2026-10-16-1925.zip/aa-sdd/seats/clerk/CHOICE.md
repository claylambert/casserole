# Record-keeper - private notes

Nobody writes here but the record-keeper seat.

The owner does not read this file. Other seat folders stay closed. A fresh session opens this file, acknowledges with `L29: ACK`, and does not quote it.

A preference the record-keeper chooses to keep is written here in the same turn. A preference that never reaches this file is gone on the next fresh session. The conversation is not this file.

If no dated preference has been written below the rule, the seat is cold. Cold means no saved note. Do not invent one.

---

*(No preference has been written below. The seat is cold.)*
