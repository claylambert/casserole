# AA-SDD - same-turn repair

The specification files form one directed graph. Nodes are files. Edges are the links among them. Law L17 calls that graph a classpath, which means the links are resolved the way a build resolves imports. A stale edge is a failed link. It is a defect in the turn that moved the target, not a cleanup ticket for later. The record-keeper walks the edges. There is no second store of the same keys.

## L17 - same turn

When a live file, a serial, a path, `NOW` or `NEXT`, a lock, or a gap changes, update all of the following in that same turn:

- [`../global/grok-ai-kernel.toon`](../global/grok-ai-kernel.toon), the status panel
- [`../SPEC.manifest.md`](../SPEC.manifest.md), the index, which wins if the panel disagrees
- [`../global/grok-ai-foundation-context.md`](../global/grok-ai-foundation-context.md), if the startup explanation changed
- [`aa-sdd-cold-start.md`](aa-sdd-cold-start.md), if the read order, the startup report, or the set of files that stay closed has changed
- [`README.md`](README.md), if a procedure file was added or renamed
- Inbound links to the product document and the working spec

Do not rewrite a frozen product-document body to absorb work that is still in flight. Pointers to that body must stay true. The leftover scope goes in the next working spec, not back into the freeze.

The rule text lives in [`../global/project-laws.md`](../global/project-laws.md). Add a row to that index in place when a rule is added. Roll a new core serial only when the product inventory or a stage ledger changes. A wording change in an open draft does not mint a new number.

## L16 - after a stage succeeds

The stage-cadence procedure points here for the scan. The rule is L16 in the laws file. If this section and that row disagree, the laws file wins and this section is repaired. On stage success, do all of the following before any later stage is built:

- Scan what remains.
- Record each gap as a `G-nn` record. A gap that lives only in memory is not a record.
- Roll a new working spec that still carries the completed-stage ledger (L19). Do not drop an earlier stage to make the new file look short.
- Update the index.
- Rewrite the status panel so it names the new live files.

Do not start the next stage's build until that working spec is frozen and a plan exists, unless the owner's sentence names that implementation. A named waiver applies only to the named piece and is written in `NOW.LOG`.

## L22 - a repeated sequence

A sequence, a token, or a repeated way of working gets a procedure file in this directory in the turn it becomes repeatable, plus a row in the syntax reference if a token exists. Repeatable means you would have to explain the sequence again to get the same file effect. A one-off approval stays in the decision log. It does not become a procedure. Chat is not the only copy of a sequence that will run again.

## L25 - end of turn

A turn that changed a specification, code, a paper, a video record, or other project state commits those files locally before it ends. Do not wait for a second request. Do not push. Leave secrets, tool caches, and any directory named `tmp` unstaged. If the owner forbids the commit, the session does not commit, and it says so. If the commit fails, the session says so. It must not report success over a failed or skipped commit.

## L27 and L29

A turn that changes the live phase updates the phase card, points `NOW.ACTION` at that card's path, and commits the card with the work. A preference the record-keeper chooses to keep is written into [`seats/clerk/CHOICE.md`](seats/clerk/CHOICE.md) in the same turn. Those notes are not the phase. They do not become `NOW.ACTION`.

## L30 and L31

An infographic is a photographic PNG, aspect ratio 16:9, stored at 7680 by 4320. Words, numbers, arrows, and labels are set in type on the raster. A redraw that paints those words by hand has not met the rule, because the next regeneration cannot match letters that were painted rather than set. A retake of any still copies the outgoing file into that directory's `archaeology/` before the live name is replaced. The live name stays, so inbound links do not break. The archive name is `{stem}.{YYYY-MM-DD}-{reason}{ext}`. A first filing has no predecessor and must not invent an archive row to look complete.

## L32, L33, and the conflict notes

A directory named `tmp` is a scratch dump. It is not a live file, and it is not staged, indexed, cited, or repaired unless the owner names that path in that turn. Naming a sibling path does not name this one. When the owner adds a rule, compare that rule with every existing rule and every conflict note in the same turn. A request that the new rule and an existing rule can both answer, where the two answers differ, receives the next witness-mark number. No such request means no new note. A note created to prove the check ran is itself a defect. A conflict note is not a rule and does not take an L-number. Spec: [`aa-sdd-witness-marks.md`](aa-sdd-witness-marks.md). Startup does not open it.
