# AA-SDD - integrity pass

**Token:** `[CLERK-SWEEP]`
**Not a startup. Not a rewrite.**

The owner orders an integrity pass. The record-keeper audits the file graph and reports what is still stale. The pass does not run at startup. A fresh session that sweeps "to see what is in the kit" has turned maintenance into orientation, and orientation belongs to the operator manual. This pass is how you check a tree you already know, when you ask for the check.

| Do | Do not |
|---|---|
| Audit live files named by the index against the files on disk. | Convert specifications into a private syntax tree, or into any form that becomes a second source. |
| Repair stale pointers in the same turn (L17). | Invent a second index or a second status panel. |
| Index a new procedure file in the turn it becomes repeatable (L22). | Move the rules, the operator manual, or a document the owner is still reading. |
| Move superseded serials into `{stem}.history/`. | Create a second archive tree beside `archaeology/` for the same stills. |
| Report what is still stale. | Claim the tree is consistent while a known bad edge remains. |

Leave other products, ingest folders, and event logs out of startup. The pass may notice they exist. It must not open them in order to boot, and it must not index them because they were nearby. A scratch directory named `tmp` stays out of the pass unless the owner named that path in the same request.
