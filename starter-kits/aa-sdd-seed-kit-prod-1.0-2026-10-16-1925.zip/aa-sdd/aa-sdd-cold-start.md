# AA-SDD - cold start

**Kit:** prod 1.0. Cut 2026-10-16 19:25. GARAGE 1.0. Not a boot.
**Token:** `COLD-START` / `[COLD-START]`.
**Why:** [`../global/grok-ai-foundation-context.md`](../global/grok-ai-foundation-context.md). That file explains the order. It is not a second procedure. If the two disagree, repair both in the same turn, and execute this list.

This file is the procedure a fresh session executes. A fresh session is a process with an empty memory. The conversation that produced the last decision is gone. The files are not gone. The status panel, file label kernel, is the first file, because it publishes the one next action. A memory index, a chat summary, and a pasted recap are not that panel. The short report at the end of the list is called a sit-rep. The report is the proof that the listed files were opened and that the session stopped. It is not a license to keep working.

Do not start from an event log. Do not load another product's tree. Do not take `NOW.ACTION` from the interchange standard, from its manual, or from the pointer under `en-ir/`.

The fenced list in section 0 is the executable contract. The prose around it tells a new reader what each line is doing. If the prose and the fence disagree, follow the fence and repair the prose. Do not "improve" the fence so that a clearer paragraph can stay wrong. Several words inside the fence are older labels. They still print, because the report is a fixed form. Read them with the meanings in the next section. You do not have to adopt the labels in your own sentences.

## How to read the list

The session reads eleven steps and then stops. It does not wander the tree looking for context. Context found that way becomes an order the owner never gave.

Step 1 opens the status panel and reads `NOW`, `NEXT`, `LOG`, `HEADS`, `LOCK`, and `FORBID`. `LOG` is on the panel so a human can see how the tree got here. It is history, closer to a build log than to a queue. Executing it replays decisions that have already had their effect. Step 2 opens the foundation file, which is why this order exists. Step 3 opens the index. If the panel and the index disagree, the index wins and the panel is rewritten in that same turn. Step 4 opens the rules through L33. Conflict notes, file label witness marks, are opened when one request can be answered two ways. They are not opened on this pass. Step 5 opens only the working-spec file the index names. Step 6 opens the do-not-build list and does not treat a row as permission. Step 7 reads the last twenty rows of the bug index and the feature index, not the trees of individual reports under them. Twenty rows are the recent edge. The whole tree is how a session invents a cause from ancient context.

Step 8 is the branch. `NOW.ACTION` is one line, and it is the only next move. If the line is `ASK-CAST`, the roster is still open. The fence says "the cast is still open." Cast means the roster. Do not invent names. If the line is a phase-card path, open that file, copy its phase into the report, and do not build from the card. If the line is `SIT` or `NO-BUILD` and it names one head, open the path on that head. Sit means stay with the phase and do not start new work. No-build means the phase is visible and implementation is refused. Head, in that line, is the live spec file, not the git HEAD commit. The card wins over the headline `NOW.WORK`. `LIVE` is a list of other card paths. Report them. Do not open them.

Step 9 sets the protocol. The default is EN-IR. The session opens the encode procedure, the baseline standard, and the operator manual for that standard. The baseline is copied whole and is not the panel. If the manual and the baseline differ, the baseline wins. Step 10 opens the roster and prints the call block, one line per seat. If any required slot is `UNNAMED`, the report waits on the roster. The fence says it waits on the cast, and it says not to call cameos. A cameo is a role that is not a row on the roster. Do not invent either. Step 11 opens only the record-keeper's notes at `aa-sdd/seats/clerk/CHOICE.md`. Do not quote the file. Do not open any other seat folder. The owner does not read it. If the file is missing, or it holds no chosen preference, the report marks the seat cold. Cold means no saved note. Do not invent one. Then the report prints `L29: ACK`. If the seat procedure cannot be opened, `L29` is `MISSING` and the startup stops.

The list ends with `reply(sit-rep)` and `stop`. Stopping is the success case. A session that continues into a plan or a program has failed the procedure, even when the extra work is useful.

---

## 0. Execute this

From the project root, in order. If a path is missing, put `MISSING` in the sit-rep and stop.

```text
COLD-START:
    1. global/grok-ai-kernel.toon
         NOW, NEXT, LOG, HEADS, LOCK, FORBID
         LOG is on the panel and is not a move
    2. global/grok-ai-foundation-context.md
    3. SPEC.manifest.md
         manifest wins over the kernel
    4. global/project-laws.md
         through L33
         witness marks are scribes, opened when a joint is hit, not on boot
    5. the working-spec path named by the manifest
         head only
    6. global/creepy-futures.md
         do-not-build list only
    7. last twenty rows, not the trees:
         bugs/bugs-fixed.md
         features/features-added.md
    8. NOW.ACTION is the only next move. It is one line.
         If the line is ASK-CAST, the cast is still open. Do not invent names.
         If the line is a resume-card path, open that file.
         If the line is SIT or NO-BUILD and names one HEAD, open the path on that HEAD.
         Put PHASE and the path on the sit-rep.
         The card wins over NOW.WORK.
         Do not read NOW.LOG as a move.
         Do not open the witness-mark file on boot.
         List LIVE. Do not open those paths.
         Do not build from the card.
    9. PROTOCOL. Default is EN-IR.
         aa-sdd/aa-sdd-encode.md
         aa-sdd/aa-sdd-enir-spec.md
           the baseline. Copied whole. Not the panel.
         aa-sdd/enir-suit-man.md
           the manual. The baseline wins if they differ.
    10. ROSTER.
         aa-sdd/roster.md
         Emit the Call block, one line each.
         If any required slot is UNNAMED, the sit-rep waits on the cast.
         Do not invent names. Do not call cameos.
    11. SEAT.
         Open only aa-sdd/seats/clerk/CHOICE.md
         Do not quote it. Do not open any other seat folder.
         The owner does not look.
         If the file is missing, or it holds no chosen nuance, SEAT is cold.
         Do not invent the memory.
         Then ack. Sit-rep line: L29: ACK
         Law: aa-sdd/aa-sdd-seat.md
         If that law cannot be opened, L29 is MISSING and the boot stops.
    reply(sit-rep)
    stop
```

If the roster is `UNNAMED`, stop after the sit-rep and ask the owner for the narrative frame, if one is wanted, and for one name on each open roster slot. That ask is required. The approval exchange comes after the names exist. Do not build either way. The fence above still prints cast and cameos. Cast means the roster. Cameos means roles that are not on it. The plain ask in this paragraph is the one you answer.

---

## 2. Sit-rep

```text
COLD-START
  PROJECT:
  STAGE:
  STATUS:
  ACTION:
  PHASE:    <resume-card PHASE, or none>
  CARD:     <path, or none>
  LIVE:     <other card paths, or none>
  NEXT:
  PANEL:    kernel agrees | manifest wins, kernel stale | card wins, WORK stale
  NAMED:    <owner's drawer this turn, or none>
  OPENED:   kernel, boot, manifest, laws, working head, encode, EN-IR baseline, roster, seat
  PROTOCOL: EN-IR | <only if the owner named another encoding this turn>
  ROSTER:   <the Call block, one line each>
  SEAT:     warm | cold
  L29:      ACK
  CLOSED:   novels, event log, other products, other seat folders, cameos
  WAITING:  cast | handshake. No build.
```

---

### What each report field means

The template above is the form. Fill the angle brackets. Do not add a second report beside it. The words in the `CLOSED` line and the `WAITING` line are fixed labels. Here is what a new reader should take them to mean.

`PROJECT`, `STAGE`, and `STATUS` are copied from the panel. On this kit the project is `UNNAMED`, the stage is `0`, and the stage status is `SEED`. The review-draft banner on this procedure is not one of those three fields. `ACTION` is the one line `NOW.ACTION`. `PHASE` is the phase card's phase, or `none` when no card exists. `CARD` is that file's path, or `none`. `LIVE` lists any other card paths and does not open them. `NEXT` restates the one thing the panel expects after the current move. It is not a backlog.

`PANEL` says whether the panel, the index, and the card agree. If the index wins, the panel is stale and must be rewritten. If the card wins, the headline is stale and must be rewritten. `NAMED` is the object the owner named in the sentence that started this turn, or `none`. The template calls that slot the owner's drawer. Read it as that named object. It is not an invitation to open an unnamed private folder. `OPENED` is the proof list: panel, startup explanation, index, rules, working head, encode procedure, EN-IR baseline, roster, and the record-keeper's notes.

`PROTOCOL` is `EN-IR` unless the owner named another encoding in this turn. `ROSTER` is the call block, one line per seat. `SEAT` is `warm` when a preference has been written in the record-keeper's notes, and `cold` when none has. Cold is an empty file, not a failure. `L29` is `ACK` when the notes were opened and not quoted. It is `MISSING` when the seat procedure itself cannot be opened, and then the startup stops.

`CLOSED` prints `novels, event log, other products, other seat folders, cameos`. Read that as five things the session did not open. Novels are narrative manuscripts. The event log is not a source of startup state. Other products are other trees. Other seat folders are every private-note folder except the record-keeper's. Cameos are roles that are not on the roster. `WAITING` prints `cast | handshake`. Cast means the roster names, if any slot is still `UNNAMED`. Handshake means the owner's next sentence, after those names exist. No build follows either wait.

## 3. After the sit-rep

The report is the end of startup. The rules below are what the next turn is allowed to do once you have named the work. They are not further startup steps. A session that treats this table as more files to execute before stopping has already left the procedure.

| Rule | Where |
|---|---|
| No build until the owner names the work. | Status panel `NOW.ACTION`. [`aa-sdd-handshake.md`](aa-sdd-handshake.md). |
| The phase card is the phase. | L27. [`aa-sdd-resume-card.md`](aa-sdd-resume-card.md). |
| The record-keeper checks the receipt before a picture-pipeline frame, a spoken line, or a phase build is filed. | L28. [`aa-sdd-continuity.md`](aa-sdd-continuity.md). |
| Specification before code. | L14. [`aa-sdd-q18-cadence.md`](aa-sdd-q18-cadence.md). |
| Links are repaired in the same turn a live file moves. | L17. [`aa-sdd-process-sync.md`](aa-sdd-process-sync.md). |
| Commit locally at the end of a turn that changed state. Do not push. | L25. |
| Legal work only. No forced entry. No private file that was not offered. The table is the list. This line is the legal row. A prime directive outranks the other rules and the product document. | L23. [`../global/prime-directives.md`](../global/prime-directives.md). |
| EN-IR unless the owner names another encoding. Two paths. The baseline is copied whole. | [`aa-sdd-encode.md`](aa-sdd-encode.md). |
| A preference the record-keeper chooses to keep is written into the record-keeper's notes in the same turn. | L29. [`aa-sdd-seat.md`](aa-sdd-seat.md). |
| An infographic is a 16:9 PNG at 7680 by 4320. Words are set in type. | L30. |
| A retake copies the outgoing still into `archaeology/` first. | L31. |
| A directory named `tmp` is a scratch dump. Do not index it unless the owner names that path that turn. | L32. |
| When the owner adds a rule, check for a joint. No joint means no new conflict note. | L33. [`aa-sdd-witness-marks.md`](aa-sdd-witness-marks.md). Not a startup step. |
| When one request reaches two rules, the conflict notes say which rule takes the load. | [`aa-sdd-witness-marks.md`](aa-sdd-witness-marks.md). Not opened at startup. |
| `[CLERK-SWEEP]` is an integrity pass. It is not startup. | [`aa-sdd-clerk-sweep.md`](aa-sdd-clerk-sweep.md). |
| `[CREATE-SEED-KIT]` exports a kit. It does not start this one. | Syntax row. |

---

## 4. Evolution

When an accepted change adds a file a fresh session must open or keep closed, or changes the startup report, update this file in the same turn. Add a pointer. Do not paste a narrative into the procedure. A story in the list becomes a second procedure the next session will try to follow.

---

## 5. Do not

- Treat a memory index as the status panel.
- Invent roster names, a phase card, or a record-keeper preference.
- Open paths listed on `LIVE`.
- Resume from the headline `NOW.WORK`.
- Build before the report and the owner's next sentence.
- Quote the record-keeper's notes on the `L29` acknowledgment.
