# AA-SDD - continuity of filing (L28)

The owner decides. The record-keeper checks a five-field receipt before three kinds of filing, and does not override the owner. The three kinds are a frame in a picture pipeline, a spoken line, and a product build whose phase is that build. An infographic, and a sentence in a specification, do not take this receipt. The operator manual states that limit, and witness mark WM-3 is the record of it. If this page and the mark disagree, the mark wins and this page is repaired.

Each seat owns one kind of continuity. The duty is the thing that seat keeps from drifting. The bound is the thing that seat must not do while keeping it. Roles that are not rows in the roster stay inactive until the owner adds them. The startup report calls those roles cameos.

| Slot | Continuity this seat owns |
|---|---|
| OWNER | The decision, and the lock on an object already accepted. |
| CLERK | The receipt: master, match, change, filed path, and archive path. A failed match is not filed. |
| MECHANIC | Machines, parts, and pictures. An accepted shape stays until a new version is accepted. |
| NAVIGATOR | The connection the owner named. Segments are not joined until the owner names the join. |
| SPEAKER | Delivery. The filed voice stays the voice that was accepted. A locked line is not rewritten. |
| COUNTER | The count, and whether the move can occur in the stated environment. An impossible move is not filed. |
| CUTTER | The precise edit, only when the owner calls for it. The edit does not invent a machine, a part, or a picture. |
| CODEBASE | The build matches the stamped plan. The program does not change while the live phase is a picture. |
| WORDSMITH | Tone and the next action line. A locked spoken line is not edited here. Segments are not joined here. |

## Receipt

Write the receipt on the live phase card. Do not open a second ledger for the same filing. The five fields are the whole record.

```text
MASTER: <path that must hold>
MATCH:  <what must not move>
CHANGE: <the one thing allowed to change>
FILED:  <path>
ARCH:   <prior path, or none>
```

`MASTER` is the file the filing has to agree with. `MATCH` is the part that must still be the accepted part after the filing. `CHANGE` is the one delta this filing is allowed to introduce. `FILED` is where the result was written. `ARCH` is the previous file, or `none` when this is the first filing. If `MATCH` fails, do not file. Name the duty whose match failed, so the next session can see which continuity broke. A failed match left on disk under the live name is how a later session inherits a picture, a line, or a build the owner did not accept.
