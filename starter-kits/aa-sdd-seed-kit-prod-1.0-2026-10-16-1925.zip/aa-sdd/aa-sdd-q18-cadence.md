# AA-SDD - stage cadence

Do not jump from a working spec to code. The build reads a stamped plan, and the English specification that plan cites. A draft, a sketch, and this kit are reading material. They are not an implementation source.

The operator manual calls the second stage a sketch. This file and the rules file call it a pre-plan. The build-sequence figure labels it Sketch. The three names are one stage: a direction you can reject before it becomes a plan. The filename pattern stays `*-pre-plan-stage-N.001.md`. Do not rename the pattern to the word sketch. A reader finds the file by the pattern. The meaning is the same either way.

```text
working spec → pre-plan → plan (owner approves, clerk files the plans/ copy) → build
      ↑                                                         │
      └── stage success → scan → new working-spec serial ──────┘
```

| Step | Artifact | Forbid |
|---|---|---|
| Working spec | `draft.NNN` → release candidate → `finalize` | Implement from a draft |
| Pre-plan | `*-pre-plan-stage-N.001.md`. The sketch. | Implement from a pre-plan |
| Plan | `*-plan-stage-N.001.md` plus `plans/YYYY-MM-DD_HHmm_*.md`. The clerk files the plans/ copy. | Build before the owner approves it. The owner does not manage the plan files. |
| Build | The code the plan names. `@aa-sdd` on new code only. | Later-stage work inside this stage |
| After-stage | L16 scan in [`aa-sdd-process-sync.md`](aa-sdd-process-sync.md) | Editing a frozen product document to absorb in-flight work |

The build may read four things: the stamped plan, the working-spec sections that plan cites, the rules, and the product-document sections the working spec cites. The English specification is the source of truth. The plan is the decision. Code is the realization of that decision. A build that also reads the conversation, a ticket comment, or a scratch directory has added a source the cadence does not allow.

A stage you skip is a stage the next session cannot reconstruct. The repository will then contain code that cites a decision it does not contain. The scan on success writes the gaps down as `G-nn` records so the next working spec inherits them as files, not as memory.
