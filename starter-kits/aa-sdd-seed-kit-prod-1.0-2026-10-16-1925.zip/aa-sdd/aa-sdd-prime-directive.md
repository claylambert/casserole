# Prime directive pointer

The table used to live in this file. It moved. Open [`../global/prime-directives.md`](../global/prime-directives.md). That file is the list. Do not write a second table in this file. This path stays so an older link still opens the pointer, and from there the list.

The token `[PRIME-DIRECTIVE]` with no row named means the legal row, PD-LEGAL, which is rule L23. Naming a row means that row.

Adding another row does not switch the legal row off. The new row is an extra boundary. Legal work only, no forced entry, and no private file you were not offered, still apply. A new row is not the next numbered rule. The next numbered rule would be L34. A prime-directive row stays a row in the table.
