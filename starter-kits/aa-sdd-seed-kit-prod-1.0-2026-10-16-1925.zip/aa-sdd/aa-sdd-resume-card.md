# AA-SDD - phase card (L27)

Chat is not state. The phase card named by `NOW.ACTION` on the status panel is the phase a fresh session returns to. The session opens that file, copies the phase line into its report, and stops. It does not build from the card. The card tells you where the work is. You name the next unit of work.

This kit ships no card. `NOW.ACTION` is `ASK-CAST`, which means the roster is still open. Do not invent a card at startup to fill the silence. An empty phase is an empty phase. The turn that makes a directory the live phase writes the card into that phase, points `NOW.ACTION` at the card's path, and commits the card with the work.

## Shape

The shape is the requirement. A card that drops a field, or that adds a second status panel inside the file, is not this card.

```text
PHASE:
WHEN:
BRANCH:
GIT: local only, unless the owner named a push
HEAD:
MODE:
```

Then three sections, in this order: where the work is, what is locked, and what is next. No second status panel. Do not paste a narrative into the card. The report template still uses the word novel for that refusal. A novel, in that line, means a narrative manuscript. The card is a phase record.

`PHASE` is the line the startup report copies. `WHEN` is the time the phase became live. `BRANCH` is the git branch the work sits on. `GIT` records that commits stay local unless the owner named a push in a separate sentence. `HEAD` sits beside those git fields, and a reader will want to put the commit id there. In this method the word head means the live spec file the index names, unless the line explicitly names a git object. On this card, write the live spec file. If you also need the commit id, write it on the `GIT` line and say that it is a commit id. One unlabeled string must not try to be both. `MODE` is the working mode of the phase, in the owner's words. Do not invent a mode to fill the blank. An empty mode is an empty mode. The verbs sit and no-build, when they are in force, are written on `NOW.ACTION`. They are not implied by an empty `MODE`.

## Rules

- Startup step 8 opens the card, copies `PHASE`, and does not build from it.
- The card wins over the headline `NOW.WORK`. If they disagree, say so in the report and rewrite `NOW.WORK` to the card in that turn. Do not rewrite the card so a more attractive headline can stay.
- `LIVE` lists any other cards. Startup reports those paths and does not open them. Opening every card "to be safe" turns the other phases into work the owner did not name.
- A crash before the commit returns to the last commit. Do not reconstruct the lost turn from habit, from the conversation, or from a scratch directory. The last commit is the state. The uncommitted edits are absent until they are committed, or until the owner says the commit is forbidden.
- In the same turn as the work: update the card, point `NOW.ACTION` at its path, set `NOW.WORK` to the same phase, update the index, and commit locally (L25). Do not push.
