# Plans directory

| Field | Value |
|---|---|
| Purpose | Hold a build decision after you approve it. This directory is the only place an approved plan lives. The clerk manages every file here. |
| Intent | The build must follow the file the clerk filed after you approved it. You must not manage these files. A suggestion, a sketch, or a shorter summary is not the plan. |
| Initial state | Empty. An empty directory is correct. Do not add an example plan so the directory is non-empty. |
| Rule | L14 in [`../global/project-laws.md`](../global/project-laws.md). |
| Terms | Defined in [`../README.md`](../README.md) section 4. Decision words are in section 9 of that manual. |
| Standard | README standard 2. LOCK 2026-10-16 19:25. Final for now. [Quick start](../README.md#quick-start). This file sits in the [tree](../README.md#tree-of-this-garage). |

A sentence that asks for a plan names the plan. It is not a capital directive called `PLAN`. Puff, in the operator manual, is a directive only for the file named in that same sentence. `Puff the roster.` does not file a plan. **Purpose** and **Intent** in the table above are keys. The value under the key is what the next session applies. Bold is not emphasis. The contract for capitals, booleans, and keys is [Normative language](../README.md#3-normative-language).

A plan follows a spec that already states the batch. It does not invent a requirement, a library, a pre-condition, or a dependency the spec left out. If the plan needs a line the spec does not have, that line is written into the spec first and marked `[NEW IN ...]`. The plan waits. The shape of the spec, including **Depends**, is [Write the spec](../README.md#write-the-spec).

A plan is the decision the build follows, and this directory is the only place that decision lives after you approve it. You do not get a file here until you ask for a plan. Asking is a sentence, in the same turn, that says you want one. A sketch, exploration notes, a conversation you have not approved in a sentence, and a puff that accepted some other file are not that request. `Puff the roster.` accepts the roster. It does not file a plan, and the clerk must not file one from that sentence.

When you approve the plan, the clerk copies the full text here. You do not copy it, rename it, edit it, or delete it. If you file the plan yourself, the next session can follow a file the clerk never recorded as your approval. You may read the file. You must not manage it.

A summary is not the plan. The build follows the bytes in the file, the way a pipeline follows the file that was committed rather than the shorter sentence someone typed in the ticket. If the summary and the file disagree, the file is what gets built, so the file has to be the decision you actually accepted. The operator manual's build path is [Build, the short form](../README.md#build-the-short-form). The gate on every stage is [Build sequence](../README.md#14-build-sequence).

The clerk writes the time you approved it into the file name:

`YYYY-MM-DD_HHmm_short-name.md`

`YYYY-MM-DD` is the date. `HHmm` is the hour and minute, zero-padded, so 9:05 is `0905`. `short-name` is a short label for the decision. With that stamp, sorting the filenames by alphabet is the same as sorting them by approval time. A renamed file that drops the stamp is no longer a plan name this directory can index. The decision may still be in the bytes, but a later reader can no longer find it by sorting.

![Build sequence. A plan exists only after the owner asks and stamps. Build is refused from a draft, a sketch, or this kit.](../figures/06-build-sequence.png)

*Map of the sequence this directory joins. The sentences on this page are the rule for a file stored here. The picture shows where a plan sits, between a sketch and a build. If the picture and this page disagree, follow this page.*

## What is not a plan

The four numbered items are keys for files that are not a plan. An open draft, a sketch, notes you marked chew, and a puff on some other file each stay what they are. Chew and Puff are the directives from the operator manual. They are not written here as new capital words. Do not put `PLAN` in capitals and expect the clerk to convert one of these four into a plan.

Do not use any of these as the source the build follows.

1. An open draft is still being revised. Saving it into this directory does not close it, and it does not approve it.
2. A sketch exists so you can throw a direction away before it becomes a plan. Throwing it away is a success. The moment a build follows the sketch, the gate between sketch and plan is gone.
3. Notes you marked chew stay notes. Chew is a decision word in section 9 of the operator manual. It keeps an exploration as notes. The clerk does not copy those notes here. You do not either.
4. A puff that accepted some other file accepted that file. Further edits to that file need a new decision. The puff did not accept anything in this directory. If you said `Puff the roster.`, the roster is accepted. A plan here is still unapproved. The clerk does not file a plan because the roster was accepted. You approve this plan in its own sentence, naming this plan, before any file in this directory counts as the decision the build follows.

## Which file the stage follows

The file name the stage cites is the key. A later clock in another file name is not a boolean that means "use this one instead." You do not say a capital word to make the newest file win. The sentence that approved the plan named the file. The build follows that file.

Do not build from a file in this directory until that file is the plan the clerk filed for the work you approved. You may read it. You must not manage it.

A newer time in the file name is not automatically the plan for an older stage. Sorting the names helps you find candidates. It does not pick one.

Say stage 2 was approved against `2026-10-16_0905_stage-2.md`. Later the same day the clerk files `2026-10-16_1400_stage-3.md` because you approved a different decision. The 1400 file is newer. Stage 2 still follows the 0905 file. The build does not switch to the later file because the later file sorts last.

The stage has to name its plan. The sentence that approved the work is what selects the file. If two stamped files could both be read as covering the same work, use that sentence. The other file remains the decision it actually was, for the work it actually named.
