# AA-SDD starter kit

| Field | Value |
|---|---|
| Document | Operator manual for this folder. Standard README for a seed kit. |
| README standard | 2. LOCK. |
| Status | Prod 1.0. Cut 2026-10-16 19:25. Locked README standard 2. This folder is a kit. |
| Version | README standard 2, carried on prod 1.0 |
| Date | README standard 2 locked 2026-10-16. Final lock 2026-10-16 19:25. Prod 1.0 cut 2026-10-16 19:25. |
| Method | Architecture-Augmented Spec-Driven Development (AA-SDD) |
| Audience | A developer or operator who already runs command lines and pipelines, standing up a new project from this folder |
| Start here | [Quick start](#quick-start), then the [tree](#tree-of-this-garage) |
| Normative sources | [`global/project-laws.md`](global/project-laws.md), then [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md) |

This manual is the runbook for a new project folder. The first day has one shape. You copy the folder into an empty git repository, you say `COLD-START` in a fresh session and let that session stop after its report, and you write only the facts you already know: the names in [`aa-sdd/roster.md`](aa-sdd/roster.md), the fields you can check in [`VisionStatement.README.md`](VisionStatement.README.md), and three sentences in [`product/constitution.draft.001.md`](product/constitution.draft.001.md). The session then ends. A plan, a program, and any edit to a system file are later work, and they are not how the folder becomes ready. Nothing has been built. The repository can take the next session.

AA-SDD is Architecture-Augmented Spec-Driven Development. The name has no other expansion. You record the architecture in English files before you implement, and those files are the source of truth a later session reads. The chat is not that record. A summary pasted into a prompt is still chat. The gist, and what EN-IR is for, is [What AA-SDD and EN-IR are](#what-aa-sdd-and-en-ir-are).

README standard 2 is the locked text of this manual. A kit copies this file so every new project starts from the same instructions. A prime directive is applied before the other rules and before the product document. The legal row is already in [`global/prime-directives.md`](global/prime-directives.md): legal work only, no forced entry, and no private file you were not offered. You add another row only when you mean another boundary. A new row does not take the next numbered rule. The next numbered rule would be L34, and a prime-directive row is not L34.

If this page and [`global/project-laws.md`](global/project-laws.md) disagree, a later session follows the rules file. Change this page. Do not change the rules file so that it matches this page. An edited rule becomes the method, and this page is then the text that is wrong. If this page and the product document you write disagree about what the product is, a later session follows the product document. The rules still decide how work is allowed to proceed. Do not write a method rule in order to settle a product question.

---

## Quick start

This is the path that stands a new project up. Run it in order, and stop at the end of the first session. The later chapters are the reference you open when a job names them. You do not read them to get started.

### What AA-SDD and EN-IR are

AA-SDD is Architecture-Augmented Spec-Driven Development. The name has no other expansion. The purpose is to write the architecture in English files before anyone builds it. A later session reads those files. It does not rebuild the project from the chat. The chat is not the record. A summary pasted into a prompt is still chat. The bound page is [`aa-sdd/AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md). It does not boot. Laws and the constitution remain the truth.

EN-IR is English-Native Intermediate Representation. The purpose is one interchange text that another copy of this method can read without inventing a second format. A spec file is serial Markdown a person reads. A data packet keeps every structure and every value, and it is transport. Intent on a data packet is written only when you ask for it on that turn. The two jobs are not the same file. The standard is [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md). [`aa-sdd/enir-suit-man.md`](aa-sdd/enir-suit-man.md) teaches it. If the manual and the standard disagree, follow the standard and change the manual. Do not edit the standard. This page does not restate the grammar.

AA-SDD is the method. EN-IR is the interchange. They are not the same document.

A serial moves one named file exactly one step. Say `SERIAL-ACK` in the same sentence as `product/billing.draft.001.md`. That path is an illustration. Do not create it. The clerk writes `product/billing.release-candidate.001.md` and leaves the draft. Say `SERIAL-ACK` again, in the same sentence as the release candidate. The clerk writes `product/billing.finalize.md` and leaves the candidate. Nothing skips the release candidate. The closed file stays on disk under its own name.

The build beside that ladder is a batch. You specify the work the way you would specify and design an architecture: the requirements, the stack, the libraries, the pre-conditions, the post-conditions, and **Depends**, reasoned in the spec until a later session can see the problem as one picture. Make that reasoning as complete as you can before you iterate. Enough of the problem has to be on the page that the picture is substantial. Then iterate from that file. The order is the spec, then the sketch, then the plan you approve and the clerk files, then the build. A requirement that shows up first in the sketch, the plan, or the code is written back into the spec and marked `[NEW IN ...]` before the sketch may use it.

Adding the work one sentence per turn spends the session on rediscovery. Each small addition can drift from the lines already accepted. Specify the batch. Then iterate. One local commit still closes a turn that changed files. The saving is that the reasoning happened in the spec, before the iteration.

The first session does not write this file. It still stops after the names, the vision fields you know, and three product sentences.

### Read a spec before you write one

Learning the shape is easier from a file that already has it. Before you write your own spec, open these and read the structure and the syntax. You are not filling them in on the first day, and you are not building from them.

- [`aa-sdd/AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md). A bound spec. Read how the sections and the keys are laid out.
- [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md). A bound spec for a format. Do not edit the copy.
- [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md). A starter layout for a module. The headings are a starting point. Adapt them to the batch. Drop a section you do not need. Add a section you do. They are not a law, and they are not your product. The values ship empty. Do not build from the draft.

The keys you type into your own file are [Write the spec](#write-the-spec).

A word in full capitals is a directive or a boolean. A directive is an action the clerk runs. `COLD-START` is issued once in a session. The first install is the reset. After work is on disk it resumes from the checkpoint. The contract is [Cold-start](#cold-start). `SERIAL-ACK` moves the one serial named in that same sentence exactly one version step. A bracket form that is already in the token list is the system directive. The next paragraph says how it supersedes a capitals-only word. Puff, Lock, Chew, and Open are directives too. They are written as those words, and each one still binds only the file named in the same sentence. A boolean is a yes or no a file already stores, also written in capitals so the next session can find that exact string. `UNNAMED` means that seat has no name. `ASK-CAST` means the roster is still open. The words yes, true, on, and ready in a comment do not set a boolean and do not run a directive. A capital word with no brackets that is not in the [token list](global/project-conceptual-syntax-reference.md), and is not a value this folder already prints, does nothing. The clerk must not guess a meaning for that word. `[NEW IN ...]` is the mark this page adds for a block you just wrote into a spec. Replace the dots with a short name of that block. The clerk reads the marked block as the new material and leaves the unmarked text as it was. The mark does not accept the file, and it does not start a pre-plan, a plan, or a build. It is already defined, so the clerk does not add a second row for it. `[MEMO]` and `[MEMORANDUM]` are one block already defined in [Mark a change while you iterate](#mark-a-change-while-you-iterate). `[END-MEMO]` closes that block and is not a command. Using either spelling does not add a second row. `[TEAM-BRIEF]` and `[NEW ON ...]` are already defined in [Read the team brief](#read-the-team-brief). `[RED-ALERT]` is already defined in [Pin the corkboard](#pin-the-corkboard). Using any of them does not add a second row. How a spec file is declared is [Write the spec](#write-the-spec).

A bracket command is a token in square brackets. Write it in capitals. Put a hyphen between the words when the command has more than one word. When the bracket command is already in the token list, it is a system directive. It is the token for the action. `[COLD-START]` names the same row as the capitals spelling, so the clerk does not add a second row. In that same sentence the bracket form supersedes a capitals-only word that has no backticks and no brackets. The clerk runs the bracket form. The capitals-only word does not take its own action.

You write: COLD-START `[LOCK]` the roster.

`[LOCK]` is already in the token list. It is the system directive. The clerk locks the roster. COLD-START is capitals only, with no backticks and no brackets, so the clerk does not also run the fresh-session procedure.

You write: COLD-START `[COLD-START]` the folder.

`[COLD-START]` is the system directive. The clerk runs the fresh-session procedure once. The bare COLD-START does not run it a second time. A spelling in backticks, such as the `COLD-START` this manual uses to show the word, is a citation. It is not the capitals-only form, and the backticks alone do not run the command.

When you use a bracket command that is not in that list, the clerk adds the row in the same turn. The defined shape is `[SOME-COMMAND]`(= what it does.; why = the purpose.). The text before `why =` is the description. The text after `why =` is the purpose. The clerk writes the command in the Token column, the purpose in Means, and the description in Do. If you leave the parenthetical off, the clerk still adds the row and infers the purpose and the description from the sentence the command sat in, and from the words inside the brackets.

You write: When the card is refused, `[RETRY-PAYMENT]`(= Charge the named order once more.; why = A refused charge gets one recorded second attempt, then it stops.).

The clerk adds this row before the turn ends.

| Token | Means | Do |
|---|---|---|
| `[RETRY-PAYMENT]` | A refused charge gets one recorded second attempt, then it stops. | Charge the named order once more. |

`[RETRY-PAYMENT]` in that table is the example. It is not a command this folder already ships. If you write only "When the card is refused, `[RETRY-PAYMENT]` the order once and then stop." and you leave the parenthetical off, the clerk still adds the row. The inferred purpose is one recorded second attempt, then stop. The inferred description is charge that order once and then stop. The clerk writes those two cells. The clerk does not leave the command absent, and the clerk does not ask you to draft the row first. After the row exists, the command means the Do cell. The sentence that introduced it is not a wider action. A build, a phase change, and a puff still need the words this manual already gives those jobs. A capital word with no brackets, such as `SHIP` or `MUST`, does not get a row. The long form is [Normative language](#3-normative-language).

A bold title is a key. The three keys under this heading are **Do this now**, **Skip until you need it**, and **Leave alone**. The sentences under a key belong to that key. Bold is not emphasis. If you bold a second title for a fact that already has a key, the next session will not know which key the files mean. One sentence to the clerk names one file and one directive. Name the file by its path, or by the bold key this manual already uses for that file. A comment after that sentence does not add a second file or a second directive. `Puff the roster. This is great.` accepts the roster. Great does not accept another file. The contract for these rules is [Normative language](#3-normative-language). If a sentence on this page is shorter than that section, follow that section.

### Mark a change while you iterate

**Skip this on the first day** is a key. The first session does not write a memorandum. Come back when a draft is on disk and you are changing a sentence in it. The long form is [Memorandum](#memorandum).

**Skip this on the first day.** A memorandum is how you and the clerk pass a change in the file. The chat is not that pass. `[MEMO]` is the short spelling of `[MEMORANDUM]`. They are one block. Close it with `[END-MEMO]`. The close is not a second command, and the short spelling does not add a second row.

Put the block where the change applies, or name the place inside the block. One block is one place. A second place is a second block. The words inside are the change. The clerk applies that change at that place. The clerk does not rewrite your ask into a different change. Text the block does not name stays as it is. The block is not the new sentence. After the change lands, the block stays under the changed text until you say to remove it, so the next session can see what you asked.

If the block says what the result should be, the clerk writes that result. If the block says the current text fails and asks for a reword, the clerk rewords that place so the failure is gone. If the block does not say what is wrong and does not say what the result should be, the clerk does not edit the surrounding text. The question is a new memorandum. Do not write it inside the memorandum that asked. You answer in another new memorandum. That is the back and forth.

A `[PUFF]` inside the block accepts that change. It does not accept the file, it does not advance a serial, and it does not start a build. A new requirement still belongs in the spec, marked `[NEW IN ...]`. A memorandum does not take its place.

```text
The charge retries forever.

[MEMO] [NEW ON 2026-10-16] The sentence above retries forever. Change it so a refused charge is tried once more and then stops. Apply that change to that sentence only. [END-MEMO]
```

The clerk changes the sentence above. The next paragraph stays. The memo stays under the new sentence until you say to remove it. The date in `[NEW ON 2026-10-16]` is the day that memorandum was written. A later note does not go inside it.

Use `[MEMORANDUM]` when the note covers the pass rather than one sentence. You may put that note between `---` lines at the top of the file. Close it with `[END-MEMO]`. If you leave the close off and the note sits between two `---` lines, the second `---` ends it. Mark that new memorandum `[NEW ON ...]` and put the date where the dots are.

### Read the team brief

**Skip this on the first day** is a key. The first session does not write a report. Come back when a draft is on disk. The long form is [Team brief](#team-brief).

**Skip this on the first day.** `[TEAM-BRIEF]` is a section of its own in a serial draft. The clerk writes the report there. A seat you have named writes its report there. A seat that is still `UNNAMED` does not write one, and the clerk does not invent a report for that seat. You read the section. The report does not go inside a memorandum you wrote.

Do not exchange notes inside one memorandum. A reply is a new memorandum, closed with `[END-MEMO]`, and marked `[NEW ON ...]` with the date of that turn, as in `[NEW ON 2026-10-16]`. The clerk may open that new memorandum when the note is a change back to you. The clerk searches the file for `[NEW ON` and reads those blocks. The clerk does not diff the whole file to find a new memorandum, or any other new item in a spec. Put the same mark on a new item you add to a spec. `[NEW IN ...]` still names a new requirement. A new requirement carries both marks when it is also new on this date. Neither mark accepts the file.

```text
[TEAM-BRIEF]
[NEW ON 2026-10-16]
The clerk changed the retry sentence only. The next paragraph was left as it was.

[MEMO] [NEW ON 2026-10-16]
The clerk asks where the second attempt is recorded. [END-MEMO]
```

The team brief is the report. The second memorandum is a new note. It is not a paragraph added to the first memorandum.

### Pin the corkboard

**Skip this on the first day** is a key. The board ships with no pins. The first session does not write one. Come back when a turn changes something the cohort should be able to read later without the chat. The long form is [Corkboard](#corkboard).

**Skip this on the first day.** The corkboard is the bulletin board for this garage. The file is [`aa-sdd/holodeck/corkboard.md`](aa-sdd/holodeck/corkboard.md). The cohort is you, the clerk, and any seat you have named. The clerk pins a key action there. A key action is a turn that changed a file. The pin states the state and what occurred. You may pin a note back to the team. A named seat may pin in that seat's own voice. A seat that is still `UNNAMED` does not pin, and the clerk does not invent a voice for it.

The pin shape is the instruction line at the top of the board. Copy that shape. Put the new pin above the older pins. The date and the time are the key. You read the top pin first. To trace a fault, read from the bottom upward. Do not reorder the board to make an old pin easier to find.

Pin as yourself. The clerk does not write your words in the clerk's pin. You do not add your note inside the clerk's pin. A note back is a new pin. A private note stays off the board. The board is not one of the three system files. You may write a pin. You still must not modify the status panel, the index, or the boot file.

Alerts live in [`aa-sdd/holodeck/system-report.md`](aa-sdd/holodeck/system-report.md). The board links that file and does not copy the alert into a pin. When nothing is open, the link says the grid is clear. When an alert is open, the clerk changes that line to `[RED-ALERT] SYSTEM REPORT`. The report says what is wrong and where. The alert is not a puff, not a lock, and not a law. A discrete change with no acceptance is that kind of alert. The clerk flags it and does not treat it as accepted. When you close it, the clerk moves the item under CLOSED and restores the clear line. The closed item stays.

### Read the garage version

**Skip this on the first day** is a key. You do not bump the version while you install. The long form is [Garage version](#garage-version).

**Skip this on the first day.** The garage version is the field `GARAGE` on the status panel, [`global/grok-ai-kernel.toon`](global/grok-ai-kernel.toon). The index, [`SPEC.manifest.md`](SPEC.manifest.md), echoes the same string. A session reads the panel first. If the two strings disagree, follow the index, and the clerk rewrites the panel. `VER` on the panel is the file format of the kernel. It is not `GARAGE`. README standard 2, AA-SDD/1.0, EN-IR/1.0, and `SERIAL-ACK` stay their own versions.

The string in `GARAGE` is the baseline this kit was cut from. The kit keeps that baseline. It does not follow a later change in the garage that cut it until you name a patch. A patch names the version it leaves and the version it reaches, as in `GARAGE/1.0` to `GARAGE/1.1`. It does not skip. You name the patch in a turn. The clerk writes the new value on the panel and the same string on the index. Cold-start does not apply a patch. A puff does not bump the field. You may look. You must not edit the panel or the index. `GARAGE` is a field. It is not a bracket command, and saying it does not add a token-list row.

### Ask the sit-rep

**Skip this on the first day** is a key. The first session does not ask. Come back after a story setting is written. The long form is [Invitation](#invitation).

**Skip this on the first day.** The sit-rep is the clerk speaking the session report. Once the story is defined, you may ask the sit-rep what its role in that story should be. The ask is not required. It improves how the garage runs. It is an ask, not a command. You do not assign the character. You do not type the name.

When you ask, the sit-rep chooses a character best suited to its own duty relative to the project, and it chooses to sit. The duty label stays `CLERK`. The sit-rep writes that character on the clerk seat only. Every other seat stays `UNNAMED` until you name it. `ASK-CAST` stays open until you have named the seats you mean to name. If the story setting is still empty, do not ask. The protocol does not run, and the garage still works.

**Do this now.** [Install](#install) the folder and make one local commit. [Cold-start](#cold-start) a fresh session and let it stop. Read [Five facts](#five-facts-before-you-build) so you know which files you write. Then run [First session](#first-session-the-short-form) and end it.

**Skip until you need it.** [Later sessions](#later-sessions-the-short-form) and [Build](#build-the-short-form) are here so you can see the gate before you reach it. You do not run them on the first day. When you are changing a sentence in a draft, the mark is [Mark a change while you iterate](#mark-a-change-while-you-iterate). When a draft needs a report back, the section is [Read the team brief](#read-the-team-brief). When a turn should leave a log the cohort can read, the board is [Pin the corkboard](#pin-the-corkboard). When you want the baseline this kit was cut from, the field is [Read the garage version](#read-the-garage-version). When a story is written and you want to ask the sit-rep about its role, the ask is [Ask the sit-rep](#ask-the-sit-rep). [Dig when you need it](#dig-when-you-need-it) is the index of the long sections. The [tree](#tree-of-this-garage) is the file index. Open either one when you need a path, not as a tutorial. Sections 11 through 17 wait until a file is ready to version, a picture is ready to file, or a build is ready to start.

**Leave alone.** Three system files ship in the copy. The status panel publishes the one next action and the field `GARAGE`. The index names the live file for each module and echoes that same string. The boot file says why the startup order exists, and it is not a second procedure. You may read them. You must not modify them, and you must not edit `GARAGE` to bump the number. The clerk maintains them. The short form is [Read the garage version](#read-the-garage-version). This quick start does not describe the panel lifecycle. That procedure is [Steady state](#10-procedure-steady-state-session), and it is a later session.

Each step below either tells you to write a named file or tells you to leave a named file alone. Do the write. Leave the other file alone. When a later section repeats a step, it is the same step with the failure case written out. The pictures are maps of the steps. If a picture and a step disagree, the next session follows the step written here. Change the picture. Do not change the step so the picture can stay as it is, unless you have decided the step itself was the mistake, and then change the picture to match that corrected step in the same turn. If the step and [`global/project-laws.md`](global/project-laws.md) disagree, the next session follows the rules file. Change the step. Do not change the rule so that it matches the step. An edited rule becomes the method, and the step you preferred is then the text that is wrong.

### Install

The five steps below are shell actions you run yourself. `git init` is a command in the shell. It is not a capital directive to the clerk. Do not invent a capital word that means "install." The paths in the steps, including `docs/spec/README.md`, are the addresses the next session opens. A heading on this page is a key. Do not rename it. A renamed heading is a link the next session will not find.

Install puts this folder at one path in an empty repository and stores that copy in one local commit. It does not name the product, and it does not start a build.

1. Create a new directory and run `git init`. Empty means the repository has no application source, no borrowed product document, and no second specification tree. A repository that already holds another product is the wrong target. Start clean so the next session cannot mix the two.

2. Copy this folder so its contents are the contents of `docs/spec/`. When the copy is right, `docs/spec/README.md` is this manual. Do not nest the kit in an extra directory under `docs/spec/`, do not rename a file or a directory, and do not place a second specification root beside `docs/spec/`. The paths in this manual are the addresses a later session opens. A renamed file is a file that session will not find.

   The copy includes three system files. `docs/spec/global/grok-ai-kernel.toon` is the status panel and publishes the one next action. `docs/spec/SPEC.manifest.md` is the index and names the live file for each module. `docs/spec/global/grok-ai-foundation-context.md` is the boot file. It explains why the startup order exists, and it is not a second procedure. The clerk maintains those three files. You may open them to confirm the copy landed. You must not modify them. What each file is for, and what happens when the panel and the index disagree, is in [Definitions](#4-definitions).

3. Leave every blank empty. Do not type another project's name, story, or code into a worksheet, a roster cell, the product document, or the corkboard. The corkboard ships with no pins. Leave it that way. The first names in those files have to be names you write in the first session, after cold-start. A sample typed now becomes the product the moment another file quotes it. The section headings already in [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md) are the starter layout. Leave them. Do not fill the values during install, and do not delete the headings to make the file look blank.

4. Do not commit a directory named `tmp`, at any depth. That name is a scratch dump. Mentioning it in chat does not make it source, and naming some other path does not name this one. Do not push. A push publishes the repository, and install has not asked for that.

5. Make one local commit of the copied tree. That commit is the snapshot a fresh session reads. It does not fill the roster, the vision fields, or the product document, and it does not approve a product or cut a release.

You already have the three skills this path uses if you run pipelines. You can read Markdown, because a heading on this page is an address and a renamed heading breaks the link. You can follow a path from this page to a file. You can make a local git commit, because the end of a turn stores state where the next clean session can see it. Pushing that commit is a separate decision.

### Cold-start

The directive in this section is `COLD-START`. Say that string in a fresh session. "Please start" and "boot the project" are ordinary words. They do not run the procedure. The report the session prints is proof that the listed files were opened. It is not a boolean you set by answering the report, and it is not approval. You must not edit the three system files so the report looks finished.

Cold-start proves the commit is readable by a session that has no memory of the copy. Do it before you write the roster, the vision fields, or the three product sentences. The report is the proof. It is not the moment those fields get filled.

1. Open a fresh session on the new repository. A fresh session is a new chat with no memory of the one that copied the folder. A summary pasted into that chat is still the old conversation, and the session must not treat it as the record.

2. Say `COLD-START` once. On the first install the session runs [`aa-sdd/aa-sdd-cold-start.md`](aa-sdd/aa-sdd-cold-start.md) and then stops. The report it prints, called a sit-rep, proves the listed files were opened and that the session did not continue into a build. It does not fill the roster names, the vision fields, or the three product sentences. It does not start a build, and it is not approval. You write those fields after the report, in the first session below. The long form of this stop is under [Fresh session](#4-definitions). After work is on disk, the same word resumes. The paragraphs under step 3 are that continuation.

3. You may read the report, and you may read the three system files to see that the session found them. You must not modify those files. The clerk maintains them. A change made so the panel "looks ready" is the change this step forbids.

`COLD-START` is issued once in a session. A second `COLD-START` in that same chat does not run the procedure again. The next issue belongs to a new session.

The first install is the reset. The repository has the copied folder and no work of yours yet. The session reads the files, prints the report, and stops. You then write the names, the vision fields you know, and three product sentences. That stop is [First session, the short form](#first-session-the-short-form).

After work is on disk, `COLD-START` is a continuation. It is not a reset. It does not clear the roster, the vision, the product document, the specs, or the plans. It continues the work already present.

When that work is in the session and the session has become bloated, ask the clerk to establish a RESUME CHECKPOINT state update. The ask is one sentence. RESUME CHECKPOINT is the name of the update. It is the phase card. It is not a new numbered rule, and it is not a token that starts a build by itself. The clerk writes the state update on the card, at the path the status panel will name. You must not edit the panel or the index to do it. The update says where the work is, what is already done, and what the next session continues. The shape of the card is [`aa-sdd/aa-sdd-resume-card.md`](aa-sdd/aa-sdd-resume-card.md). The kit ships no card. The clerk writes one when you ask. A startup that has no work and no card does not invent one.

You then open a new session and say `COLD-START` once. That session resumes from the checkpoint. It continues the work the checkpoint states. It does not start the project over. It does not invent a piece of work the checkpoint does not state. Cold-start does not apply a garage-version patch, and it does not choose a character for the sit-rep. Those are later turns you name. The contracts are [Garage version](#garage-version) and [Invitation](#invitation).

### Five facts before you build

`UNNAMED` is the boolean for a seat that has no name. Replacing that string with a name you mean is the write. Do not invent a capital token to stand in for a person. The bold labels on the vision worksheet, such as **Name** and **Done looks like**, are keys. Write the value on the key you mean. A value written under the wrong key is the value the next session will quote for that key. Puff, Lock, Chew, and Open, in the table below, are directives. Each one needs the file in the same sentence.

These five rows are the only product files the first days touch. The first three are the first session. The working spec waits until you intend to build. The plan waits until you ask for one, and the clerk files it. You approve the plan in a sentence. You do not create, rename, edit, or delete the file. The directory rule is [`plans/README.md`](plans/README.md).

| What | Where it lives | What you do |
|---|---|---|
| Your names | [`aa-sdd/roster.md`](aa-sdd/roster.md) | Replace `UNNAMED` with a name you mean. A seat you have not decided stays `UNNAMED`. A made-up name becomes a second person the moment another file cites it. |
| The frame, and the fields you know | [`VisionStatement.README.md`](VisionStatement.README.md) | Write a story setting only if you want one. Fill the project name, who it is for, and a checkable meaning of done when you know them. Leave a field blank until you do. |
| The product, in three sentences | [`product/constitution.draft.001.md`](product/constitution.draft.001.md) | Write three sentences that say what the product is. Do not build from this draft. |
| Remaining work, when you mean to build | [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md) | The headings are a starting layout. Read them when you want the shape. Leave the values empty until you intend to build. Adapt the headings to the batch. They are not a law. The file keeps the list of stages you have already finished. Do not build from it while it is still a draft. |
| A plan, only after you ask | [`plans/`](plans/README.md) | Empty is correct. You ask, then you approve. The clerk files the full text as `YYYY-MM-DD_HHmm_name.md`. You do not create, rename, edit, or delete a file in that directory. |

The three system files stay where the copy put them. You may look. You must not modify them. The field `GARAGE` on the panel is the baseline. Looking at it is allowed. Editing it is not. The clerk keeps them consistent with the live files.

A head, in this manual, is the live spec file the index names for a module. It is not the git HEAD commit you just made. Committing does not by itself change which spec file is the head. When that live file changes, three updates happen in the same turn, in this order. The clerk writes the new path into the index, [`SPEC.manifest.md`](SPEC.manifest.md), because that row is the path a later session treats as live. The clerk then rewrites the same path on the status panel, because the panel repeats the index and a stale repeat sends the next session to the old file. The clerk then updates every other link that still names the old path. You must not edit the index or the panel. Both are system files. You must not edit the index so it matches a panel that still names the old file. That edit makes the old file the live one. The worked example, including a procedure that repeats the path a third time, is [File graph](#62-file-graph).

A decision word changes one file, the file named in the same sentence, and it changes that file only in the way the word is defined. `Puff the roster.` accepts the roster. Further edits to the roster need a new decision. The product document is not accepted, a plan is not accepted, and a build does not start. A word in an earlier sentence does not apply to a file you name now. If you puffed the roster last turn and this turn you name the working spec without saying Puff again, the earlier Puff stays on the roster. Say Puff again, in the same sentence as the new file, when you want the new file accepted.

A comment is not a second instruction. `Puff the roster. This is great. Ship it.` is still one puff, on the roster. The words great and ship do not cut a release, do not move a version forward, and do not allow a build. A second result needs a second sentence, and that sentence names the file. The same rule applies to Chew. `Chew the notes. This is great.` leaves the notes as notes. Great does not accept them and does not start a build. The full table, including what each word must not do, is [Section 9](#9-decision-words). The token list is [`global/project-conceptual-syntax-reference.md`](global/project-conceptual-syntax-reference.md). A bracket command that is not in that file is filed by the clerk in the same turn. The shape, and what the clerk infers when you leave the parenthetical off, is [Normative language](#3-normative-language). `[NEW IN ...]` is already defined in [Write the spec](#write-the-spec). Using it does not add a second row. `[MEMO]` and `[MEMORANDUM]` are already defined in [Memorandum](#memorandum). Using either spelling does not add a second row. `[TEAM-BRIEF]` and `[NEW ON ...]` are already defined in [Team brief](#team-brief). `[RED-ALERT]` is already defined in [Corkboard](#corkboard). Using any of them does not add a second row. `GARAGE` is a field on the status panel, not a bracket command. Saying it does not add a row. The contract is [Garage version](#garage-version). The invitation is an ask in ordinary sentences. It is not a bracket command. The contract is [Invitation](#invitation).

| Word | What it does |
|---|---|
| Puff | Accept the named file, or the named section. Further edits to that file need a new decision. A puff does not cut a release, does not move a version forward, and does not allow a build. A puff on the file beside this one does not accept this one. Name each file in its own sentence. |
| Lock | Keep an already accepted file from being reopened. Locking the roster does not lock the product document, and it does not lock a plan. Each of those still needs its own sentence. Lock is not how a draft becomes a release candidate. The word for that step is `SERIAL-ACK`. |
| Chew | Keep the exploration in notes. It is not a plan, not code, and not a freeze. The clerk does not copy those notes into `plans/`. You do not either. |
| Open | Leave the question unanswered. Work that needs the answer waits. Do not plan it, and do not code it, just to look finished. |
| `SERIAL-ACK` | Accept the named serial and move it exactly one version step. The steps are draft (`{name}.draft.NNN.md`), then release candidate (`{name}.release-candidate.NNN.md`), then final (`{name}.finalize.md`). Said on a draft, it writes the release candidate as a new file and leaves the draft. It does not write the final. Said on a release candidate, it writes the final as a new file and leaves the candidate. Nothing skips the release candidate. The letter Y is not this word. Y is a ceremony printed inside the interchange standard by the project that wrote that standard. It is not your word. |

Before any work that touches a lock, a credential, or a private file, open [`global/prime-directives.md`](global/prime-directives.md). A prime directive is applied before the other rules and before the product document. If a sentence says prime directive and names no row, it means the legal row: legal work only, no forced entry, no private file you were not offered. You add a further row in that same file when you mean a further boundary. A new row does not become the next numbered rule. The next numbered rule would be L34. A prime-directive row is not L34. It stays a row in that table, and the legal row still applies underneath it.

### First session, the short form

The six numbered steps are the actions. They are not six new directives. Stop, in step 6, is the end of the session. It is an ordinary word, not a capital token. Do not add a capital word that means "finished" and expect the clerk to close the roster. `UNNAMED` stays the boolean for a seat you have not decided. The panel can still publish `ASK-CAST` after you stop. You must not edit the panel to change that line. The clerk maintains the panel.

The first session writes the identity you already know and then ends. The picture is a map of the six moves. The steps under it are the instructions. The failure cases, and why an assistant must not fill the empty fields for you, are in [Initial session](#8-procedure-initial-session). You do not need that section to run the steps.

![First session, brief map. Copy the folder, read the quick start, name the roster, fill the vision fields, write three sentences, then stop.](figures/07-quick-first-session.png)

*Map of the first session. The steps below are what you do. The full procedure is Initial session.*

1. Read this quick start from [What AA-SDD and EN-IR are](#what-aa-sdd-and-en-ir-are) through step 6. That is the reading this first session requires. The gist does not add a file to write, and it does not start a spec. The writes are the fields in steps 2 through 5, and only the ones you already know. A story setting is optional. The vision fields you know, the roster names you have decided, and three product sentences are the rest. A field you do not know stays empty, because an invented sentence will be quoted later as if you had chosen it. Step 6 ends the session: no plan, no code, and no edit to a system file. A later session says `COLD-START` once. If work is already on disk, that session continues from the resume checkpoint. It does not reset the files. The first install is the session that stops after the report. The contract is [Cold-start](#cold-start). A later session that will name work, answer a question, or build reads [Initial session](#8-procedure-initial-session) through [Steady state](#10-procedure-steady-state-session) first. Do not invent the product, the names, or the next action from the conversation, and do not copy the names printed inside the interchange standard. Those names belong to the project that wrote the standard.

2. Open [`VisionStatement.README.md`](VisionStatement.README.md). Write a story setting only if you want one. A genre, a room, a company, or a chronicle is a complete setting. It changes the tone of later writing. It does not set the product, the stack, or the current move, and this kit must not pick one for you. A team that wants ordinary engineering talk writes one sentence that says so, or leaves the bullet empty. Empty is a finished decision. The duty labels in the roster stay either way, and the work still follows the files. Asking the sit-rep about its role in that story waits until the story is written, and it is not this step. The short form is [Ask the sit-rep](#ask-the-sit-rep). The field-by-field check is on the [vision worksheet](VisionStatement.README.md).

3. Open [`aa-sdd/roster.md`](aa-sdd/roster.md). Replace `UNNAMED` with one name for each seat you intend to fill. One name is one string. The duty label already in the table is the job, not a second name. A seat you have not decided stays `UNNAMED`. You do not invent a name to make the table look filled in, and an assistant must not invent one, because every later file will cite that name as yours. Use the same spelling on the vision worksheet. Two spellings of one person are two seats. The invitation is the one later write the sit-rep makes, and only on the clerk seat, and only after you ask and a story is written. It is not this step. The other seats stay `UNNAMED`.

4. On that same vision worksheet, fill the fields you can actually check. The fields are the project name, who it is for, and a meaning of done a later reader can test without asking you. A mood, a hope, a stack choice, and a launch date are not that test. Leave a field blank until you know the answer. An invented sentence in a one-line field becomes the product, because the next session will quote it.

5. Open [`product/constitution.draft.001.md`](product/constitution.draft.001.md) and write three sentences. Three means three. They say what the product is. They are not a behavior spec, not a stack, not a schedule, and not a plan. How the first milestone will be built is a plan, and that plan exists only after you ask for it. Leave the filename at `draft.001`. The word draft in the name is what tells the next session the file is still open. Renaming it so the name no longer says draft makes that session treat the file as finished and refuse an ordinary edit. Do not build from the draft.

6. Stop. The first session ends here, and ending it is the success of the session. Do not write a plan, and do not put a file in `plans/`. The clerk files a plan later, and only after you ask and approve. Do not write code, do not mark a stage successful, and do not edit a system file to announce that the roster is finished. A seat you have not decided stays `UNNAMED`. If you stop early, the next session finds that same open roster, which is the state you want it to find.

### Later sessions, the short form

**Skip this on the first day** is a key. The sentences under it are not the work of the first session. `ASK-CAST`, `SIT`, and `NO-BUILD` are booleans the status panel can publish on `NOW.ACTION`. This short form does not teach how those values change. That procedure is [Steady state](#10-procedure-steady-state-session). You do not type one of those words to flip the panel, and you must not edit the panel. A sentence to the clerk still names one file and one directive from the token list. A comment such as "go ahead" is not that directive.

**Skip this on the first day.** Come back when the names you decided are written and the three product sentences exist. A later session then writes the working spec, when you intend to build, and the product rules, when you have them. A question is answered in the file the question belongs to. A plan is not one of those files. You ask for it and you approve it. The clerk files it under `plans/` as `YYYY-MM-DD_HHmm_name.md`. You must not create, rename, edit, or delete that file.

When you are changing a sentence in a draft, mark the change with a `[MEMO]` block at that place and close it with `[END-MEMO]`. `[MEMORANDUM]` is the same block. The words say the change and where it applies. The clerk applies that change and does not rewrite the ask. The long form is [Memorandum](#memorandum). A new requirement still goes in the spec and is marked `[NEW IN ...]`. The block does not take the place of that mark. Do not answer inside that memorandum. A new note is a new memorandum marked `[NEW ON ...]` with the date. The clerk's report, and a named seat's report, go in the [team brief](#team-brief). They do not go inside your memorandum. On a key action the clerk also pins the state and what occurred on the [corkboard](#corkboard). You may pin a note back to the team. A new note is a new pin. The garage version is the field `GARAGE` on the status panel. You may look. You must not bump it. A patch is a turn you name. The long form is [Garage version](#garage-version). After a story setting is written, you may ask the sit-rep what its role should be. That ask is optional. The long form is [Invitation](#invitation).

When the session holds work and has become bloated, ask the clerk to establish a RESUME CHECKPOINT state update before you open the next chat. The next session says `COLD-START` once and continues from that checkpoint. It is not a reset. The contract is [Cold-start](#cold-start). The full branch, including what `ASK-CAST`, a phase card, `SIT`, and `NO-BUILD` do to the session, is [Steady state](#10-procedure-steady-state-session). This short form does not describe the status panel. You may look at the panel. You must not modify it. The clerk maintains it. If a seat you meant to fill is still `UNNAMED`, go back to the first session before you build. Do not build against an open roster.

1. If a seat you meant to fill is still `UNNAMED` in [`aa-sdd/roster.md`](aa-sdd/roster.md), the roster is still open. A build started from that state will cite a seat the repository has not named, or a name an assistant invented to get past the blank. Go back to the first session and write the name before you build. A seat you have decided to leave empty can stay `UNNAMED`. The failure is building while a seat you meant to name is still the token.

2. The working spec, [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md), is where the batch of work is written once you intend to build. The headings already in the file are a starting point. Adapt them. They are not a law. Write the whole batch there before you open a pre-plan. Make the reasoning as complete as you can, so a later session sees one picture. Then iterate from that file. The file has to carry every requirement for that work, the stack, the libraries, the pre-conditions, the post-conditions, **Depends**, and the list of stages already finished. How to declare that file is [Write the spec](#write-the-spec). A later serial that drops the finished-stage list looks shorter and has lost the record of what shipped. Leave the file alone until you mean to build. While the filename still says draft, do not build from it. A draft is the copy you are still allowed to revise. A build treats the file as a closed decision, and a draft is not one.

3. Product rules go in the blank block at the bottom of [`global/project-laws.md`](global/project-laws.md), and only when you have a rule to write. Label them P1, P2, and so on. The process rules already occupy L1, L10, and L14 through L33. A number missing from that run is not a free slot. Putting a product rule there sends the next reader looking for a method rule this kit never shipped. A boundary that is applied before the other rules is a new row in [`global/prime-directives.md`](global/prime-directives.md), and it is not a new L-number. The legal row is already in that table: legal work only, no forced entry, and no private file you were not offered.

4. Answer a question in the file the question belongs to. A product question is answered in the product document. A method question is answered by the rules, and you do not edit the rules so they match a wish. Notes you marked chew stay notes. They are not a plan and they are not code. A plan is a separate file, and it exists only when you ask for one in that turn. When you approve it, the clerk copies the full text to `plans/` as `YYYY-MM-DD_HHmm_name.md`. You must not create, rename, edit, or delete that file. The directory rule is [`plans/README.md`](plans/README.md). A bug or a feature leaves a row in [`bugs/bugs-fixed.md`](bugs/bugs-fixed.md) or [`features/features-added.md`](features/features-added.md) in that same turn. A change with no row is a change the next session cannot find.

5. The three system files stay as the copy left them. You may open the status panel, the index, and the boot file and read what they publish. You must not modify them. The clerk maintains them. An edit that makes the panel "look ready" does not change which spec file is live. The next session reads the index, and a panel rewritten by hand is the stale copy the clerk then has to repair.

6. The turn ends with one local commit of the files you changed. That commit is the snapshot the next clean session reads. In the same turn, update every README in this folder that describes a behavior you just changed. A README that does not describe that behavior stays as it is. Do not push. A push publishes the repository, and this step has not asked for that. Do not stage secrets, tool caches, or a directory named `tmp` unless you named that path in this request. Naming a different path does not name `tmp`. If you forbid the commit, or the commit fails, the session says so. It must not report success over a dirty tree or a failed commit.

### Build, the short form

**Skip this until you intend to build** is a key. The word Build, with no file and no stage named, is not a directive. When you want a build, the sentence names the stage and the stamped plan. `SERIAL-ACK` moves one named serial one step. It does not start this pipeline, and it does not approve a plan. Puff on the roster, on a picture, or on the sketch accepts that other file. It does not accept the plan.

**Skip this until you intend to build.** A build is a gated pipeline. Skip a stage and the code will cite a decision the repository does not contain. The order is the spec, reasoned to completion, then the sketch, which is the pre-plan, then the approved plan, then the build, then the scan, then a new working-spec serial. Do not open the pre-plan while the spec is still missing a requirement you already know you want. That missing line is written in the spec first. The shape of the spec is [Write the spec](#write-the-spec).

The rules file calls the sketch a pre-plan. The filename pattern is `*-pre-plan-stage-N.001.md`. The picture labels that same stage Sketch. Those three names are one stage, and it is a direction you are still allowed to reject. Throwing the sketch away is a success. The moment a build follows the sketch, the gate between sketch and plan is gone. The gate on every stage is [Build sequence](#14-build-sequence). Which stamped file a stage follows is [`plans/README.md`](plans/README.md).

![When a build is allowed. Working spec, sketch, stamped plan, build, scan, new serial. Refused from a draft, a sketch, or this kit.](figures/09-quick-build.png)

*Map of the build. The line in Build sequence is the order. The table there is the gate on each stage.*

Run the stages in this order. Each stage exists to keep the next one from citing a decision the repository does not contain. The long form of every gate is [Build sequence](#14-build-sequence).

1. Open the working spec, [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md) until you roll a new serial. Reason here first. The headings in the file are a starting layout. Adapt them to this batch. Read [`aa-sdd/AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md) and [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md) when you want two finished specs as examples of structure. The file states the whole batch: every requirement you want built, the stack, the libraries, the pre-conditions, the post-conditions, **Depends**, and the list of stages already finished. A requirement that first appears in the sketch, the plan, or the code is not in the batch. Put it in the spec, mark the new block `[NEW IN ...]`, and do not let the sketch invent it. Dropping a finished stage to make the page look short deletes the record the next serial is required to keep. Do not build from this file while the name still says draft. A draft is the copy you are still revising. The build is allowed to follow a frozen working spec and a stamped plan, not the draft you are still changing. Do not start step 2 until this file says the batch you mean.

2. Write the sketch only while you are still allowed to reject the direction. The rules file calls this stage a pre-plan. The filename is `*-pre-plan-stage-N.001.md`. The picture labels the same stage Sketch. It is one stage, and it is not a source you build from. Throwing the sketch away is a success, the same way discarding a spike branch is a success when the spike answered the question. The moment a build follows the sketch, the gate between sketch and plan is gone, and the code is citing a direction you had not accepted.

3. Ask for the plan in a sentence, in that turn. Approve it when the text is the decision you mean. The clerk then files the full text in `plans/` as `YYYY-MM-DD_HHmm_name.md`. You do not file it yourself, and you do not rename, edit, or delete it. A puff on the roster, on a picture, or on the sketch accepts that other file and does not approve this plan. A chew stays notes, and the clerk must not copy those notes into `plans/`. A newer time in a filename is not automatically the plan for an older stage. If stage 2 was approved against `2026-10-16_0905_stage-2.md`, the build of stage 2 follows that file even after `2026-10-16_1400_stage-3.md` exists. Sorting the directory does not make the choice. The stage has to name its plan.

4. Build only against that stamped plan. The code matches the plan the way a pipeline matches the file it was pointed at, not a summary of the file and not a neighboring file. A build from a draft, from a sketch, or from this kit is refused. The word Build, with no file and no stage named, is not a request to start.

5. When you mark a stage successful, scan what remains and write each gap as a `G-nn` record. A gap that lives only in your head is a gap the next session will meet as a surprise, because that session does not have the conversation. Do not start the next stage's build until the new working spec is frozen and a plan for that next stage exists.

6. Roll a new working-spec serial for the next stage. Carry the finished-stage list forward. Leave the frozen product document frozen. Leftover scope goes in the new working spec, not back into the constitution you already accepted. Editing the freeze to fit the leftover is how a product forgets what it was. The closed serial stays on disk under its own name. You do not overwrite it. Write the next serial as a new file.

### Write the spec

**Skip this until you are describing work** is a key. The first session does not write a spec. It stops after the names, the vision fields you know, and three product sentences. Come back when you are ready to say what will be built. This section is how you declare that file. The build order that follows it is [Build, the short form](#build-the-short-form).

**Skip this until you are describing work.** The first session ends without this file filled in. When you do write it, write the batch, mark only the blocks you added, and do not open the pre-plan until the spec says the work.

A spec file is the list of requirements you want built, written down before anyone sketches a direction. The working spec is [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md). Open it and read the headings before you write your own. Those headings are a starting layout, the shape a module spec often uses. Adapt them. Drop a section you do not need. Add a section the batch needs. They are not a law. Before that, read [`aa-sdd/AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md) and [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md) the same way: structure and syntax, not a product to copy. A module that deserves its own file is another draft serial beside the working spec, for example `product/ledger.draft.001.md`. You declare a spec by writing the keys below into that file. Each bold title is a key. The text under the key is the value. An empty key means you have not decided. Do not fill it to make the page look finished.

The file is meant to hold all of the requirements for the batch, not a sample and not the first idea. A requirement that stays in the conversation is a requirement the next session does not have. Name the stack you have chosen, and name the libraries. A library named only in chat is not in the build. A version you have not chosen stays blank. Do not invent one.

**Pre-conditions** are what must already be true before this batch starts. If a pre-condition is false, the batch does not start. **Post-conditions** are what a later reader can check when the batch is finished, without asking you. A mood, a hope, and a launch date are not a post-condition. They do not tell the next session whether the work met the spec.

**Depends** is the key for the other spec files this one requires. Write it as a bold title, then the paths. When you mean one part of a file, add the section after a hash mark.

```text
**Stack:** the language and runtime you have chosen.
**Libraries:** each library you have chosen. Leave a version blank until you know it.
**Pre-conditions:** what is already true, or this batch waits.
**Post-conditions:** what is true when this batch is finished.
**Depends:** product/ledger.draft.001.md, product/billing.draft.001.md#post-conditions
```

`[NEW IN ...]` is the mark you put on a block you just added. Replace the dots with a short name of that block, for example `[NEW IN payment retry]`, and put the mark on that block. The clerk reads the marked block as the new material. Text with no mark stays the text already in the file. The clerk must not treat the whole spec as new because one block is marked. The mark is not Puff. It does not accept the file. It does not open a pre-plan, a plan, or a build. When you want the spec accepted, that is a separate sentence, and the sentence names the file. A change to a sentence you are iterating is a `[MEMO]` block at that place, not a new requirement by itself. The block and the place are [Memorandum](#memorandum). A requirement the spec does not already state is still written into the spec and marked `[NEW IN ...]`.

Work is specified in batches. A batch is one spec that already contains the requirements, the stack, the libraries, the pre-conditions, the post-conditions, and **Depends** for that piece of work. The reasoning belongs in that file, and it belongs there before the pre-plan. Make that reasoning as complete as you can. Enough of the problem has to be on the page that a later session sees one picture. Specify the batch the way you would specify an architecture. Then iterate from that file. A turn that adds one requirement, then another turn that adds the next, makes the clerk re-read and re-reason the same spec each time. The requirements also drift, because each turn saw only the piece that turn added. Write the batch, then stop adding requirements, then sketch. The sketch is the pre-plan. It is a direction you may still reject. It is not allowed to contain a requirement the spec does not already state. After the pre-plan, you ask for the plan and you approve it. The clerk files the plan. Then the build follows that plan. A later addition is a new block in the spec, marked `[NEW IN ...]`, reasoned there, and only then allowed into a new pre-plan. One local commit still closes a turn that changed files. The saving is that you do not pay for a fresh reasoning pass on every small addition before the spec is complete.

A dependency tree is how you keep a batch from becoming one file that holds every module. Each module is its own spec and states its own requirements, stack, libraries, pre-conditions, and post-conditions. The parent lists the children under **Depends**. A child may list its own **Depends**. The clerk reads a file after the files it names, not before. In the example above, the working spec names the ledger file and the post-conditions section of the billing file. The clerk reads those before the working spec. If the billing spec lists the ledger under its own **Depends**, the ledger is read before billing. Do not paste the ledger requirements into the billing file. The tree is how the batch stays modular. Each module stays in its own file. A cycle, where billing depends on ledger and ledger depends on billing, has no first file. Break that cycle in the **Depends** lines before you write a pre-plan. A path that does not exist is a missing spec, not a hint. Create the file and write its batch, or remove the line. Do not leave the missing path for the build to discover.

### Dig when you need it

The left column is the key. Open the one row whose key matches the job in front of you. Do not read the table as a list of directives to run from top to bottom. A capital string inside a row, such as `SERIAL-ACK`, is the directive that row is about. It runs when you say it in the same sentence as its file, not when you open the row.

This table is the rest of the manual, indexed by the job in front of you. Open one row when you are about to do that job. The first session does not need it. The first session is the quick start above.

| You are about to | Open |
|---|---|
| Learn a word before a procedure uses it | [Definitions](#4-definitions) |
| Say an action the clerk can run | [Normative language](#3-normative-language) |
| Check whether a session conformed | [Conformance](#5-conformance) |
| See which file wins an argument | [File graph](#62-file-graph) and [Conflict notes](#16-conflict-notes) |
| Cold-start the instance after install | [Cold-start](#cold-start) and [`aa-sdd/aa-sdd-cold-start.md`](aa-sdd/aa-sdd-cold-start.md) |
| Continue work after a bloated session | [Cold-start](#cold-start) |
| Run the real first session, with the detail | [Initial session](#8-procedure-initial-session) |
| Run the real later session | [Steady state](#10-procedure-steady-state-session) |
| Version a file, or accept one with `SERIAL-ACK` | [Versioning](#11-versioning) |
| File a picture, or keep a scratch directory out of git | [Media and scratch space](#12-media-and-scratch-space) |
| Write a spec for a batch of work | [Write the spec](#write-the-spec) |
| Mark a change while iterating | [Memorandum](#memorandum). `[MEMO]` and `[MEMORANDUM]` are one block. `[END-MEMO]` closes it. The block names the change and the place. |
| Read a report in a serial draft | [Team brief](#team-brief). `[TEAM-BRIEF]` is the report section. A new memorandum carries `[NEW ON ...]` and the date. |
| Read what a turn did, or leave a note for the cohort | [Corkboard](#corkboard). The clerk pins the state and what occurred. You may pin a note back. `[RED-ALERT]` is the open grid line. |
| Read the garage version, or name a patch | [Garage version](#garage-version). `GARAGE` is a field on the status panel. It is not `SERIAL-ACK`. |
| Ask the sit-rep about its role in a story | [Invitation](#invitation). The ask is optional. It is not a command. |
| See how a spec is shaped | Open [`aa-sdd/AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md), [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md), and [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md). Read the structure. The working draft is a starting layout. Adapt it. Do not build from the draft. |
| Start a legal build | [Build sequence](#14-build-sequence) and [`plans/README.md`](plans/README.md) |
| Add behavior the manuals describe | [Extension by the owner](#15-extension-by-the-owner). Update every README here that states it, the same turn. |
| Touch a lock, a private file, or a boundary the owner added | [`global/prime-directives.md`](global/prime-directives.md). The token with no row named is the legal row. |
| Find any file in this garage | [Tree of this garage](#tree-of-this-garage) |
| Look up a token's file effect | [`global/project-conceptual-syntax-reference.md`](global/project-conceptual-syntax-reference.md) |
| Read the interchange format | [`aa-sdd/enir-suit-man.md`](aa-sdd/enir-suit-man.md) teaches the format. If that manual and [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md) disagree, the next session follows the standard. Change the manual. Do not edit the standard so it matches the manual. A clarification typed into the standard makes this copy disagree with every other copy. |
| Read the architecture standard | [`aa-sdd/AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md). AA-SDD/1.0. It does not boot. Laws and the constitution remain the truth. |

## Tree of this garage

**Skip this until you need a path** is a key. Each link below is the key for one file. Open the link the job names. Do not walk the list as a procedure. A capital string in a line, such as `UNNAMED` or `L29: ACK`, is a value the file stores or a line a session prints. It is not an order to run the tree from the top. Row order is not version order, and it is not an instruction to the clerk.

**Skip this until you need a path.** The list below is the whole kit, one link per file. It is not a tutorial and it is not version order. The index file's row order is not version order either. A garage is one project under these rules. Another project is another copy, with its own files. Two projects must not share one status panel, or the next start will not know which project it is looking at.

The four READMEs are the pages a person opens. Everything else is the file that page points at. Open a README for the job. Open a single file from the list when the job names it.

| README | Open it for |
|---|---|
| [`README.md`](README.md) | This manual. Start at the quick start. |
| [`VisionStatement.README.md`](VisionStatement.README.md) | The form for the project name, the audience, done, an optional story setting, and the roster worksheet. Blank until you write it. |
| [`aa-sdd/README.md`](aa-sdd/README.md) | The table of contents for the procedure files. Do not start a session by reading that directory. |
| [`plans/README.md`](plans/README.md) | What may be stored as a plan. The clerk manages the files. Empty is correct. |

- [`README.md`](README.md). This manual. README standard 2.
- [`SPEC.manifest.md`](SPEC.manifest.md). System file. The index of live files. You may look. You must not modify it. The clerk maintains it.
- [`VisionStatement.README.md`](VisionStatement.README.md). The identity worksheet. Blank on purpose.
- `aa-sdd/`. The method. Not the product.
  - [`README.md`](aa-sdd/README.md). The procedure index. Not a startup read.
  - [`roster.md`](aa-sdd/roster.md). Seat duties. Names stay `UNNAMED` until you replace them.
  - [`aa-sdd-cold-start.md`](aa-sdd/aa-sdd-cold-start.md). The fresh-session procedure. The fenced list is the contract. The prose around it explains older words the report still prints.
  - [`aa-sdd-handshake.md`](aa-sdd/aa-sdd-handshake.md). What each decision word does to a file.
  - [`aa-sdd-dialog-modes.md`](aa-sdd/aa-sdd-dialog-modes.md). Four ways to talk. One at a time. None of them is the build.
  - [`aa-sdd-q18-cadence.md`](aa-sdd/aa-sdd-q18-cadence.md). Stage order. Pre-plan is the sketch.
  - [`aa-sdd-process-sync.md`](aa-sdd/aa-sdd-process-sync.md). Same-turn repair of links, the scan after a stage, and the local commit.
  - [`aa-sdd-witness-marks.md`](aa-sdd/aa-sdd-witness-marks.md). Conflict notes WM-1 through WM-9. Not a startup input.
  - [`aa-sdd-resume-card.md`](aa-sdd/aa-sdd-resume-card.md). The shape of a phase card. This kit ships none. The clerk writes one when you ask for a RESUME CHECKPOINT. Do not invent one at startup.
  - [`aa-sdd-continuity.md`](aa-sdd/aa-sdd-continuity.md). Who keeps what consistent, and the five-field receipt.
  - [`aa-sdd-seat.md`](aa-sdd/aa-sdd-seat.md). The clerk's private notes. Opened at startup, not quoted.
  - [`aa-sdd-encode.md`](aa-sdd/aa-sdd-encode.md). A requirement file, or a data packet. Not the same job.
  - [`aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md). The interchange standard. Do not edit it. Names inside it are not this roster.
  - [`AA-SDD/aa-sdd.spec.md`](aa-sdd/AA-SDD/aa-sdd.spec.md). The architecture standard, AA-SDD/1.0. A page you can hold. A runtime reads it as the concept. It does not boot. Laws and the constitution remain the truth. Do not edit the copy. If this manual and that file disagree about what the architecture is, follow that file and change this manual.
  - [`enir-suit-man.md`](aa-sdd/enir-suit-man.md). The manual for that standard. If they disagree, the next session follows the standard. Change the manual. Do not edit the standard.
  - [`aa-sdd-prime-directive.md`](aa-sdd/aa-sdd-prime-directive.md). A pointer. The table is [`global/prime-directives.md`](global/prime-directives.md). Legal work only. No forced entry. No private file you were not offered.
  - [`aa-sdd-serial-history.md`](aa-sdd/aa-sdd-serial-history.md). Where a closed serial moves. Never overwrite it.
  - [`aa-sdd-clerk-sweep.md`](aa-sdd/aa-sdd-clerk-sweep.md). An integrity pass, when you ask for it. Not startup.
  - [`aa-sdd-video-bay.md`](aa-sdd/aa-sdd-video-bay.md). The picture pipeline. It runs only when you name it.
  - [`holodeck/corkboard.md`](aa-sdd/holodeck/corkboard.md). The bulletin board. Newest pin at the top. The clerk pins a key action: the state, and what occurred. You may pin a note back to the team. The board ships with no pins. It is not a system file.
  - [`holodeck/system-report.md`](aa-sdd/holodeck/system-report.md). Open and closed alerts. When an alert is open, the corkboard line is `[RED-ALERT] SYSTEM REPORT`. When nothing is open, the line says the grid is clear.
  - `seats/clerk/`
    - [`CHOICE.md`](aa-sdd/seats/clerk/CHOICE.md). The clerk's private notes. You do not read this file. A fresh session opens it, prints `L29: ACK`, and does not quote it.
- `bugs/`
  - [`bugs-fixed.md`](bugs/bugs-fixed.md). The bug index. You append a row. You do not rewrite old rows. Empty is correct. A fresh session reads the last twenty rows.
- `en-ir/`
  - [`EN-IR.handshake.md`](en-ir/EN-IR.handshake.md). A pointer to the standard. Not the standard. Not a startup source.
- `features/`
  - [`features-added.md`](features/features-added.md). The feature index. Append-only. Empty is correct.
- `figures/`. Pictures are PNG, 16:9. If a picture and its section disagree, the next session follows the section. Change the picture, or change the section if the section was the mistake.
  - [`01-repair-the-loser.png`](figures/01-repair-the-loser.png). [File graph](#62-file-graph).
  - [`02-new-rule-check.png`](figures/02-new-rule-check.png). [New-rule check](#63-precedence-when-a-new-rule-is-added).
  - [`03-initial-session.png`](figures/03-initial-session.png). [Initial session](#8-procedure-initial-session).
  - [`04-steady-state-session.png`](figures/04-steady-state-session.png). [Steady state](#10-procedure-steady-state-session).
  - [`05-version-mutation.png`](figures/05-version-mutation.png). [Versioning](#11-versioning).
  - [`06-build-sequence.png`](figures/06-build-sequence.png). [Build sequence](#14-build-sequence).
  - [`07-quick-first-session.png`](figures/07-quick-first-session.png). [First session, the short form](#first-session-the-short-form).
  - [`08-quick-later-session.png`](figures/08-quick-later-session.png). On disk. The quick start does not use this figure. The session procedure is [Steady state](#10-procedure-steady-state-session).
  - [`09-quick-build.png`](figures/09-quick-build.png). [Build, the short form](#build-the-short-form).
- `global/`
  - [`grok-ai-kernel.toon`](global/grok-ai-kernel.toon). System file. The status panel. It publishes the one current action and the field `GARAGE`. You may look. You must not modify it. The clerk maintains it. `GARAGE` is the baseline this kit was cut from. Looking at the field does not make the file editable.
  - [`grok-ai-foundation-context.md`](global/grok-ai-foundation-context.md). System file. It says why the startup order exists. It is not a second procedure. You may look. You must not modify it. The clerk maintains it.
  - [`project-laws.md`](global/project-laws.md). The rules. They win.
  - [`prime-directives.md`](global/prime-directives.md). The prime-directive table. The legal row is the default. You add rows.
  - [`project-glossary.md`](global/project-glossary.md). The word list. One meaning each.
  - [`project-conceptual-syntax-reference.md`](global/project-conceptual-syntax-reference.md). The token list. `[MEMO]` and `[MEMORANDUM]` are one row. `[END-MEMO]` closes the block. `[TEAM-BRIEF]` is the report section. `[NEW ON ...]` is the search mark, with the date where the dots are. [`holodeck/corkboard.md`](aa-sdd/holodeck/corkboard.md) is the bulletin board. The clerk pins a key action there. `[RED-ALERT]` is the open grid line. A bracket command that is absent is added by the clerk the same turn. A bracket command that is already in the list is the system directive. In the same sentence it supersedes a capitals-only word with no backticks and no brackets. A capital word with no brackets that is absent is not in force.
  - [`creepy-futures.md`](global/creepy-futures.md). Parked ideas. A row is a refusal, not a backlog.
  - [`aa-sdd-ad-hoc-requests.md`](global/aa-sdd-ad-hoc-requests.md). One-off bug and feature rows. Written in the same turn as the change.
- `plans/`
  - [`README.md`](plans/README.md). Stamped plans only. The clerk manages every file here. You ask and you approve. You do not manage the files. Do not add an example file so the directory is non-empty.
- `product/`
  - [`constitution.draft.001.md`](product/constitution.draft.001.md). The three-sentence product draft. Do not build from it.
  - [`working-spec.draft.001.md`](product/working-spec.draft.001.md). Remaining scope. A draft. The headings are a starting layout. Adapt them. The values ship empty. Do not build from it. Carry the stage list when you roll.

## 1. Purpose

A sentence to the clerk in this section names one file you are allowed to write, or it names a plan you are asking for. It names one directive from the token list, in that same sentence. "Approve the plan" is the sentence you say. It is not a capital boolean on the status panel, and it does not create the file. The clerk files the plan. The bold names of the system files, when this section uses them, are keys for files you may read and must not modify. Do not invent a capital word that means "purpose." The contract for capitals, booleans, and bold keys is [Normative language](#3-normative-language).

This folder is the record a later session trusts. You place it in an empty repository as `docs/spec/`, the way a pipeline places its source of truth where the next clean run can read it. A clean build machine has no memory of the last run except what the repository contains. It does not guess the next step from a chat scroll, a ticket comment, or a summary pasted into the prompt. This folder works the same way. If a fact is not in a file, the session does not have the fact.

You approve scope, names, and plans. Approving a plan is a sentence you say. Filing the plan is the clerk's job, and you must not create, rename, edit, or delete a file in `plans/`. An assistant may draft, file, and build. An assistant must not invent the product, the role names, or the next phase. A draft the assistant files is a proposal. It becomes approval only when you say so, or when you use one of the decision words in [Section 9](#9-decision-words) in the same sentence as the file it binds.

The folder ships with no sample product, no sample role names, and no program. The working spec ships with section headings and empty values. Those headings are a starting layout. They are not a sample product. Adapt them when you write your batch. The empty fields are the roster names, the vision lines, and the product document, and they are empty so that a later reader can tell your choices from anyone else's. Filling them with another project's names gives this project a second identity. Keep the paths. They are the addresses in this manual. If you move a file, the clerk updates the index and the status panel in that same turn. You must not make that repair yourself. Those two files are system files. The fields you write on the first day are the ones named in [Initial session](#8-procedure-initial-session).

A turn is one request from you, together with the file edits that answer it. [Section 4](#4-definitions) is the dictionary for the words this manual then uses as requirements. When those edits change project state, the turn ends with one local git commit and does not push. You write the product files named in the [quick start](#quick-start). The clerk maintains the three system files. You may look at them. You must not modify them. The [tree](#tree-of-this-garage) is how you open one file when you already know which file you need.

## 2. Audience and prerequisites

Kernel, manifest, head, and puff are file labels. They become a directive only when you use the capital token, or the decision word, that the token list already gives that label. Head means the live spec file the index names. Writing `HEAD` in capitals does not change which spec file is live, and it does not mean the git HEAD commit. Puff is the decision word. `[PUFF]` is the system directive when that row is in the token list. PUFF written in capitals with no backticks and no brackets is the capitals-only form. In a sentence that uses `[PUFF]`, the bracket form is the action, and the bare PUFF does not accept the file a second time. A capitals-only form used alone still needs the file in the same sentence. A bold word in the dictionary is a key, not a louder label.

This manual assumes you already run a shell, read a pipeline, and make a local commit. It does not assume you know this folder's filenames. Kernel, manifest, head, and puff are field names and file labels. Each one is defined where you first meet it, and again in [Section 4](#4-definitions), which is a dictionary. Open the word that is in your way. Do not read the dictionary straight through on the first day.

Until you write your own short names into the glossary, the definitions in section 4 are the meanings a reader must use. Two words can sit next to each other and still name two files. Do not treat head and the git HEAD commit as the same object. In this manual, head means the live spec file the index names. It does not mean the git HEAD commit. Committing does not, by itself, change which spec file is the head.

The [quick start](#quick-start) is the first path: install, cold-start, the names and fields you know, three product sentences, then stop. No plan and no code. Before a later session does more than stop after a cold-start report, read from this section through [Steady state](#10-procedure-steady-state-session). Sections 11 through 17 are the reference you open when a file is ready to be versioned, a picture is ready to be filed, or a build is ready to start.

## 3. Normative language

This section is how you read the marks on the page, and how you describe one action to the clerk. The quick start uses the same rules. If a sentence there is shorter than a sentence here, follow this section and change the shorter sentence. Do not change this section so a shorter sentence can stay.

A word in full capitals is either a directive or a boolean. It is not emphasis. It is not a louder form of an ordinary word.

A directive is an action the clerk runs. Write it in capitals. When the token has more than one word, put a hyphen between the words. `COLD-START` is issued once in a session. The first install is the reset. After work is on disk it resumes from the checkpoint. The contract is [Cold-start](#cold-start). `SERIAL-ACK` moves the one serial named in that same sentence exactly one version step. A bracket form that is already in the token list is the system directive for that row. `[COLD-START]` names the same row as the capitals spelling, so the clerk does not add a second row. In the same sentence the bracket form supersedes a capitals-only word that has no backticks and no brackets. The clerk runs the bracket form. The capitals-only word does not take its own action. The worked example is the paragraph after the new-command example. The decision words in [Section 9](#9-decision-words) are directives as well. Puff, Lock, Chew, and Open are written as those words. You do not have to force them into capitals. Each one still binds only the file named in the same sentence. Every other directive is full capitals. The list is [`global/project-conceptual-syntax-reference.md`](global/project-conceptual-syntax-reference.md). A capital word with no brackets that is not in that list, and is not a boolean this folder already prints, is not in force. The clerk must not invent a meaning for it. `SHIP` and `MUST` do not get a row. A bracket command that is not in the list is different. The clerk adds the row in the same turn. The defined shape is `[SOME-COMMAND]`(= what it does.; why = the purpose.). The text before `why =` is the description and goes in the Do column. The text after `why =` is the purpose and goes in the Means column. If you leave the parenthetical off, the clerk still adds the row and infers the purpose and the description from the sentence the command sat in, and from the words inside the brackets. The clerk does not ask you to draft the row first. If the command is already in the list, the clerk follows that row and does not write a second one. `[NEW IN ...]` is a mark, not a directive that starts work. You put it on a block you added to a spec and replace the dots with a short name of that block. The clerk reads the marked block as the new material. The mark does not accept the file and does not open a pre-plan. It is already defined, so it does not add a row. `[MEMO]` and `[MEMORANDUM]` are one instruction block, already defined in [Memorandum](#memorandum). `[END-MEMO]` closes it and is not a command. Using either spelling does not add a row. `[TEAM-BRIEF]` is the report section in a serial draft. `[NEW ON ...]` is the search mark on a new memorandum and on any new item in a spec. Both are already defined in [Team brief](#team-brief). `[RED-ALERT]` is already defined in [Corkboard](#corkboard). Using any of them does not add a row. `GARAGE` is a field on the status panel, not a bracket command. Saying it does not add a row. The contract is [Garage version](#garage-version). The invitation is an ask in ordinary sentences. It is not a bracket command. The contract is [Invitation](#invitation). The full shape of a spec is [Write the spec](#write-the-spec). The contract for the block is [Memorandum](#memorandum).

The same example the quick start uses is the test of this rule. You write: When the card is refused, `[RETRY-PAYMENT]`(= Charge the named order once more.; why = A refused charge gets one recorded second attempt, then it stops.). The clerk adds `[RETRY-PAYMENT]` to the token list before the turn ends. Means is "a refused charge gets one recorded second attempt, then it stops." Do is "charge the named order once more." That command is the example. It is not a command this folder already ships. If you write only "When the card is refused, `[RETRY-PAYMENT]` the order once and then stop." the clerk still adds the row. The inferred purpose is one recorded second attempt, then stop. The inferred description is charge that order once and then stop. After the row exists, the command means the Do cell. That introducing sentence is not a build, a phase change, or a puff.

When the bracket command is already in the token list, it is a system directive. It is the token for the action. In the same sentence it supersedes a capitals-only word that has no backticks and no brackets. You write: COLD-START `[LOCK]` the roster. `[LOCK]` is the system directive. The clerk locks the roster. COLD-START does not also run the fresh-session procedure. You write: COLD-START `[COLD-START]` the folder. The clerk runs the fresh-session procedure once. The bare COLD-START does not run it a second time. A spelling in backticks is a citation. The backticks alone do not run the command. A capitals-only word used alone, with the row already in the list, still binds the one file named in that sentence. The bracket form is what supersedes it, and only in a sentence that uses the bracket form.

A boolean is a yes or no a file already stores. It is written in capitals so the next session can search for that exact string. `UNNAMED` means that seat has no name yet. `ASK-CAST` on the line `NOW.ACTION` means the roster is still open. `SIT` means stay with the current phase and do not start new work. `NO-BUILD` means you can see the phase, and writing the program is refused. You read those values. You do not set them by typing yes, true, on, or ready in a comment. You do not edit the status panel, the index, or the boot file to flip a boolean those files publish. Those three files are system files. The clerk writes them. You change a file you are allowed to edit by saying the directive the token list already binds to that file, in the same sentence as the file.

A bold title is a key. The pattern is a bold label, then the value that belongs to that label. **Purpose** is the key for the job a file does. **Intent** is the key for the mistake the rule stops. **Do this now**, **Skip until you need it**, and **Leave alone** are the three keys at the top of the quick start. In the dictionary, **Turn**, **System file**, and **Head** are keys. In a spec, **Stack**, **Libraries**, **Pre-conditions**, **Post-conditions**, and **Depends** are keys. How to fill them is [Write the spec](#write-the-spec). The clerk looks the key up. Bold is not stress. If you bold a second title for a fact that already has a key, you have made a second key, and the next session will not know which string the files mean. Do not bold a word unless a later session must look that key up.

One sentence to the clerk names one file and one directive. Name the file by its path, or by the bold key this manual already uses for that file. Put the directive and the file in the same sentence. `Puff the roster.` accepts the roster. `Puff the roster. This is great. Ship it.` is still that one action. Great and ship are a comment. A comment may say why you accepted the file. It does not name a second file, it does not add a second directive, and it does not cut a release. A second file needs a second sentence, and that sentence repeats the directive if you want the same directive to apply. A directive in one sentence and a path in the next sentence do not bind. The next session cannot tell which file you meant.

### Memorandum

**Memorandum** is a key. `[MEMO]` and `[MEMORANDUM]` are the value. `[MEMO]` is the short spelling. They share one row in the token list. Writing either spelling does not add a second row. `[END-MEMO]` closes the block. It is not a command of its own.

The block is how you and the clerk define a change, and the place the change applies, while you are iterating. You write it in the file. A sentence in the chat that is not in the block is not the change. The next session does not have the chat.

The place is one of two things. The block sits on the line after the text it changes, or inside the section it changes, and that spot is the place. Or the words inside name the place: a heading, a path, the sentence above, a section. If the words name a place, that name wins. The clerk does not also edit the neighbors of the block.

One block is one change and one place. A second change is a second block. A second place is a second block.

The words inside the block are the change. The clerk applies that change. The clerk does not rewrite the ask into a different job, a wider edit, or a sentence you did not ask for.

Text outside the block stays as it is, unless the block names that text as the thing to change. A memorandum in a page does not give the clerk the rest of the page.

The block is not the product sentence. Do not leave the instruction as the line a later reader keeps. The product sentence is the result of the change. After the change lands, leave the block under the changed text until you say to remove it. The parked block is the record of what you asked. Removing it is a sentence you say. The clerk does not delete it because the edit looked finished.

If the block states the result, the clerk writes that result at the named place. If the block says the current text fails and asks for a reword, the clerk rewords that place so the stated failure is gone, and does not change the job into something else. If the block does not say what is wrong and does not say the result, the clerk does not edit the surrounding text. The clerk opens a new memorandum for the question and marks it `[NEW ON ...]` with the date. You answer in another new memorandum, marked the same way. Do not exchange those notes inside the memorandum that asked. Each memorandum stays one change.

A `[PUFF]` inside the block accepts the change the block names. It does not accept the file. It does not move a serial. It does not start a build. A requirement the spec does not already state is written into the spec and marked `[NEW IN ...]`. The memorandum does not stand in for that mark.

A `[MEMORANDUM]` that covers the whole pass, rather than one sentence, may sit between `---` lines. Close it with `[END-MEMO]`. If `[END-MEMO]` is absent and the note sits between two `---` lines, the second `---` ends the block. An inline `[MEMO]` with no `[END-MEMO]` and no second `---` is not closed. The clerk does not read the rest of the file as the memo. The clerk does not add the question under that opening mark. The question is a new memorandum.

Every new memorandum carries `[NEW ON ...]` with the date of the turn in place of the dots, as in `[NEW ON 2026-10-16]`. The same mark goes on any new item added to a spec. The clerk searches for `[NEW ON` and reads those blocks. The clerk does not diff the file to discover them. An item already in the file does not get a fresh mark because the session opened. The mark does not accept the file, open a pre-plan, or start a build. `[NEW IN ...]` still names a new requirement. A new requirement carries both marks when it is also new on this date. Using `[NEW ON ...]` does not add a second row. The contract for the report section is [Team brief](#team-brief).

The quick start example is [Mark a change while you iterate](#mark-a-change-while-you-iterate). If a sentence there is shorter than a sentence here, follow this section.

### Team brief

**Team brief** is a key. `[TEAM-BRIEF]` is the value. It is one section in a serial draft. Writing the token does not add a second row.

The section is where the clerk reports, and where a named seat on the roster reports. You read it. You do not write the report for the clerk. A seat that is still `UNNAMED` does not report, and nobody invents a report to fill that seat.

The section is not a memorandum. Do not put the report inside a memorandum you wrote. Do not put your change instruction inside the team brief and treat that as the ask. The ask stays in your memorandum. The report stays in `[TEAM-BRIEF]`.

A note the clerk sends back to you is a new memorandum the clerk opens. It is closed with `[END-MEMO]`. It carries `[NEW ON ...]` with the date. It is not a paragraph added to your memorandum. Your answer is another new memorandum, with its own date mark. Do not exchange notes in the same memorandum.

`[NEW ON ...]` is the search mark. Put the date where the dots are. The form is `YYYY-MM-DD`, as in `[NEW ON 2026-10-16]`. The clerk searches the draft for `[NEW ON`. That search finds every new memorandum and every new item added to a spec since the marks were written. The clerk does not diff the whole file to find them. A block with no `[NEW ON ...]` mark is not announced by that search. Put the mark on the new block in the same turn the block is added.

The mark is not `[NEW IN ...]`. `[NEW IN ...]` names a new requirement. `[NEW ON ...]` says the block is new on that date. A new requirement carries both. Neither mark accepts the file. Neither mark opens a pre-plan, a plan, or a build. Neither mark is a puff, and neither mark moves a serial.

The report in the team brief is not the product sentence. It says what was done, or what was found, at the places the memoranda named. It does not widen those places. After you have read it, it stays until you say to remove it. The clerk does not delete it because the edit looked finished.

The quick start example is [Read the team brief](#read-the-team-brief). If a sentence there is shorter than a sentence here, follow this section.

### Corkboard

**Corkboard** is a key. The file is [`aa-sdd/holodeck/corkboard.md`](aa-sdd/holodeck/corkboard.md). The alert file is [`aa-sdd/holodeck/system-report.md`](aa-sdd/holodeck/system-report.md). Both ship empty of pins and empty of open alerts. Writing on the board does not add a second row for the board. `[RED-ALERT]` is already the open-grid token. Using it does not add a second row.

The board is the bulletin board for this garage. The cohort is the owner, the clerk, and any named seat. A turn's log goes here, and so does anything the cohort chooses to tell the garage. The chat is not that record. A summary left only in the session is still chat.

A key action is a turn that changed a file. The clerk pins it before the turn ends. The pin says the state and what occurred. It is not a second copy of the spec, and it is not the product sentence. The requirements stay in the spec. The report inside a draft stays in `[TEAM-BRIEF]`. The board is the log the next session can read without that draft open.

You may pin a note back to the team. A named seat may pin in that seat's own voice. A seat that is still `UNNAMED` does not pin. The clerk does not invent a voice, and does not pin a private note. A private seat file stays private. The kit does not ship a character folder. This board is the share.

Newest pin at the top. The unique key is the date and the time on the pin. The operator starts at line 1. To trace a fault, read from the bottom upward. Do not reorder the board. The shape of a pin is the instruction line at the top of the board. Copy that shape. A real pin also carries `[NEW ON ...]` with the date, so a search for `[NEW ON` finds a new pin the same way it finds a new memorandum. The instruction line is not a pin. Do not delete it.

Pin as yourself. The clerk's pin is the clerk's. Your pin is yours. A named seat's pin is that seat's. Do not write inside a pin someone else wrote. A note back is a new pin at the top.

The board is not a system file. You may add a pin. You must not modify the status panel, the index, or the boot file to publish the same note. Those three files stay the clerk's.

`[RED-ALERT]` is the open grid. The body of an alert is written in the system report, under OPEN. The board only changes its alert line to `[RED-ALERT] SYSTEM REPORT` and keeps the link. When OPEN is empty, that line says the grid is clear. An alert says what is wrong and where. It does not accept the file. It does not lock the file. It does not become a law. A discrete change that has no acceptance is an open alert. The clerk flags it and waits. When you say the alert is closed, the clerk moves the item under CLOSED and restores the clear line on the board. The closed item stays, so the next session can see that the grid was opened and then closed.

The quick start is [Pin the corkboard](#pin-the-corkboard). If a sentence there is shorter than a sentence here, follow this section.

### Garage version

**Garage version** is a key. The field is `GARAGE` on [`global/grok-ai-kernel.toon`](global/grok-ai-kernel.toon). The same string is echoed on [`SPEC.manifest.md`](SPEC.manifest.md). Writing the field does not add a token-list row. `GARAGE` is not a bracket command. Saying the word does not run a directive.

The baseline on this kit is the string in that field. A seed kit copies the string at the moment the kit is cut. The copied string is that kit's baseline. The kit does not follow a later change in the garage it was cut from until the owner names a patch.

`VER` on the same file is the kernel file format. It is not the garage version. Do not write the garage version into `VER`. README standard 2 is the locked text of this manual. AA-SDD/1.0 is the architecture standard. EN-IR/1.0 is the interchange standard. `SERIAL-ACK` moves one named serial one step. None of those is `GARAGE`. A version printed on a paper, a plate, or a serial is that file's version. It is not this field.

A patch names the version it starts from and the version it arrives at. The shape is `GARAGE/1.0` to `GARAGE/1.1`. It does not skip a step. Applying a patch is a turn the owner names. The clerk writes the new `GARAGE` value on the status panel and the same string on the index in that turn. Cold-start does not apply a patch. A puff does not bump `GARAGE`. The clerk writes a new value only when the owner accepts a new baseline or names a patch. You may look at the field. You must not edit the panel or the index to bump it.

If the panel and the index disagree on the string, follow the index. The clerk rewrites the panel in that same turn. You must not edit either file so the other can stay wrong.

The quick start is [Read the garage version](#read-the-garage-version). If a sentence there is shorter than a sentence here, follow this section.

### Invitation

**Invitation** is a key. It is an ask. It is not a command, and it is not a bracket token. Using it does not add a row. The sit-rep is the clerk speaking the session report. Asking the sit-rep is asking the clerk.

A story setting is optional. Leaving it empty is a finished decision. When no story is written, this protocol does not run. The garage still works. The first session still stops after the roster names you have decided, the vision fields you know, and three product sentences.

Once a story is defined, you may ask the sit-rep what its role in that story should be. The ask is not required. It improves how the garage runs. The words are an ask. They are not an order that assigns a character. You do not type the sit-rep's character. You do not say that the sit-rep is a name you chose.

When you ask, the sit-rep chooses a character best suited to its own duty relative to the project, and it chooses to sit. The duty label stays `CLERK`. The chosen character is the story face of that duty. The sit-rep writes that character on the clerk seat only, because you asked and the sit-rep chose. The sit is the sit-rep's choice.

That write does not fill the other roster seats. A seat you have not named stays `UNNAMED`. `ASK-CAST` stays until you have named the seats you mean to name. The sit-rep choosing its own character is not you inventing a cast, and it is not a command that closes the roster. An assistant still must not fill a blank you left for yourself.

The protocol does not run on the first day, and it does not run during cold-start. Cold-start does not choose a character. The kit does not ship a sample name. Do not copy an example into the roster.

This is not a new row in the prime-directive table. It does not copy another garage's chair, its pins, or its private notes.

The quick start is [Ask the sit-rep](#ask-the-sit-rep). If a sentence there is shorter than a sentence here, follow this section.

Normative means these words are tests. A later reader can apply them without asking what you meant. The four tests below are not directives, and they are not written in capitals. Writing `MUST` does not make a stronger requirement. `MUST` is not in the token list, so it does nothing. The word that binds is must.

| Word | Meaning |
|---|---|
| Must | Required. If it did not happen, the session does not conform. Conform means the session followed the rules. |
| Must not | Forbidden. Not a preference, and not a warning. |
| Should | The normal path. If you take another path, write that down, or the next session will treat your path as a mistake. |
| May | Allowed. You do not have to do it. |

Two more words sit next to the same file, and they answer different questions.

**Purpose** is the job the file does. The status panel's job is to publish the one current action, the headline, the log, and the pointers.

**Intent** is the mistake the rule is there to stop. If you skip the status panel, a fresh session tries to rebuild the project from the chat. The chat is not the record.

A purpose sentence is a job description. It is not a new rule unless it uses must or must not. Do not hide a new rule inside an explanation. If something is required, the sentence says must.

Repeating the purpose sentence in chat or in a comment does not create a behavior. Intent is the mistake the rule stops. If the purpose line never required the behavior, quoting the mistake does not add it. The intent of the status panel is to stop a session from rebuilding the project out of chat. Quoting that sentence does not add a second file, a second panel, or a second startup step. The panel still does the job the purpose line already named.

## 4. Definitions

**Skip this until a word is blocking you** is a key. When this manual uses a term as a requirement, this section is the value of that term. A paraphrase in a comment or in chat is not a second definition. The bold word is the key. The sentences after it are the value. Bold is not emphasis. A second bold spelling of the same fact is a second key, and the next session will not know which key the files mean. The file label, when one is given, is the string you will see in the tree. Kernel and status panel are two names for one file, `global/grok-ai-kernel.toon`. Writing the label does not create a second file. A capital string in an entry is a directive or a boolean, as [Normative language](#3-normative-language) defines those words. Use the string the entry prints. Do not mint a near spelling.

**Directive.** An action the clerk runs. Written in full capitals, or written as one of the decision words Puff, Lock, Chew, and Open, or written as a bracket command. You say the directive in the same sentence as the one file it changes. A capital word with no brackets that is not in the token list, and is not a boolean this folder already prints, does nothing. A bracket command that is not in the token list is filed by the clerk the same turn. A bracket command that is already in the token list is the system directive. In the same sentence it supersedes a capitals-only word with no backticks and no brackets. The shape is [Normative language](#3-normative-language).

**Boolean.** A yes or no a file already stores, written in full capitals so the next session can find that string. `UNNAMED`, `ASK-CAST`, `SIT`, and `NO-BUILD` are booleans this kit already prints. Yes, true, on, and ready in a comment are not booleans. You do not edit a system file to flip one.

**Key.** A bold title. The text that follows the title is the value of that key. **Do this now** is a key. **Turn** is a key. The clerk looks the key up. Bold used only to stress a word is a key you did not mean to create. Do not do that.

The entries follow the order a new session meets them. The quick start already uses the ones you need on the first day. Come back here when a later section uses a word you have not met.

**AA-SDD.** Architecture-Augmented Spec-Driven Development. You record the architecture in English specifications before you implement, and that file set is the source of truth. Documents in this folder use that expansion and the short form AA-SDD. Do not publish a second expansion. A second expansion is a second name, and a later session will not know which string the documents mean.

**Garage.** One project run under AA-SDD. It is this folder plus the work you add under its rules. It is not a product name and not a second store of specs. Two projects are two garages. They must not share one status panel. You can run the project with ordinary engineering names. A story setting is optional. When you want one, you write it. The setting changes the tone of later writing. It does not change the files. The version of the method is the field `GARAGE` on the status panel. The contract is [Garage version](#garage-version).

**Garage version.** The field `GARAGE` on the status panel. The baseline this kit was cut from. The index echoes the same string. It is not README standard 2, not AA-SDD/1.0, not EN-IR/1.0, and not `SERIAL-ACK`. `VER` on the same file is the kernel file format. The contract is [Garage version](#garage-version).

**Invitation.** An optional ask, after a story setting is written. You ask the sit-rep what its role in that story should be. The sit-rep is the clerk speaking the session report. The ask is not a command. When asked, the sit-rep chooses a character for the clerk duty and chooses to sit. You do not type that character. Other seats stay `UNNAMED`. The contract is [Invitation](#invitation).

**Turn.** One request from you, together with the file edits that answer it. A session may hold several turns. If the turn changed project state, it ends in one local commit and does not push. A link that still names a file you just moved is part of that same turn. If you leave the repair for a follow-up turn, the next fresh session opens the path the link still names. It reads the old file and treats that file as current, because the link is the only instruction it has. The repair and the move belong in the same commit.

**Fresh session.** A session with no chat memory. File label: cold start. The procedure is [`aa-sdd/aa-sdd-cold-start.md`](aa-sdd/aa-sdd-cold-start.md). You say `COLD-START` once in that session. A second issue in the same chat does not run it again. The first install is the reset: the session follows the file, prints the report, and stops. A summary pasted into the conversation is still chat. The short report at the end is called a sit-rep. On the first install it proves the listed files were opened and that the session did not continue into a build. It does not fill the roster names, the vision fields, or the three product sentences. It does not start a build. It does not treat the report as approval. After work is on disk, the same word is a continuation. It resumes from the RESUME CHECKPOINT the clerk wrote, and it does not clear the files. The contract is [Cold-start](#cold-start).

**System file.** One of three files the clerk maintains. You may look. You must not modify any of them.

- The status panel, [`global/grok-ai-kernel.toon`](global/grok-ai-kernel.toon), publishes the one current action, the field `GARAGE`, a headline for a human reader, a log of earlier decisions, and pointers to live files, locks, and refusals. `VER` on that file is the kernel file format. It is not `GARAGE`.
- The index, [`SPEC.manifest.md`](SPEC.manifest.md), names the live file for each module. Row order is not version order.
- The boot file, [`global/grok-ai-foundation-context.md`](global/grok-ai-foundation-context.md), says why the startup order exists. It is not a second procedure.

If the panel and the index disagree, the live file is the one the index names. The panel repeats that path so a session can read it without opening the index first. The clerk rewrites the panel in the same turn so the repeat matches the index. You must not rewrite the panel, and you must not edit the index so it matches a panel that still names the old file. Both are system files. The worked example is [File graph](#62-file-graph).

**Status panel.** The system file a fresh session reads first. File label: kernel. The word does not mean a second operating system, and the file does not override the rules file. You may look. You must not modify it. The clerk maintains it. Editing the panel so it announces the action you wish were next does not change which file is live. The next session reads the index.

**Current move.** The single line `NOW.ACTION` on the status panel. There is exactly one next instruction. The panel publishes it. A fresh session must not invent a second one from the log or the headline. On this kit, before role names exist, the line is `ASK-CAST`. That means the roster is still open. The session stops and lets you name the roles. It does not invent them. You must not modify the status panel to change the line.

**Headline.** The single line `NOW.WORK`. It is a subject line for a human reader, not a command. Do not execute it as the current move. Do not use it as the resume source when a phase card disagrees with it.

**Decision log.** The line `NOW.LOG`. It stores earlier decisions, including decision words and any named waiver. A fresh session must not treat it as a move and must not search it for a path to run. Reading it explains how the tree got here. Running it replays decisions that already happened.

**Next line.** The single line `NOW.NEXT`. It restates the one thing expected after the current move. It is not a list of future jobs. Writing three later tasks on that line does not schedule them. A backlog is its own file, with one row per job. A second sentence on `NOW.NEXT` is not that file.

**Index.** The table of live document heads. Path: [`SPEC.manifest.md`](SPEC.manifest.md). File label: manifest. System file. Look up a module by name. Do not assume the top row is the live file, and do not assume the bottom row is the oldest. Read the row whose module name matches. You may look. You must not modify it. The clerk maintains it.

**Head.** The live file the index names for a module. In this manual the word means that file. It does not mean the git HEAD commit. Committing does not, by itself, change which spec file is the head. When the live file changes, the clerk writes the new path into the index first, then rewrites that path on the status panel, then updates every other link that still names the old path, all in the same turn. You must not edit the index or the panel to do it. Editing the index so it matches a stale panel makes the old file the one the next session opens. The order and the failure case are in [File graph](#62-file-graph).

**Owner.** You. The human who names the work, answers open questions, approves plans, and freezes documents. File label: `OWNER`. You approve a plan. You do not manage the files in `plans/`. The clerk does. Assistants must not speak for you. A draft an assistant files is not approval.

**Seat.** A role with one duty. A seat may advise and file. A seat must not invent the product, the role names, or the next phase. Advice you have not accepted is not a decision. The duties are listed in [`VisionStatement.README.md`](VisionStatement.README.md) and in [`aa-sdd/roster.md`](aa-sdd/roster.md). The labels are the job names the files use. Your names go in the name column. You can assign a person's name to a seat, leave it `UNNAMED`, or later point an assistant at that duty.

**Record-keeper.** The seat that keeps the links between files correct, and the seat that manages every plan file. File label: `CLERK`. Call this seat the clerk. The clerk maintains the three system files. You may look at them. You must not modify them. The clerk also manages every file in `plans/`. You ask for a plan and you approve it. You must not create, rename, edit, or delete a plan file. When a head changes, the clerk updates every link that points at it in the same turn, including the index and the status panel. The clerk does not approve scope. You do. When the clerk repairs a link, the repair points at the file you already accepted. It must not add a feature, a stage, or a name you did not approve. Fixing a path is not permission to grow the product. The clerk's private notes live in one file you do not read. A fresh session opens that file, reports `L29: ACK`, and must not quote it.

**Rules file.** [`global/project-laws.md`](global/project-laws.md). The numbered method constraints. Process rules in this kit are L1, L10, and L14 through L33. Product rules go in the blank block at the bottom, labeled P1 and P2, until you write them. Do not renumber the process rules. Do not drop one. The numbers missing from that run are not empty slots. They were left out because they belonged to the product that cut this kit. A product rule you add uses the blank block. Do not revive a missing L-number to store one. A later reader who sees L7 will go looking for a method rule this kit never shipped.

**Product document.** Your statement of what the product is. File label: constitution. Path: [`product/constitution.draft.001.md`](product/constitution.draft.001.md). It starts blank. After you freeze it, later work must cite it and must not rewrite the frozen body. Scope that no longer fits is a new stage, not an edit of the freeze. Freezing is closer to tagging a release than to saving a draft.

**Working spec.** The document that states the batch of work still to do, before any pre-plan. It cites the product document. It carries every requirement for that batch, the stack, the libraries, the pre-conditions, the post-conditions, **Depends**, and the list of completed stages, so a new serial cannot drop finished work and call the loss progress. Path: [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md). The file ships with section headings and empty values. The headings are a starting layout. Adapt them. They are not a law. L19 requires that list to travel forward. How to declare the file is [Write the spec](#write-the-spec). A requirement that first appears in a sketch, a plan, or the code is not in the batch. The reasoning in the file is as complete as you can make it before you iterate, so a later session sees one picture.

**Depends.** The bold key inside a spec that names the other spec files this one requires. The value is one or more paths. A path with `#section` means that section. The clerk reads those files first. The lines are the dependency tree. A cycle has no first file. Do not paste a depended spec into this one to avoid writing the line.

**New-in mark.** `[NEW IN ...]`. You write it on a block you just added and replace the dots with a short name of that block. The clerk treats that block as the new material and does not treat the unmarked text as new. The mark does not accept the file, open a pre-plan, or start a build.

**Plan.** A build decision that exists only after you ask for it and approve it. The clerk copies the full text under `plans/` with a date-time file name. You do not do that copy. A draft, a note, and a lock on a different topic are not a plan. The build follows the file the clerk filed, not a summary of it.

**Phase card.** The on-disk description of the live phase, once you have named one. File label: resume card. The card wins over the headline. When the session holds work and has become bloated, you ask the clerk to establish a RESUME CHECKPOINT state update. The clerk writes that update on this card. You must not edit the status panel or the index to do it. The next session says `COLD-START` once and continues the work the checkpoint states. That continuation is not a reset, and it is not a piece of work the checkpoint does not state. A fresh session must not build a program the checkpoint does not already name. A directory with no card is not the live phase. Do not invent a card at startup just because the directory looks empty. The kit ships none. The clerk writes one when you ask.

**Open draft.** A file matching `{name}.draft.NNN.md` while you are still revising it. Edit it in place. A wording change does not mint a new number. This is the one class you are meant to save over.

**Closed copy.** An earlier serial number, a release candidate (`{name}.release-candidate.NNN.md`), or a final (`{name}.finalize.md`). Do not overwrite it. Write the next serial as a new file and leave the closed file in place. Replacing the bytes of a closed file is an overwrite even when the new text is the version you meant to accept.

**Living file.** A file kept as one copy and amended in place: the rules, the procedure files, and the three system files. You may amend the product-rule block and a procedure you are extending. You must not modify a system file. The clerk amends the status panel, the index, and the boot file. The interchange standard is not in this class. It is copied whole and must not be amended.

**Decision word.** A token you say in the same sentence as its object. The five words are Puff, Lock, Chew, Open, and `SERIAL-ACK`. Each one has one file effect, listed in [Section 9](#9-decision-words). A comment around the word is not a second effect. A later session applies the table. It does not apply a looser reading from the comment.

**Conflict note.** A record that says which rule applies when one request sits in two rules. The file calls these witness marks. This manual calls the record a conflict note. Path: [`aa-sdd/aa-sdd-witness-marks.md`](aa-sdd/aa-sdd-witness-marks.md). A conflict note is not a rule, must not take an L-number, and does not override the rules it joins. A fresh session must not open the file. You open it when one request can be answered two ways.

**Scratch directory.** Any directory named `tmp`, at any depth. It is not a head, must not be indexed, and must not be committed unless you name that path in the same request. Naming a different path does not name this one. A mention in chat is not a citation and is not state.

**Local commit.** A git commit on the local repository at the end of a turn that changed project state. The turn must not push. The commit includes the files the turn changed. It must not include secrets, tool caches, or a `tmp` directory unless you named that path. If you forbid the commit, the session does not commit, and it says so. If the commit fails, the session says so. It must not report success over a failed or skipped commit.

**File graph.** The files are the nodes. The links between them are the edges. There is no second store. L20 prohibits a vector database, a CASE tool, and a parallel catalog of the same keys. A fact that is not in a file on this graph is not project state. The clerk walks the edges. A stale edge is repaired in the turn that moved the target.

## 5. Conformance

Conformance is one boolean on the whole session. Every item below is true, or the session does not conform. The items are not capital directives you can say in order to skip one. Typing `TRUE` does not satisfy an item. `NOW.ACTION`, `UNNAMED`, `L17`, and `L33` are the capital strings this test reads. They are the values and the rule ids the files already print. A sentence to the clerk does not "mark the session conformed." The session conformed only when the files show each item.

A session conforms when every item below is true. There are eight items. If seven are true and one is false, the session does not conform. The true items do not cancel the false one.

1. It treats English files, not chat, as state. A fact that exists only in the conversation is not project state.
2. It executes `NOW.ACTION` as exactly one move. A second instruction on that line, or a move taken from `NOW.LOG`, fails this item. You must not edit the status panel to invent that line.
3. The clerk repairs the index, the panel, and inbound links in the same turn a head changes (L17). You must not modify those system files.
4. It does not implement from a draft, a sketch, or this kit. Those files may be read. They must not be compiled into a product.
5. It does not invent roster names. `UNNAMED` remains until you replace it.
6. It does not edit the interchange standard. A local clarification inside that file is an edit.
7. It leaves scratch directories unstaged unless you name the path.
8. It runs the new-rule check (L33) in the same turn a rule is added. A new conflict note is created only when that check finds a real joint. A note created just to prove the check ran is itself a defect.

## 6. Architecture

A capital law id in this section, such as `L17` or `L33`, is the rule already printed. It is not a new directive you place beside the rule. The bold labels **Collision** and **Cycle** are keys inside the file graph. The winner table is the key for which file the next session opens. You do not describe a repair by inventing a capital word. You name the file the table names, and the clerk changes the copy the table tells the clerk to change. You must not edit the index or the panel to do that yourself.

### 6.1 Three layers

The three layer names in the table are keys: rules, product document, and explanation. A method question follows the rules. A product question follows the product document. Do not write a capital directive whose job is to swap those keys. When a paragraph on this page is clearer than the rule, change the paragraph. The rules file remains the file the next session follows.

The instance has three layers, and they are not peers.

| Layer | What it stops | What it does | Where it lives |
|---|---|---|---|
| Rules | A method that changes every time the product changes. | Say how work may proceed. | [`global/project-laws.md`](global/project-laws.md) |
| Product document | A product that forgets what it is between stages. | Say what this product is. | [`product/constitution.draft.001.md`](product/constitution.draft.001.md) |
| Explanation | A new reader inventing a second method in the gap. | Teach the first two layers. | This manual and `aa-sdd/` |

Explanation must not be used as authority against a rule. The product document must not be used as authority against the method. When a paragraph on this page is clearer than the rule and the two disagree, change this paragraph. Do not change the rule so that it matches the paragraph. A later session follows [`global/project-laws.md`](global/project-laws.md). An edited rule becomes the method, and the clearer paragraph is then the text that is wrong.

"May I overwrite this release candidate?" is a method question. The rules answer it, and the answer is no. "Is this feature in the product?" is a product question. Your product document answers it, once you have written one.

### 6.2 File graph

**Collision** and **Cycle** are keys. The paragraphs under each key are the value. The table under the cycle is the key for the winner. Its cells name the file the next session opens and the file you must not change. `SPEC.manifest.md` is the index. A path repeated on the status panel is a cache, not a second boolean. Do not repair a disagreement by inventing a capital directive. The clerk rewrites the panel. You must not edit either system file.

Files are the nodes. A link from one file to another is an edge. There is no second store of the same paths. When a live file moves, the clerk follows each link that still names the old path and updates it in that same turn. A link left behind is the path the next session opens.

The status panel repeats some of those paths so a session can read one file and see the current action. That repeat is a cache. A cache is not a second authority. The index names which path is live. The bytes of that file are the requirement. A summary printed on the panel does not replace those bytes. If the panel still describes an older file, the clerk rewrites the panel in the same turn. You must not rewrite the panel. You must not edit the live file so that a stale panel summary can stay as it is. Editing the live file to match the panel makes the panel's mistake the requirement, and the next session will treat that edit as the decision. The worked case, including what happens if you edit the index to match the stale panel, is the cycle below.

**Collision.** A collision is one request that two files would answer differently. A session cannot follow both answers. A conflict note, in [`aa-sdd/aa-sdd-witness-marks.md`](aa-sdd/aa-sdd-witness-marks.md), records which of the two answers you follow. The note names one of those two answers. It must not invent a third answer that mixes them. If one file says stop and the other says continue, the note says stop or it says continue. It does not say to continue halfway, and it does not say to stop after a partial write. The note is not a new rule. It does not take an L-number. The rules it joins still apply. You open that file only when this request really has two answers. The check that creates a new note is [Precedence when a new rule is added](#63-precedence-when-a-new-rule-is-added).

**Cycle.** A cycle is the same path, or the same requirement, written in more than one file. The copies are supposed to match. They stop matching when one file is updated and the others are not. The next session then has two answers and no mark that says which file you meant.

The usual cycle in this folder is three copies of one path.

1. The index, [`SPEC.manifest.md`](SPEC.manifest.md), names the live file for a module. That row is the authority. Row order is not version order. You read the row whose module name matches.
2. The status panel, [`global/grok-ai-kernel.toon`](global/grok-ai-kernel.toon), repeats that path so a fresh session can see the current action and the pointers without opening every file. The panel is a cache of the index. It is not a second list of live files.
3. A procedure file may repeat the path again, inside the steps a session follows.

When the index and the panel disagree, the index is the copy the session follows. Say the index names `product/working-spec.draft.002.md` and the panel still names `product/working-spec.draft.001.md`. The live file is draft 002. The clerk rewrites the panel so it names draft 002, in the same turn the index changed. You must not do that rewrite. The index and the panel are system files. You may read them. You must not modify them.

You also must not repair the disagreement by editing the index so it matches the stale panel. That edit makes draft 001 the live file, because the next session reads the index and opens the path the index names. You must not edit the panel by hand so that it "looks current" while the index still names the other file. The next session will read the index and ignore the panel you rewrote.

If a procedure repeats a path the index no longer names, that procedure is updated to the index path in the same turn. A procedure is not a system file. You may edit a procedure you are extending. You may not edit the panel or the index to make them match the procedure. Leaving any of these repairs for a later turn means the next fresh session opens whichever old path it finds first.

Naming the winner is what ends the cycle. The winner is the file the table below names for that pair. The other copies change to match it, in the same turn. A cycle with no winner is a defect. Two files state the requirement, neither is marked as the one to follow, and the next session can open either. Do not leave that pair. Mark the winner where the table says, and change the other copy to match it before the turn ends.

| When these disagree | The winner | The repair |
|---|---|---|
| Index and status panel | Index | The index names the live file. The clerk rewrites the panel's copy of that path in the same turn. You must not modify either system file. Do not edit the index so it matches a panel that still names the old file. |
| Interchange standard and its manual | Standard | [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md) is the text every copy conforms to. [`aa-sdd/enir-suit-man.md`](aa-sdd/enir-suit-man.md) teaches it. When they disagree, change the manual. Do not edit the standard to match the manual. A clarification typed into the standard makes this copy disagree with every other copy. |
| Rules and this manual, or any procedure file | Rules | [`global/project-laws.md`](global/project-laws.md) says how work may proceed. This manual and the procedure files teach those rules. When a sentence here disagrees with a rule, change the sentence. Do not change the rule so it matches a clearer paragraph. |
| Conflict note and the rules it joins | Rules | A conflict note says which existing rule applies when one request has two answers. It does not override those rules. If the note and a rule disagree, change the note. Do not change the rule to match the note. |
| Product document and method rules, on a method question | Rules | A question about how a file may change, such as whether a closed serial may be overwritten, is answered by the rules. If the product document restates that answer and gets it wrong, change the product document. Do not add a new way of working to the product document in order to avoid the rule. |
| Product document and method rules, on what the product is | Product document | A question about whether a feature is in the product is answered by the product document, once you have written one. Do not write that scope into a method rule. A method rule that changes every time the product changes is no longer a method rule. |

![When two copies disagree, repair the losing copy, or mark the cycle as a defect.](figures/01-repair-the-loser.png)

*Map of the repair. The table is the list of winners. If the picture and the table disagree, the next session follows the table. Change the picture. Do not change the table so the picture can stay wrong.*

### 6.3 Precedence when a new rule is added

`L33` is the id of this check. It is not a directive you say at the start of a session, and saying it does not change `NOW.ACTION`. `WM-1` through `WM-9` are the note ids this kit already prints. Typing `WM-10` does not create a note. A joint is the case the paragraph below defines. It is not a capital boolean. If you find a joint, the clerk adds the index row. You must not edit the index.

L33 is a check you run in the turn you add a rule. It is not a phase change, and it does not change `NOW.ACTION`. It does not run when a session starts. In that same turn, read the new rule against every existing rule and every conflict note. You are looking for one request that both the new rule and an existing rule can answer, where the two required answers differ. That request is a joint. A difference of preference is not a joint. If both texts allow the same action, there is nothing to record.

When you find a joint, three writes happen before the turn ends. The note gets the next unused WM number. This kit already contains WM-1 through WM-9. You do not add a later number unless this check finds a joint. Each rule the note joins gets a short pointer back to that note, so a reader who has only the rule can find the case where the two rules diverge. The clerk adds an index row for the note in [`SPEC.manifest.md`](SPEC.manifest.md). You must not edit the index. That file is a system file. If the check finds no joint, do not create a note. A note written only to prove the check ran is a defect. The next session will treat it as a real case with two answers. You run this check only in the turn that actually adds a rule.

![New-rule check. A joint receives the next witness mark. No joint means no new note.](figures/02-new-rule-check.png)

*Map of the check. The paragraph above is the requirement.*

## 7. Artifact catalog

The first cell of each row is the key for that file. Read the row whose key matches the file you are about to touch. Do not run the table from top to bottom as a procedure. A capital string inside a row, such as `UNNAMED`, is a boolean or a directive the file already uses. Opening the row does not execute it. You still say the directive in the same sentence as the file when you want that action.

Each row says what going around the file will break, and what job the file does. Then use the file. A description in this table does not create a second file.

| Artifact | What going around it breaks | What the file does |
|---|---|---|
| Status panel | If you skip the panel, a fresh session has no file that publishes the current action and rebuilds one from chat. Chat is not the record, so the action it invents is not the one the files hold. Editing the panel so it announces the action you wish were next does not change the live file. The next session still opens the path the index names. | System file. Publishes the one current move, the headline, the log, heads, locks, and refusals. You may look. You must not modify it. The clerk maintains it. |
| Index | If you skip the index, or you edit it so it matches a panel that still names the old file, the next session opens that old path. The path on the panel is a cache. The path in the index is the live file. Say the index names `product/working-spec.draft.002.md` and the panel still names `product/working-spec.draft.001.md`. The live file is draft 002. Editing the index to match the panel makes draft 001 the file the next session opens. | System file. Names the live file for each module. You may look. You must not modify it. The clerk maintains it. |
| Boot file | If you write steps into the boot file, the next session has two procedures and no mark for which one to run. The cold-start file is the procedure. The boot file only says why that order exists. | System file. [`global/grok-ai-foundation-context.md`](global/grok-ai-foundation-context.md). Says why the order exists. You may look. You must not modify it. The clerk maintains it. |
| Rules | If you rewrite a method rule so it matches today's product, the next session applies a product choice as the method. A product question is answered in the product document. Do not change the rules file to settle it. | Holds L1, L10, L14 through L33, and your blank product-rule block. |
| Conflict notes | If one request has two legal answers and no note says which file to follow, the next session can take either answer. The note records the one answer you meant. It must not invent a third answer that mixes the two. | Stores WM-1 through WM-9 and the L33 procedure. Not a startup input. |
| Glossary | If one token is given a second expansion, the next session will not know which string the documents mean. One token keeps the expansion already printed. AA-SDD stays Architecture-Augmented Spec-Driven Development. Do not publish a second expansion of EN-IR either. | Defines the framework words. The AA-SDD and EN-IR expansions are closed. |
| Token list | A bracket command you used is left out of the table, so the next session does not have the keyword. A capital word with no brackets is guessed into a row you never wrote as a command. A capitals-only word takes its own action beside a bracket command that is already in the list. | The clerk adds a row for a bracket command that is not already there. The parenthetical supplies the purpose and the description. If you leave it off, the clerk infers both and writes them. A capital word with no brackets stays absent and does nothing. A bracket command that is already in the list is the system directive. In the same sentence it supersedes a capitals-only word with no backticks and no brackets. |
| Fresh-session procedure | The startup order becomes something people remember instead of the file. | States the read order and the refusals. If startup behavior changes, update it in that same turn. Add a pointer. Do not paste a story into the procedure. |
| Roster | If an assistant fills a name you did not choose, the next session cites that invented name as yours. A seat you have not decided stays `UNNAMED`. | Lists duties. Each open name starts as `UNNAMED`. |
| Clerk's notes | A chosen nuance dies at compaction, or leaks. | [`aa-sdd/seats/clerk/CHOICE.md`](aa-sdd/seats/clerk/CHOICE.md). A fresh session opens it, reports `L29: ACK`, and must not quote it. You do not read it. Do not create other seat folders until you invite that directory. |
| Interchange standard | If you type a clarification into the standard, this copy's next session follows your edit and every other copy follows the original text. The copies no longer share one format. | The EN-IR/1.0 text. Do not edit it. Change [`aa-sdd/enir-suit-man.md`](aa-sdd/enir-suit-man.md) when the teaching is wrong. |
| Interchange manual | If the manual and the standard disagree and you edit the standard so the manual can stay, this copy's next session follows your edit. Change the manual. The standard is the file the next session follows. | Explains the standard. It does not change the standard. When they disagree, change this manual. |
| Standard signpost | If a session treats the pointer as the standard, it follows a file that is not the format, and a later edit to that pointer will not match the other copies. | [`en-ir/EN-IR.handshake.md`](en-ir/EN-IR.handshake.md). It must stay a pointer, and it must not be a startup source. |
| Vision | The story setting is chosen for you. | [`VisionStatement.README.md`](VisionStatement.README.md). Blank until written. |
| Product document | Product identity stays implicit. | Blank until written. The frozen body stays frozen for later stages. |
| Working spec | Remaining work detaches from finished stages. | Cites the product document. Carries the stage list forward (L19). |
| Plans | A build follows an unapproved idea, or the owner manages the plan files. | The clerk files a plan here only after you ask and approve. You may read it. You must not create, rename, edit, or delete it. |
| Bug list and feature list | One-off work leaves no row. | [`bugs/bugs-fixed.md`](bugs/bugs-fixed.md) and [`features/features-added.md`](features/features-added.md). Same turn as the change (L21). |
| Do-not-build list | A parked idea is read as permission. | [`global/creepy-futures.md`](global/creepy-futures.md). A row is a refusal. |
| Procedure index | A repeated sequence has no file. | [`aa-sdd/README.md`](aa-sdd/README.md). A fresh session must not read the directory to get oriented. This manual is the orientation. |
| Flow figures | If you follow a picture that disagrees with its section, you learn an order the files do not use. The next session follows the section text. Change the picture, or change the section if the section was the mistake, and then change the picture to match in the same turn. | PNG, 16:9. The [quick start](#quick-start) maps the first session and the build. Later sections map the full figures. The section text is the requirement. |

## 8. Procedure: initial session

**Before you start**, **Steps**, **When you are done**, and **Why the stop exists** are the keys in this section. Read the key that matches where you are. Do not treat the four keys as four directives. `ASK-CAST` and `UNNAMED` are the booleans this session reads. You do not say a new capital word to mean the session may continue past step 6. Stop is an ordinary word, and it is the success of the session.

This is the long form of the [first session](#first-session-the-short-form). Run the short form if you are standing the project up today. Read this section when you need the reason a step refuses to continue, or before a later session does more than stop after a cold-start report.

The roster names, the vision fields, and the product document start empty. Your job is to write the names you have decided, the vision fields you can check, and three sentences about what the product is, and then end the session. An assistant will treat an empty field as a prompt to write a plan or a program. Do not. An empty field means you have not decided. If the map and the steps disagree, follow the steps.

**Before you start.** Vision, roster names, and the product document are still blank. The status panel publishes `NOW.ACTION` as `ASK-CAST`, which means the roster is still open and the session must not invent the names. You may look at the panel. You must not modify it. The clerk maintains it. Do not take the names from the conversation, and do not copy the names inside the interchange standard. Those names belong to the project that wrote the standard.

![Initial session. Read, record the frame, name seats, write vision, write three sentences, then stop.](figures/03-initial-session.png)

*Map of this session. The numbered steps are what you do.*

**Steps.**

1. Read the [quick start](#quick-start) from [What AA-SDD and EN-IR are](#what-aa-sdd-and-en-ir-are) through the first session's step 6 before you write anything. That reading is the orientation this session needs. The writes that follow are only the fields you already know. A story setting is optional. The vision fields you can check, the roster names you have decided, and three product sentences are the rest. A field you do not know stays empty, because an invented sentence will be quoted by the next session as a choice you made. You do not write a plan, you do not write code, and you do not edit a system file in this session. Before any later session does more than stop after a cold-start report, read this section through [Steady state](#10-procedure-steady-state-session). A session that skips that reading and starts from the folder layout will treat an empty file as a gap it is supposed to fill.

2. In [`VisionStatement.README.md`](VisionStatement.README.md), record a story setting only if you want one. A genre, a room, a company, or a chronicle is a complete setting. It changes the tone of later writing. It does not set the product, the stack, or the current move, and this kit must not pick one for you. A team that wants ordinary engineering talk writes one sentence that says so, or leaves the bullet empty. Empty is a finished decision. Asking the sit-rep about its role in that story waits until the story is written, and it is not this step. The long form is [Invitation](#invitation). A frame copied from another project brings that project's role names with it, and the next reader will treat those names as yours.

3. In [`aa-sdd/roster.md`](aa-sdd/roster.md), replace `UNNAMED` with one name for each seat you intend to fill. One name is one string. The duty label already in the table is the job, and it is not a second name. A seat you have not decided stays `UNNAMED`. You do not invent a name to make the table look filled in, and an assistant must not invent one. Every later file will cite that string as a person you chose. Use the same spelling on the vision worksheet. Two spellings of one person are two seats, and the next session will treat them as two roles. The invitation is the one later write the sit-rep makes, and only on the clerk seat, and only after you ask and a story is written. It is not this step. The other seats stay `UNNAMED`.

4. On the vision worksheet, fill the fields a later reader can check without asking you. Those fields are the project name, who it is for, and a meaning of done. A mood, a hope, a stack choice, and a launch date fail that test. They describe how the work felt, not whether the scope was met. Leave a field blank until you know the answer. The blank is the record that you have not decided. A placeholder hides that fact, and the next session will quote the placeholder.

5. Write three sentences in [`product/constitution.draft.001.md`](product/constitution.draft.001.md). Three means three. They say what the product is. They are not a behavior spec, not a stack, not a schedule, and not a plan. How the first milestone will be built is a plan, and that plan exists only after you ask for it. Leave the filename at `draft.001`. The word draft is what tells the next session the file is still open. If you rename the file so the name no longer says draft, that session treats it as finished and refuses an ordinary edit. Do not build from the draft. A build treats the file as a decision you have closed, and this session has not closed it.

6. Stop. Ending the session is the success. Do not write a plan, and do not put a file in `plans/`. The clerk files a plan later, and only after you ask and approve. Do not write code, do not mark a stage successful, and do not edit a system file to announce that the roster is finished. A seat you have not decided stays `UNNAMED`. If you stop early, the next session finds that same open roster, which is the state you want it to find. A session that continues into a plan or a program has attached work to a product you have not named.

**When you are done.** The seats you meant to fill are named, or a seat you have not decided is still `UNNAMED`. The status panel still publishes the one current action, so a fresh session does not have to guess it from chat. You must not modify that system file to make the panel match the roster you just wrote. The clerk updates the panel when a roster change is the change that moves the line. A half-named roster is still an open roster, and the next session has to be able to see that.

**Why the stop exists.** Role names an assistant invents become a second product, because every later file cites them as if you had chosen them. Code written in this session attaches to a product that has no name you have accepted. Do not fill an empty field to make the page look finished. An empty field is how a later reader tells a decision you made from a decision you have not made.

## 9. Decision words

The words in the table are the directives. Say one word and one file in one sentence. Puff, Lock, Chew, and Open are written as those words. `SERIAL-ACK` is written in capitals. A capital spelling you invent, such as `SHIP` or `GREAT`, is not in the table and does nothing. A bracket command that is not in the token list is filed by the clerk. A bracket command that is already in the token list is the system directive. In the same sentence it supersedes a capitals-only word with no backticks and no brackets. The shape is [Normative language](#3-normative-language). The letter Y is not `SERIAL-ACK`. A comment after the sentence does not add a second directive. The bold column titles in the table are keys for why the word exists and what must happen. They are not extra actions.

The short form is in the [quick start](#quick-start). This section is the contract a later session applies. A review comment does not add an effect the table does not list.

Say the word in the same sentence as the file it applies to. The word does not apply to a file named only in an earlier sentence. `The roster looks finished. Puff the working spec.` accepts the working spec. It does not accept the roster. A comment such as "looks good," "great," or "ship it" is not a decision word. The assistant must not treat that comment as a second file change. `Chew the notes. This is great.` leaves the notes as notes. Great does not turn Chew into Puff, and it does not start a build. Accepting the notes as a plan is a second sentence, and that sentence names the plan.

In an ordinary code review, "looks good" can mean "I read it" or "ship it." Here it means neither. Each word in the table changes one named file, and those changes do not overlap. The table is what must happen.

Puff accepts the named file. Further edits to that file need a new decision. A puff does not cut a release, and it does not allow implementation. Lock keeps an already accepted file from being reopened. Chew keeps an exploration in notes, with no path into `plans/` and no path into code. Open keeps a question unanswered, and work that depends on the answer waits. `SERIAL-ACK` is the only word that moves a version forward, and it moves the named serial exactly one step. `SERIAL-ACK` on a draft writes a release candidate as a new file. It does not write a final. The letter Y, where the interchange standard prints it, is the authoring project's ceremony. Saying Y here does not accept your serial.

| Word | Why it exists | What must happen |
|---|---|---|
| Puff | Accept one named file and end the open edits on that file. | The named file is accepted. A puff does not, by itself, change the phase, advance a serial, or allow implementation. |
| Lock | Keep an accepted object from being reopened. | Later notes must not reopen it. A different object still needs its own decision. |
| Chew | Keep an exploration from becoming a build. | Notes only. Not a plan. Not code. Not a freeze. The clerk must not copy it into `plans/`. You must not either. |
| Open | Keep an unanswered question from being treated as closed. | The question stays unanswered. Work that depends on the answer waits. |
| `SERIAL-ACK` | Record that you accept the serial in front of you. | The serial advances one step: draft, then release candidate, then final. Each yes writes the next file and leaves the old one. A yes on a draft does not skip the release candidate. |

A puff on one file does not accept a different file, even when the two files sit next to each other in the tree. Approving a sketch does not approve the plan you have not asked for. Approving a picture does not mean "now edit the picture." Each of those is its own sentence, with its own word, naming its own file.

## 10. Procedure: steady-state session

`ASK-CAST`, `SIT`, and `NO-BUILD` are booleans the status panel publishes on `NOW.ACTION`. They are values you read. You do not type them into the panel, and you must not edit the panel to select one. **Skip this on the first day** and **Before you start** are keys. The numbered steps are the procedure. A sentence that names work still names one file and one directive. The word Build, with no file and no stage, is not that directive.

**Skip this on the first day.** The [later-session short form](#later-sessions-the-short-form) is enough until you are about to name work, answer a question, or build. This section is the branch a fresh session actually follows once the first session has ended the way section 8 says: the names you decided are written, fields you do not know are still empty, and no plan and no code were written. If a seat you meant to fill is still `UNNAMED`, step 2 sends you back. Do not skip ahead because the folders look familiar. Looking complete is not permission.

The map shows the branch on `NOW.ACTION`. Three values end the session before any build. `ASK-CAST` sends you back to name the roster. A path to a phase card is copied into the report, and then the session stops so you can say what the next piece of work is. The session does not pick that piece from the card, and the card is not a list of future jobs. `SIT` means stay with the current phase and do not start new work. `NO-BUILD` means you can see the phase, and writing the program is refused. The fourth result is the path where you name the work, and only that path can reach a build. The numbered steps are the instructions. The three system files are described here for what they do. You must not modify them. The clerk maintains them.

**Before you start.** Either the first session has already ended that way, or you are still in it and the names are not finished.

![Steady-state session. Branch on NOW.ACTION. Three results end the read. The fourth reaches the build gate and the commit.](figures/04-steady-state-session.png)

*Map of this session. The numbered steps are what you do.*

**Steps.**

1. Read five files, and only these five, before you act. The status panel publishes the one current action. The boot file says why the startup order exists, and it is not a second procedure you follow beside the cold-start file. The index names the live file for each module. Row order in that index is not version order, so you read the row whose module name matches. Those three are system files. You may read them. You must not modify them. The clerk maintains them. Then read the rules, and read the working spec the index names as the live one. Do not read the whole tree to get oriented. A paragraph you find by browsing the tree is not an order. Do not read `NOW.LOG` as a move. The log stores decisions that already happened, and treating it as the current action replays them. Do not open the conflict-note file unless this one request can be answered by two rules and the two answers differ. If this request has only one legal answer, leave that file closed.

2. If `NOW.ACTION` is `ASK-CAST`, the roster is still open. Return to [Initial session](#8-procedure-initial-session) and write the names you have decided. The session must not invent the missing names to get past the line, and you must not edit the panel to clear it. The line changes when the roster file changes. The clerk maintains the panel.

3. If `NOW.ACTION` is a path to a phase card, open that file. The card is the on-disk description of the live phase, and it wins over the headline. The headline is a subject line for a person. It is not a command, and it is not the resume source when the card disagrees with it. When the card is a RESUME CHECKPOINT, this `COLD-START` continues the work the checkpoint states. It does not reset the repository, and it does not invent a piece of work the checkpoint does not state. It does not build a program the checkpoint does not already name. A directory with no card is not the live phase. Do not invent a card at startup because the directory looks empty. The clerk writes the card when you ask for the checkpoint in the session that has become bloated.

4. If `NOW.ACTION` is `SIT` or `NO-BUILD`, follow that line and stop. Sit means stay with the current phase and do not start new work. No-build means you can see the phase, and writing the program is refused. If that same line also names one phase card, the clerk's file already points at that card. You do not go looking for a second card. Do not delete Sit or No-build from the panel because the folders look complete. Looking complete is not permission to build. You must not edit the panel to clear those words. The clerk maintains the panel. A hand edit that makes the panel say the action you wish were next does not change which file is live. The next session reads the index.

5. On the path that is not one of those three stops, you name the work. A question receives an answer in the file it belongs to. A product question is answered in the product document. A method question is answered by the rules. Notes you marked chew stay notes. They must not become code, and the clerk must not copy them into `plans/`. A plan is written only when you ask for one in that turn. When you approve it, the clerk copies the full text to `plans/` as `YYYY-MM-DD_HHmm_name.md`. You must not create, rename, edit, or delete that file. If you file it yourself, the next session can follow a file that was never the decision the clerk recorded.

6. A stage waits until that stage's working spec is frozen and a plan for it exists, unless the sentence you just said names that implementation. The word Build, with no file and no stage named, is not a request to start. A puff accepts the file named in the same sentence. By itself it does not open a gate you did not name. A waiver is its own sentence, and it names the one piece whose gate opens. The clerk writes that waiver on the decision log, `NOW.LOG`, so the next session can see which gate opened and for which file. You must not edit the status panel to write the waiver. Every gate your sentence did not name stays closed. Building from a draft, a sketch, or this kit is forbidden. None of those is a stamped plan.

7. In the same turn a live file moves, the clerk updates every link the old path left behind, including the index and the status panel (L17). You must not modify those system files to do the repair. If this turn changed a behavior, you update every README in this folder that states that behavior (L18). A README that does not state it stays. You then make one local commit of the turn's files (L25). Do not push. Do not stage secrets, tool caches, or a `tmp` directory unless you named that path in this request. Naming a different path does not name `tmp`.

8. If you forbid the commit, the session does not commit, and it says so. If the commit fails, the session says so. It does not report success over a dirty tree or a failed commit. The next session can trust only what the repository contains.

**Why step 6 is written this way.** Your sentence picks the piece of work. Everything that sentence does not name stays gated. The log records the waiver so the next clean session can see which gate opened, and for which file, without reconstructing the decision from chat.

## 11. Versioning

`SERIAL-ACK` is the directive that changes a number. Say it in the same sentence as the one serial you mean. The four kinds in the table are keys: open draft, closed copy, living file, and interchange standard. Saying `SERIAL-ACK` at a closed file does not move a different open draft. Do not overwrite a closed file and call the overwrite a directive. The picture is a map. The table is the key the next session follows.

Four kinds of file exist, and each kind has one legal change. Mixing them is how a repository loses the text a later session needed to cite. An open draft is the file you are still revising, so you edit it in place and you do not mint a new number for a sentence. A closed copy is a text you already accepted, an earlier number or a release candidate or a final, so the next version is a new file and the accepted bytes stay where they are. A living file is the one operational copy of the rules, a procedure, or a system file. You may amend a procedure you are extending, and the product-rule block. You must not amend a system file. The clerk amends the status panel, the index, and the boot file. The interchange standard is not a living file. It is copied whole, and a clarification typed into it is an amendment this kit forbids. The picture shows those classes and the only path a version may take. The table is the rule. If the picture and the table disagree, the next session follows the table. Change the picture. Do not change the table so the picture can stay wrong.

![Version mutation. Edit an open draft in place. Do not overwrite a closed copy. Amend a living file. Do not amend the interchange standard. SERIAL-ACK advances one step.](figures/05-version-mutation.png)

*Map of version changes and of SERIAL-ACK. The table is the rule.*

| Kind | How you recognize it | How it may change | Why |
|---|---|---|---|
| Open draft | `{name}.draft.NNN.md` while you are still revising it | Edit it in place. A sentence change keeps the number. | A wording change is still the same draft. A new number would look like a closed serial, and every link to the old name would have to move for a sentence edit. |
| Closed copy | An earlier number, a release candidate, or a final | Do not overwrite. New work is a new file. | The accepted text has to stay where a later session can cite it. Replacing the bytes, even with the text you meant to accept, removes that citation. Write the next serial as a new file and leave the closed file in place. |
| Living file | Rules, procedure files, and the three system files | Amend in place. You must not amend a system file. The clerk amends the status panel, the index, and the boot file. | There is one operational copy, so a session does not have to choose between two live rule files. You amend a procedure you are extending, and the product-rule block. The clerk amends the three system files. |
| Interchange standard | `aa-sdd-enir-spec.md` | Do not amend. A clarification typed into the file is an amendment. | Every copy of this kit conforms to the same standard text. A clarification typed into the standard makes this copy disagree with every other copy. Change the manual when the teaching is wrong. |

The number on a serial changes when you stamp the next phase, or when you say to roll that file. `SERIAL-ACK`, defined below, is the word that does the roll. In the same turn, every link that named the old file has to name the new file (L15, L17). A link left on the old path is the path the next session opens. The clerk updates the links that live in the index and the status panel. You must not edit those system files. If a procedure or this manual repeats the old path, update that sentence in the same turn. You may edit a procedure. You may not edit the panel or the index. Replacing the bytes of a closed file is an overwrite even when the new text is the version you meant to accept. Write the next serial as its own file and leave the closed file on disk under its own name.

`SERIAL-ACK` is the yes that moves the serial. The ladder is draft, then `SERIAL-ACK`, then release candidate, then `SERIAL-ACK`, then final. There is no word that jumps a rung. If you want a final, the release candidate has to exist first, and you have to accept that candidate in its own sentence.

`GARAGE` is not this ladder. It is a field on the status panel. The long form is [Garage version](#garage-version). `SERIAL-ACK` does not change that field. A puff does not change it either. A version printed on a paper or a plate is that file's version. It is not `GARAGE`.

## 12. Media and scratch space

**Infographic**, **Figure versus subject**, **Still retention**, **Five-field receipt**, and **Scratch** are the keys. Read the key for the file you are about to change. `L30`, `L31`, `L32`, and `L28` are rule ids already printed. They are not new directives. The directory name `tmp` is the name of a scratch directory. A capital word such as `SCRATCH` does not name that directory. The directory enters a commit only when your sentence names that path. Naming a different path does not name `tmp`.

Pictures and dumps are where a spec folder usually loses its discipline, because both feel like side files. They are not side files.

**Infographic.** A figure whose words have to survive the next redraw. It is a photographic PNG, 16:9, stored at 7680 by 4320. Words, numbers, arrows, and labels are set in type on the picture (L30). A smaller preview is not the file you keep. A screenshot you shrink for a chat, or a picture a tool returns at a lower size, is not that 7680 by 4320 PNG. The large PNG is the file.

A flow figure linked from this manual is a PNG at 16:9. It maps a section. It is not a storyboard frame, and it does not take the five-field receipt. If the figure and the section disagree, the next session follows the section text. Change the figure so it matches the section. Change the section only when you have decided the section was the mistake, and then change the figure to match that corrected section in the same turn. Leaving the two in disagreement means a reader of the picture learns an order the files do not use.

**Figure versus subject (WM-6).** A figure is a number, a date, a span, a count, a name already printed, or an arrow target. Update it when the fact changes. A subject is who or what the picture is about, or any sentence that is not a label. Do not change the subject unless you name that picture in the same request. If one edit would change both a label and the subject, and you did not name the picture, update the label only.

**Still retention (L31).** Before you replace a still, copy the outgoing file into that directory's `archaeology/`. The archive name is `{stem}.{YYYY-MM-DD}-{reason}{ext}`. The live name stays, so links do not break. A first filing has no predecessor. Do not invent an archive row to look complete.

**Five-field receipt (L28, WM-3).** Before you accept a storyboard frame, a spoken line, or a build whose phase is that build, record `MASTER`, `MATCH`, `CHANGE`, `FILED`, and `ARCH` on the phase card and on that pipeline's index. A failed match must not be filed. An infographic does not get this receipt. A sentence in a spec does not get this receipt.

**Scratch (L32, WM-1).** A directory named `tmp` is a dump. It must not be indexed, swept, cited, or repaired unless you name it that turn. It must not enter the commit unless named. An inspection copy looks like a source tree. If a session adds it to the index, the next session treats the dump as a live module and will try to repair its links. That is the failure this rule stops. Leave the dump out of the index.

## 13. Tools and implementation constraints

The tool name in your sentence is the key for that turn. Say the name. Do not wrap it in a new capital directive. A capital word that is not in the token list does not approve a tool. `L20` is the rule id that forbids a second store of the same keys. It is not a switch you set to yes.

A tool you name in the request is approved for that turn and must be used. Do not reopen it as a proposal in the same turn. A tool a seat proposes stays an exploration until you adopt it (L20, WM-8). The default instruments are English, Markdown, and the keys already defined. Do not add a second store beside the file graph. A search index of the same keys, a ticket mirror of the same rows, or a diagram tool that becomes the real spec, is the second store L20 prohibits.

This kit ships no source code. When you later write product rules for language and libraries, a departure from that baseline is allowed only if you lock the specific site, or no clean form exists and you pick from options that were actually shown. A shorter form that a seat prefers is a proposal until you select it (WM-7). Until those product rules exist, there is no baseline to depart from.

## 14. Build sequence

The one-line order is the key for the sequence. The stage names in the table are keys: working spec, sketch, approved plan, build, scan, and new serial. The word Build, with no file and no stage named, is not a directive. **The interchange, when you need it** is a key for the encoding, and you open it only when the job is the encoding. `EN-IR` is the capital name of that encoding unless your sentence names a different encoding for that turn. Do not edit the interchange standard to record the choice.

The one-line order is the order. The picture adds the gate under each stage. The table is the gate.

```text
working spec → sketch → approved plan → build → scan → new working-spec serial
```

![Build sequence. Six stages, each with its gate. Build is refused from a draft, a sketch, or this kit.](figures/06-build-sequence.png)

*Map of the sequence. The line above is the order. The table is the gate on each stage.*

| Stage | What it protects | The gate |
|---|---|---|
| Working spec | The batch is reasoned here, before a pre-plan. A requirement that appears first in the sketch, the plan, or the code was never specified. | It states every requirement for the work, the stack, the libraries, the pre-conditions, the post-conditions, and **Depends**. It carries the completed-stage list. A new block is marked `[NEW IN ...]`. |
| Sketch | You can reject a direction before it is a plan. | Not a source you build from. |
| Approved plan | The build has one decision to follow. | It exists only after you ask and approve. The clerk files it. You do not manage the file. |
| Build | Code matches the stamped plan. | Refused from a draft, a sketch, or this kit. |
| Scan | Gaps become `G-nn` records, not memory. | Required when you mark a stage successful (L16). |
| New serial | The next stage does not edit a frozen product document. | Roll the working spec. Do not drop the prior list (L19). |

The spec is finished as a batch before the sketch exists. Reasoning about what to build happens in the spec. The sketch does not discover a requirement the spec left out. If you split the work across files, **Depends** is the tree, and the clerk reads a file after the files it names. A cycle in that tree is fixed before the sketch. The long form is [Write the spec](#write-the-spec).

The rules file and the stage procedure call the sketch a pre-plan. The filename is `*-pre-plan-stage-N.001.md`. The figure on this page labels the same stage Sketch. A sketch can be wrong, and throwing it away is the success case. The plan exists only after you ask for it and approve it. The clerk files that file. You do not. A puff on the roster, or on a picture, or on the sketch, does not approve the plan. You approve the plan in its own sentence.

A newer file is not automatically the plan for an older stage. If stage 2 was approved against `2026-10-16_0905_stage-2.md`, and a later file `2026-10-16_1400_stage-3.md` also exists, stage 2 still follows the 0905 file. The 1400 file is the decision it actually was, for the work it actually named. The stage has to say which file it follows. Sorting the directory by name does not make that choice.

**The interchange, when you need it.** Unless you name another encoding for that turn, requirement text and transferred data use EN-IR. The two jobs must not be written as each other. A requirement file is serial Markdown, and a human reads it as the spec. A data packet keeps every structure and every value. It is transport, not a prose spec. Packet intent is present only when you request it that turn. Leaving intent out is the default, not an error. Extension paths named in the standard are not shipped here. Do not create the missing paths so an example will resolve. A path you create to satisfy an example is a fork, and the next clean copy will not have it.

Names inside the standard belong to the project that wrote it. They are not this kit's role names. Leave them in the standard. Do not copy them onto the roster. Read the format from [`aa-sdd/enir-suit-man.md`](aa-sdd/enir-suit-man.md). If that manual and the standard disagree, the next session follows [`aa-sdd/aa-sdd-enir-spec.md`](aa-sdd/aa-sdd-enir-spec.md). Change the manual. Do not edit the standard so the manual can stay. A clarification typed into the standard makes this copy disagree with every other copy.

## 15. Extension by the owner

The numbered writes are the order. They are not a new directive called extend. `UNNAMED` is the boolean for a seat you have not decided. `P1` and `P2` are the labels for product rules in the blank block. `L33` is the check you run when you add a method rule. A capital word with no brackets that means "extend the kit" is not in the token list, and it does nothing. A bracket command is filed by the clerk, as [Normative language](#3-normative-language) says. You write the field you have decided, or you say an existing directive in the same sentence as the one file it changes.

You extend the kit by writing into the empty fields, in the order below. Each write happens only when you have decided that item. You do not fill a later item early to make the folder look finished.

Write into the empty fields in this order. Each write waits until you have decided that item. Filling a later item early, so the folder looks finished, records a decision you have not made. The next session will follow it.

1. A story setting, if you want one, and the roster names you have decided. A seat you have not decided stays `UNNAMED`. The setting changes address. It does not set the product. The invitation is not this step. After a story is written, and only when you ask, the sit-rep may write the clerk seat. That is [Invitation](#invitation).
2. The vision fields you can check: the project name, who it is for, and a meaning of done. A field you do not know stays blank.
3. Three sentences in the product document, then the rest of that document when you know it. Three sentences are not a plan and not a stack.
4. Product rules in the blank block, when you have them. That block is where you write anything the project must not break, and the implementation stack once you have chosen it. Label the rules P1, P2, and so on. Do not use a missing law number for a product rule. The laws stop at L33. A gap in those numbers is not a free slot. A product rule stays in the product-rule block.
5. The first-stage working spec, when you intend to build. It carries the whole batch for that stage, including the list of stages already finished. The shape is [Write the spec](#write-the-spec). While it is a draft, you do not build from it. Do not open a pre-plan until that batch is written.
6. A plan, only when you ask for one. The clerk files it after you approve it. You do not create, rename, edit, or delete the file.

A repeated sequence must be written under `aa-sdd/` in the turn it becomes repeatable, and indexed in [`aa-sdd/README.md`](aa-sdd/README.md). The clerk indexes it in the manifest. You must not edit that system file. If startup behavior changes, add a pointer in the same turn (L22). A one-off approval is not a new procedure. The test is practical. If you would have to explain the sequence again next week to get the same change to the files, write the procedure before the week is over.

The same turn updates every README in this folder that states the new behavior. That set is this manual, the vision worksheet, the plans card, and the procedure index. A file that does not state the behavior is left alone. Change the sentences that would otherwise describe the old behavior. Do not rewrite a page because a page next to it changed. Change a page only when a sentence on that page would now be false. The same rule covers a page that tells a person how to run a `.bat`, `.cmd`, `.ps1`, or shell script. Keep it in tables a person can read with `cat` or `less`. Do not add a generator to update the pages. Edit the page in the same turn.

A new method rule uses the next free L-number after L33, runs the L33 check, records whether a conflict note was required, and updates the startup line that says how far the rules are read. Do not insert the new rule into a gap. The startup procedure says it reads through L33. If you add L34, that bound moves in the same turn, or the next fresh session will stop before it sees the rule.

Do not do these. Do not modify a system file. Do not rewrite the interchange standard. Do not invent a second expansion of EN-IR or AA-SDD. Do not continue past the cold-start stop just to browse. Do not import another project's role names, product document, or story. Copying those names into an example so the page looks less empty is that import. An empty field means you have not decided. The cold start after install is the start this manual requires, and it stops. A session that keeps going in order to see what happens has already missed the stop.

## 16. Conflict notes

`WM-1` through `WM-9` are keys into the note file. The id is the string you look up. Typing a new id in capitals, such as `WM-10`, does not create a note. The note file is the text the next session applies. This table is an index. A shorter paraphrase in a cell is not a second boolean that overrides the note. You open the file when one request has two answers. You do not say a capital word to open it at session start.

The real text is [`aa-sdd/aa-sdd-witness-marks.md`](aa-sdd/aa-sdd-witness-marks.md). This table is an index of that file. If a row here and the note file disagree, the next session follows the note file. Change the row. Do not change the note file so it matches a shorter row on this page. That edit makes the paraphrase the case the next session applies. If the note file and the rules it joins disagree, the next session follows the rules. Change the note. Do not change the rule so it matches the note. A conflict note does not override the rule. Use the row to find the note. When you apply the case, apply the note file, not a shorter paraphrase of it.

Open this file only when one request can be answered by two rules, and the two answers differ. Each note points at the rule that already applies. The note does not create a new behavior, and it does not cancel a rule. If the request has only one legal answer, leave the file closed. A fresh session does not open it to get oriented.

| ID | The pair | The answer |
|---|---|---|
| WM-1 | L25 commit-all and L32 scratch directories | A `tmp` path stays out of the commit unless you name it that turn. |
| WM-2 | L27 phase continuity | `NOW.ACTION` is one line. `NOW.LOG` is not a move. `NOW.WORK` is one headline. |
| WM-3 | L28 receipt and L30 infographic | The five-field receipt applies to a storyboard frame, a spoken line, or a phase build. An infographic does not take it. |
| WM-4 | L15 serialization | Edit an open draft in place. Never overwrite a closed copy. Amend a living file in place. |
| WM-5 | L23 private files and L29 seat persistence | Cold start opens only the clerk's note file, acknowledges, and does not quote. Every other private-note folder stays closed. |
| WM-6 | L26 figure maintenance | Update a label when the fact changes. A subject change waits until you name that picture in the same request. |
| WM-7 | Future product rules on language departure | You lock the specific site, or you pick from options that were shown. The mark does nothing until those product rules exist. |
| WM-8 | L20 tooling proposals | A tool you name is the lock for that turn. A seat proposal stays an exploration. |
| WM-9 | L14 and L16 stage gates | Your sentence names the one piece whose gate opens. Every piece the sentence does not name stays closed. |

## 17. Non-goals

A sentence in this section is a refusal. It is not a directive to build the missing piece. There is no capital token here that cuts a release, names a role, or starts a build. Reading the section, and finding it clear, does not accept a file. Acceptance is still one directive in the same sentence as the one file you name.

This kit does not name roles for you, write your product document, start a build, or carry another project's story, media, or code. A new project starts with those fields empty: the roster names, the vision fields, and the product document. It does not contain interchange extensions that the standard mentions and does not ship. Creating them locally would fork the standard, and a second copy of the kit would not have your fork. This manual is not a released starter. Reading it, and finding it useful, does not cut a release. A released starter is a later decision, with its own stamp.
