# Working spec draft.001

**State:** draft. Do not implement from this file. Do not implement from a pre-plan.
**Constitution:** [`constitution.draft.001.md`](constitution.draft.001.md)
**Purpose:**
**Intent:**

This file is a starting layout. The sections are the shape a module spec often uses. They are not required. Rename a heading, drop a section, or add a section when the batch needs a different shape. What this folder ships is a starting point. An empty value means you have not decided. Do not fill one to make the page look finished.

Read two finished specs for the structure and the syntax, not as a product to copy: [`../aa-sdd/AA-SDD/aa-sdd.spec.md`](../aa-sdd/AA-SDD/aa-sdd.spec.md) and [`../aa-sdd/aa-sdd-enir-spec.md`](../aa-sdd/aa-sdd-enir-spec.md). Do not edit the interchange standard.

A bold title is a key. The text under the key is the value. Write the batch here, as completely as you can, before a sketch. Enough of the problem has to be on the page that a later session sees one picture. Specify it the way you would specify an architecture. Then iterate from this file. A requirement that stays in the conversation is a requirement the next session does not have.

Stage 0 is empty until you say what already exists. No plan until you ask for a plan. The clerk files it. You do not manage the plan files.

## 1. What this batch is

One paragraph. What the module does, who it is for, and what done looks like. Done is a check a later reader can run without asking you.

## 2. What this batch is not

The neighboring jobs this file does not cover. A boundary written here keeps the next session from widening the build.

## 3. Stack and libraries

**Stack:**

**Libraries:**

Name the language and the runtime you have chosen. Name each library you have chosen. A version you have not chosen stays blank. A library named only in chat is not in the build.

## 4. Requirements

The batch. Write the requirements here before a sketch exists. Make the reasoning as complete as you can. A thin file that arrives one sentence per turn spends the session on rediscovery, and each addition can drift from the lines already accepted.

## 5. Pre-conditions

**Pre-conditions:**

What must already be true before this batch starts. If a pre-condition is false, the batch waits.

## 6. Post-conditions

**Post-conditions:**

What a later reader can check when the batch is finished, without asking you. A mood, a hope, and a launch date are not a post-condition.

## 7. Depends

**Depends:**

Other spec files this one requires. Write paths. Add `#section` when you mean one part of a file. A parent lists its children. A child may list its own. The clerk reads a file after the files it names. Do not paste a depended spec into this file. A cycle has no first file. Break the cycle in these lines before a pre-plan. A path that does not exist is a missing spec. Create that file and write its batch, or remove the line.

## 8. Files and configuration

Where the work lives. A path you have not chosen stays blank. A file this batch must not touch can be named here too, so a later session does not "help" by editing it.

## 9. Flows

The paths a person, or a later session, walks. One flow is enough to start. Add the ones the batch must not break. A flow that is only in chat is a flow the next session does not have.

## 10. Stage ledger

Stages already finished. Carry this table forward when you roll a new serial. Do not drop a row to make the page look short.

| ID | Delivered | Where it lives | Relevance |
|---|---|---|---|
| | | | |

## 11. Gaps

A gap that lives only in chat is a surprise for the next session. When you have one, give it an id of the form `G-nn`.

| ID | Gap | Impact | Lock |
|---|---|---|---|
| | | | |

## 12. Open questions

A question with no answer. Work that needs the answer waits. Do not plan it, and do not code it, just to look finished.

## 13. Decisions

Why a choice was made, in one line each, so a later session does not reopen it from chat. A choice you have not made stays off this list.

`[NEW IN ...]` marks a block you just added. Replace the dots with a short name of that block. The mark does not accept the file, and it does not open a pre-plan, a plan, or a build.

A `[MEMO]` block is how a later iteration names a change on a span. `[MEMORANDUM]` is the same block. `[END-MEMO]` closes it. It is not a filled product requirement.

## 14. Team brief

The clerk and any named seat report here. This section stays empty until there is a report. A report does not go inside a memorandum. A reply is a new memorandum. A new memorandum, and any new item in this file, carries `[NEW ON ...]` with the date of that turn in place of the dots. The mark is a search key. It is not a filled product requirement.

The corkboard is not a section of this file. A turn's log, and a note back to the team, go on [`../aa-sdd/holodeck/corkboard.md`](../aa-sdd/holodeck/corkboard.md). This draft stays the requirements.

The garage version is not a requirement in this file. It is the field `GARAGE` on the status panel. The invitation is not a filled roster cell. A story role for the sit-rep is written only when you ask, and only on the clerk seat.
