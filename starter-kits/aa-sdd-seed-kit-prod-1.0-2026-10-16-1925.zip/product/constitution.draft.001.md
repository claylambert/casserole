# Constitution - draft.001

**State:** draft. Do not implement from this file.
**Vision worksheet:** [`../VisionStatement.README.md`](../VisionStatement.README.md)

The owner writes three sentences. Three means three. The sentences state what the product is, small enough that the boundary is visible. They are not a plan, not a stack, and not a schedule. A paragraph that also carries those things is more than a seed, and it must be cut back to the product statement before it is treated as this draft. The file remains `draft.001` until you freeze it. Do not rename it in the first session to make the draft look finished.

1. 
2. 
3. 

Product laws P1 and P2 live in [`../global/project-laws.md`](../global/project-laws.md) once the owner locks them. Until then the stack is unspecified. Do not assume a language.
