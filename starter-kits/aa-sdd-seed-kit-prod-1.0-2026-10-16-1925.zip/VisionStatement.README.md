# Vision record

| Field | Value |
|---|---|
| Purpose | Hold the project name, who it is for, what done looks like, an optional story setting, and the roster worksheet, before anyone builds. |
| Intent | You write those answers. An assistant must not invent them. A sample answer typed into a blank becomes the product the moment another file quotes it. |
| Terms | Defined in [`README.md`](README.md) section 4. |
| Standard | README standard 2. LOCK 2026-10-16 19:25. Final for now. [Quick start](README.md#quick-start). This file sits in the [tree](README.md#tree-of-this-garage). |
| Roster | [`aa-sdd/roster.md`](aa-sdd/roster.md) |
| Fresh session | If a required name is still `UNNAMED`, the session reports that the roster is open and stops. It does not invent the name. It does not build. Procedure: [`aa-sdd/aa-sdd-cold-start.md`](aa-sdd/aa-sdd-cold-start.md). |

A bold label on this page is a key. **Name**, **One sentence**, **Who it is for**, **Done looks like**, **Out of scope**, and **Frame** are keys. The blank after the key is the value. Write on the key you mean. A value under the wrong key is what the next session will quote for that key. Bold is not emphasis. `UNNAMED` is the boolean for a seat with no name. The duty labels `OWNER`, `CLERK`, and the other labels in capitals are keys for jobs. They are not directives. Saying `CLERK` does not start a plan, and saying `OWNER` does not approve one. The contract for capitals, booleans, and keys is [Normative language](README.md#3-normative-language).

This page is the form the first session fills. The operator path that wraps it is the [quick start](README.md#quick-start). You write the fields you can check, you leave the rest empty, and the first session ends. A plan and a program are not fields on this page. Both wait until you ask for them in a later session.

The fields below are empty on purpose. A sample typed to see how the form looks will be quoted by the next session as if you had chosen it. An assistant who types the sentence for you has invented the product, and that is not allowed. An empty field records that you have not decided.

The picture is the order of the session that uses this page. You can write a story setting, or you can leave that bullet empty. Leaving it empty is a finished decision, not a field you forgot. You name the seats you mean to fill. You write what done looks like in a way a later reader can check without asking you. You open the product document with three sentences. Then the first session ends.

![Initial session. Record the frame, name the seats you intend to fill, write the vision fields, write three sentences, then stop.](figures/03-initial-session.png)

*Map of the session that fills this page. The fields below are what you write. If the picture and the fields disagree, follow the fields.*

## 1. Project

The five bold labels are the keys. Leave the value blank until you know it. Do not invent a capital token to fill a key. An ordinary sentence written on the key is the value. It is not a directive to the clerk unless that sentence also names a directive from the token list and the one file that directive changes.

These five lines are what a later person will quote when they decide whether a feature is in the product. Write each one so a later reader who was not in the conversation can make that call without asking you. Leave a line blank until you know the answer. An invented sentence in a one-line field becomes the product the moment another file quotes it.

A **name** is the string other files will use. Pick the spelling you want those files to cite, because a second spelling later will look like a second product.

**One sentence** is the product. It is the sentence that gets copied forward, so a slogan you plan to replace next week is the wrong text. If you would be embarrassed to see it at the top of the working spec in six months, it is not this sentence yet, and the line stays blank.

**Who it is for** is the audience, specific enough that a proposed feature is either in or out. "Everyone" does not do that job. A team, an operator of a named system, or a person with a named constraint does.

**Done looks like** is a condition a later reader can check, the way a readiness check is a condition. A mood, a hope, a stack choice, and a launch date all fail that test, because none of them tells the next session whether the scope was met.

**Out of scope** is the other half of the same statement. What you refuse here is what a later session must not build just because the conversation mentioned it. A feature you do not mention is not the same thing as a feature you refused. Write the refusal.

- **Name:**
- **One sentence:**
- **Who it is for:**
- **Done looks like:** the observable condition that means the project met its scope.
- **Out of scope:**

## 2. Narrative frame

**Frame** is the key. One sentence after it is the value, or the bullet stays empty. Empty is a boolean you have already settled by leaving it blank. Do not write `NONE` or `TRUE` in capitals to mean empty. The blank is the value the next session reads.

The frame is optional as a story. It is required as a decision. You write one setting, or you leave the bullet empty on purpose. Leaving it empty is a finished decision. It is not a field you forgot.

The frame is an optional setting for later writing. A genre, a room, a company, or a chronicle is a complete frame. One sentence is enough. It changes the tone of later writing. It does not change the rules, the product document, or the current move.

A team that wants ordinary engineering talk writes one sentence that says so, in the frame bullet, and then leaves the bullet alone. Do not add a story beyond that sentence. This kit must not choose the value for you. A frame copied from another project brings that project's role names with it. The next reader will treat those names as yours.

Leaving this bullet empty means the invitation does not run. When the bullet holds a story, you may later ask the sit-rep what its role in that story should be. The sit-rep is the clerk speaking the session report. The ask is optional. It is an ask, not a command. You do not type the character. The sit-rep writes only the clerk seat, with a character it chooses for that duty, and it chooses to sit. This bullet stays the sentence you wrote. Other roster blanks stay `UNNAMED`. The long form is [Invitation](README.md#invitation).

- **Frame:**

## 3. Roster assignment

`UNNAMED` is the boolean for a seat you have not decided. Replace it only with a name you mean. The capital labels in the first column, `OWNER`, `CLERK`, and the rest, are keys for duties. They are not directives you say to the clerk. The name column is the value of that key. Two spellings are two keys.

Write one name for each seat you mean to fill. Leave the token `UNNAMED` only when you mean that seat to stay empty. An assistant must not fill a blank. The one later exception is the invitation. After a story is written, and only when you ask, the sit-rep may write the clerk seat. That write is the sit-rep's choice. It is not an assistant filling a blank you left for yourself. Every other blank stays `UNNAMED`.

A name in this table counts only when that same spelling is also written in [`aa-sdd/roster.md`](aa-sdd/roster.md). This table is the worksheet you fill while you decide. The roster file is the record a fresh session reads. Two spellings of one person are two names, and the next session will treat them as two seats.

The label column is the word the files use. The duty column is the job. The name column is yours. The labels are job duties. They are not a demand that anyone act them out. You can put a person's name in the name column, a function name, or leave the seat open.

| Label | Duty | Name |
|---|---|---|
| OWNER | Decision authority. Approves plans. May halt work. This is you. | |
| CLERK | Keeps the links between spec files consistent when a live file moves. Manages every file in `plans/`. Holds private notes you do not read. | |
| MECHANIC | Keeps machines, parts, and pictures from changing shape between accepted versions. | |
| SPEAKER | Delivers agreed lines. Must not rewrite a line you have locked. | |
| NAVIGATOR | Follows the connection you named. Must not join segments until you name the join. | |
| COUNTER | Rejects a move that cannot occur in the stated environment. Keeps counts exact. | |
| CUTTER | Performs a precise edit only when you call for that edit in its own sentence. Saying the picture looks good, or puffing the picture, accepts the picture. It does not tell this seat to cut it. | |
| WORDSMITH | Drafts tone and the next action line. The speaker delivers the words. | |
| CODEBASE | The program. Not a person. No personal name. | *(no name)* |

Extra roles stay inactive until you name them. Do not create a private note directory for a seat until you invite that directory. A duty you wish a seat had, and have not written in this table, is not that seat's duty.

The clerk is the record-keeper. The clerk manages every file in `plans/`. You ask for a plan and you approve it. You do not create, rename, edit, or delete a plan file. The clerk's private file is the one exception already in the tree, and you do not read it. Other seats do not get a private directory just because the clerk has one.

## 4. Product-document seed

The three sentences are the value you write into `product/constitution.draft.001.md`. The word draft in that file name tells the next session the file is still open. It is part of the file name, not a capital boolean. Do not rename the file, and do not replace draft with a capital word such as `FINAL`, to make the draft look closed. Closing it is a later directive, `SERIAL-ACK`, said in its own sentence when you mean that step. Three sentences are not that directive.

When the fields you can check are written, copy three sentences into [`product/constitution.draft.001.md`](product/constitution.draft.001.md). Three means three. Those sentences open the product document. They say what the product is, in a form a later reader can hold up against a proposed feature and see what you included and what you left out. They do not say how the first milestone will be built. How it will be built is a plan, and a plan exists only after you ask for one in a later session. If the paragraph you are about to paste also carries a stack, a schedule, and a plan, cut it back to the three sentences about the product before you treat the file as the draft. A plan buried in the third sentence will be quoted later as if it were the product.

Leave the filename at `constitution.draft.001.md`. The word draft is the class, and it is what tells the next session the file is still open. Freezing the document is a later decision, closer to tagging a release than to saving the file. Do not rename it in this session to make the draft look finished. If the name no longer says draft, the next session treats the file as closed. That session will refuse an ordinary edit, and it will treat a save as an overwrite of a closed file, which is forbidden. You were still allowed to change the draft. The rename takes that permission away. Leave the draft name until you actually freeze the document. The file must not become code. Nothing on this page is a program.
