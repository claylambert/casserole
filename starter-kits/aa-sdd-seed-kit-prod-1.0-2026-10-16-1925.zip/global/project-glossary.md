# Glossary. AA-SDD seed kit prod 1.0

Framework words only. You add product words when the product exists. Do not import another project's nouns, role names, or story. A word in this table means what the row says. A friendlier paraphrase in a comment is a second meaning, and the next reader will not know which one the files obey.

The operator manual defines the same objects in the order a new session meets them. If a row here and a definition there disagree, repair the one that is explanation. The rules file wins over both. File labels such as kernel, manifest, and head are the strings you will see in the tree. They are not separate concepts from the entries below.

| Term | Meaning |
|---|---|
| **AA-SDD** | Architecture-Augmented Spec-Driven Development. Record the architecture in English specifications before implementation, and treat that file set as the source of truth. No other expansion is valid. |
| **EN-IR** | English-Native Intermediate Representation. English used as a locked interchange format. The default data protocol. Rule L24 also calls this "English as locked bytecode." That phrase is part of the locked name. It means the headed English is the interchange itself, not a tour around a hidden schema. Baseline: [../aa-sdd/aa-sdd-enir-spec.md](../aa-sdd/aa-sdd-enir-spec.md). Manual: [../aa-sdd/enir-suit-man.md](../aa-sdd/enir-suit-man.md). No other expansion is valid. |
| **PURE-EN-IR** | Data and intent carried in headed English. Not JSON, not XML, not YAML as the source of truth, and not embeddings. A boundary format the owner names for one turn is not this protocol. |
| **NORMAL-WORLD** | An encoding the owner names on that turn, such as JSON at an integration boundary, a spreadsheet, or a PDF extract. It applies to that turn. It does not replace the project protocol. |
| **Garage** | One project instance operated under AA-SDD. This folder, plus the work you add under its rules. Not a product name, not a runtime, and not a second specification store. |
| **Turn** | One request from the owner, together with the file edits that answer it. If the turn changed project state, it ends in one local commit and does not push. |
| **Kernel** | The status panel. Path: `global/grok-ai-kernel.toon`. It publishes the one current action, a headline, a decision log, and pointers. It does not outrank the index or the rules. |
| **Head** | The live file the index names for a module. In these documents the word means that file. It does not mean the git HEAD commit, the tip of a branch, or the commit you have checked out. |
| **OWNER** | The human who holds decision authority. Names the work, approves plans, and may halt. Does not create, rename, edit, or delete a plan file. Assistants must not speak for this seat. |
| **CLERK** | The record-keeper. Manages every file in plans/. Keeps links between specification files consistent, checks the filing receipt, and holds one private notes file. Does not override the owner. |
| **Chair** | The owner. Older sentences say the owner remains the chair. Assistants do not override the owner. |
| **Cast** | The roster. `ASK-CAST` means the roster names are still open. The startup list still prints the word cast. It means this roster, not a troupe and not a set of sample names. |
| **Cameo** | A role that is not a row on the roster. It stays inactive until the owner adds the row. The startup report still prints the word cameos in its closed-set line. |
| **Novel** | A narrative manuscript. Product text lives in the specification files. Do not paste a narrative into a procedure, and do not open narratives to discover the project. The startup report still prints the word novels. |
| **Drawer** | Older sentences use this word for the record-keeper's private notes, and sometimes for the folder that would hold a phase card. The only private-note file this kit ships is `aa-sdd/seats/clerk/CHOICE.md`. A directory with no card is not a live phase. |
| **Open chew** | In the witness-mark tail on rule L15, the open draft under revision, edited in place. It is not the decision word chew. The decision word chew is notes that must not enter `plans/` and must not become code. |
| **Plate** | In a picture pipeline, one filed still, also called a storyboard frame. An infographic plate is the L30 PNG. The five-field receipt applies to a picture-pipeline frame, a spoken line, or a product build whose phase is that build. It does not apply to an infographic or to a specification sentence. |
| **Hull** | The accepted shape of a machine, a part, or a picture. It does not change between accepted versions. |
| **Stitch** | Joining picture segments into one piece. Only when the owner names that join. Adjacent files do not join themselves. |
| **Sit-rep** | The short report a fresh session prints after the read list, and before it stops. The report is the proof the list was followed. It is not a license to keep working. |
| **SEED KIT** | This folder. A fresh project frame. Prod 1.0, cut 2026-10-16 19:25. GARAGE 1.0. |
| **SERIAL-ACK** | The word that moves one named serial exactly one version step. Draft, then release candidate, then final. Said on a draft, it writes the release candidate as a new file. It does not write the final, and it does not skip the release candidate. The letter Y is not this word. |
| **COLD-START** | The spoken token, or `[COLD-START]`. Run [`../aa-sdd/aa-sdd-cold-start.md`](../aa-sdd/aa-sdd-cold-start.md) from the top. Print the sit-rep. Stop. Do not build. |
| **RESUME CARD** | The on-disk phase. Wins over the headline `NOW.WORK`. Shape: [`../aa-sdd/aa-sdd-resume-card.md`](../aa-sdd/aa-sdd-resume-card.md). This kit ships none. Do not invent one at startup. |
| **RECEIPT** | The five fields `MASTER`, `MATCH`, `CHANGE`, `FILED`, and `ARCH`. A failed match is not filed. |
| **SERIAL** | `draft.NNN`, then `release-candidate.NNN`, then `finalize`. Never overwrite a closed serial. A wording change in an open draft does not mint a new number. |
| **Pre-plan** | The sketch stage. A direction you can reject. Not an implementation source. Filename pattern `*-pre-plan-stage-N.001.md`. The operator manual and the build-sequence figure call this stage a sketch. |
| **`[PUFF]`** | Owner approval of the named object. Treat that object as locked unless a later serial reverses it. A puff does not, by itself, change the phase, advance a serial, or authorize implementation. |
| **`[LOCK]`** | Frozen. Implement or specify exactly this. |
| **`[CHEW]`** | Notes only. Not a plan. Not code. Not a freeze. Must not be copied into `plans/`. |
| **`[OPEN]`** | The question has no answer yet. Do not plan it and do not code it. |
| **`[SCRATCHED]`** | Withdrawn. Remove it from the live spec. |
| **`[PRESERVE-ALL]`** | Accepted behavior stays. Spoken lines under this mark stay byte-identical. Add description around those lines. Do not paraphrase them. |
| **`[AD-HOC]`** | A one-off bug or feature ledger row, written in the same turn. A bare token means a bug. |
| **`[CLERK-SWEEP]`** | An integrity pass across the file graph. Not startup. Not a rewrite of the specifications into another form. |
| **`[CREATE-SEED-KIT]`** | Export a fresh kit. It does not start the project that runs the export. |
| **`[PRIME-DIRECTIVE]`** | A law above every other rule and above the product document. Rule L23, and the default row of [`prime-directives.md`](prime-directives.md). A sentence that names no row means the legal row. Other rows live in that table. Legal work only. No forced entry. No private file that was not offered. |
| **`[VIDEO-BAY]`** | The picture pipeline: narrative, then EN-IR, then storyboard, then stills, then clips. Joined output only when the owner names the join. |
| **L27** | The phase card is the phase a fresh session returns to. The card wins over `NOW.WORK`. `NOW.ACTION` is one line. `NOW.LOG` is not a move. |
| **L28** | Each seat owns one continuity. The record-keeper checks the receipt before a picture-pipeline frame, a spoken line, or a phase build is filed. |
| **L29** | A preference the record-keeper chooses to keep lives only in the record-keeper's notes. The startup report acknowledges the duty with `L29: ACK` and does not quote the file. |
| **Spec file** | The EN-IR path for a project, code, or video specification. Serial Markdown. When the owner asks to encode raw prose, the session compiles the headings and the owner's prose stays quoted. |
| **Data packet** | The EN-IR path for transfer or persistence. Every structure and every value survives. Intent is present only when the owner requests it that turn. |
| **L30** | An infographic is a photographic PNG, 16:9, filed at 7680 by 4320. Words, numbers, arrows, and labels are set in type on the raster. |
| **L31** | A retake copies the outgoing still into that directory's `archaeology/` before the live name is replaced. The live name stays. A first filing has no predecessor. |
| **L32** | A directory named `tmp` is a scratch dump. Not a live file. Not indexed. Not staged unless the owner names that path that turn. |
| **L33** | When the owner adds a rule, check it against the whole set and against every conflict note in the same turn. A joint gets the next witness mark. No joint means no new mark. |
| **Witness mark** | A conflict note across two rules that can both answer one request, where the answers differ. Not a rule. Not an L-number. `aa-sdd/aa-sdd-witness-marks.md`. Startup does not open it. |
| **Spec graph** | Specification files are the nodes. Links are the edges. The record-keeper walks the edges the way a build walks imports. Law L17 calls this graph a classpath for that reason. The index wins over the status panel. The rules win over the manual. A conflict note does not win over the rules it joins. |
