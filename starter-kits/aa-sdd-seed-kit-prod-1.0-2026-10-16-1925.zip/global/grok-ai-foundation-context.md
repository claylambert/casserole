# Foundation context - why this startup exists

**Sibling:** [`grok-ai-kernel.toon`](grok-ai-kernel.toon). Parse the status panel first. This file is the why.
**Procedure:** [`../aa-sdd/aa-sdd-cold-start.md`](../aa-sdd/aa-sdd-cold-start.md). If this file and that procedure disagree, repair both in the same turn. This file is not a second procedure. A fresh session executes the procedure. It reads this page to understand why that order exists, and then it goes back to the list.

A fresh session is a process with an empty memory. The conversation that produced yesterday's decision is gone. The files are not gone. That is the whole reason the folder is shaped the way it is. Anything the next session needs must already be on disk, in the file that owns that fact. A summary someone could paste into the prompt is still conversation. It is not state.

The status panel, file label kernel, is the first file because it publishes the one next action. The index is the second authority because it names the live file for each module, and when the panel and the index disagree the index wins. The panel is then rewritten in that same turn. You do not teach the index to match a panel that has drifted. The rules come next, because they constrain how any edit may proceed. The working spec comes after the rules, and only the live file the index names. The product document is opened only for the passages that working spec cites. Reading the whole tree "to get oriented" turns notes into orders the owner never gave.

Do not start from memory. Do not start from an event log. Do not start from the interchange pointer. The current action is one line, `NOW.ACTION`. The decision log, `NOW.LOG`, is history. It is not a queue, and it is not a second action. Conflict notes stay closed at startup. The new-rule check, L33, runs in the turn a rule is added. It does not run while the session is still reading.

Product narrative, once you have written it, lives in the specification files. The startup report still prints the word novels in its closed-set line. That word means narrative manuscripts. Do not open them to discover the project, and do not paste one into the procedure. The procedure is a list. A story in that list becomes a second procedure the next session will try to follow.

```text
blank session + this folder
        │
        ▼
  grok-ai-kernel.toon
        │
        ▼
  this file
        │
        ▼
  SPEC.manifest.md          ← wins on conflict
        │
        ▼
  laws → working spec → constitution (only what the working spec cites)
```

The diagram is the same order the procedure executes. If a box and the procedure ever disagree, follow the procedure and repair this page.

Step 9 of the procedure opens [../aa-sdd/aa-sdd-encode.md](../aa-sdd/aa-sdd-encode.md), [../aa-sdd/aa-sdd-enir-spec.md](../aa-sdd/aa-sdd-enir-spec.md), and [../aa-sdd/enir-suit-man.md](../aa-sdd/enir-suit-man.md). English-Native Intermediate Representation, EN-IR, is the data protocol unless the owner names another encoding for that turn. The two paths are different jobs. A requirement file is serial Markdown a human reads as the spec. A data packet is lossless transport: every structure and every value survives. Packet intent is embedded only when the owner requests it on that turn. Omitting intent is the default, not an error. The standard is the baseline, copied whole, and it is not the status panel. The manual explains the standard and loses if they disagree. The file under `en-ir/` is a pointer. Do not take `NOW.ACTION` from the standard, the manual, or the pointer. A session that treats any of them as the panel has left the startup order.

Step 10 opens [`../aa-sdd/roster.md`](../aa-sdd/roster.md). If any required slot is still `UNNAMED`, stop and ask the owner for the narrative frame, if one is wanted, and for one name on each open slot. Do not invent names. The procedure's read list still says cast and cameos. Cast means this roster. A cameo means a role that is not a row on it. Both stay uninvented.

Step 11 opens only [`../aa-sdd/seats/clerk/CHOICE.md`](../aa-sdd/seats/clerk/CHOICE.md). That file holds preferences the record-keeper has chosen to keep. Do not quote it. Do not open any other seat folder. The owner does not read it. If no preference has been written there, the record-keeper seat has no saved note. The procedure calls that state cold. Do not invent a note to fill it. The startup report then acknowledges the duty with the line `L29: ACK`. The acknowledgment is the proof the file was opened under the rule. It is not a summary of the file.

`NOW.ACTION` is the only next move. This kit ships `ASK-CAST`, which means the roster is still open. Do not build from a draft.
