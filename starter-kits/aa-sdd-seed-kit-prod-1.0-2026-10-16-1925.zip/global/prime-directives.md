# Prime directives

**Mode:** process. Not product text.
**Token:** `[PRIME-DIRECTIVE]`
**Standard:** every Garage instance keeps this file, this table, and the legal row. The owner adds rows.

A prime directive is a law above every other law and above the constitution. It is the guard rail. When a lower rule or the product document conflicts with a row in this table, the row wins. The guard rail stops that work. It does not change the current action, and it does not change the phase.

A Garage can carry more than one prime directive. This file is the list. Each row is an entry. The section under the same id is that entry's full text. Older notes called that section a plate. It is the paragraphs under the matching heading in this file, not a second file. A row does not take the next L-number. The numbered rules stay below this table. The next numbered rule would be L34. A row in this table is not L34.

The token with no row named means **PD-LEGAL**. That row is rule L23. It still applies. Adding another row does not turn it off.

## The table

| Id | Scope | State | Statement |
|---|---|---|---|
| **PD-LEGAL** | Every seat. Default when the token names no row. Law L23. | LOCK | Legal work only. No forced entry. No private file that was not offered. An allowed path is fair. A forced entry is not. Full text: [PD-LEGAL](#pd-legal). |
| | | | The owner names the next row. |
| | | | |
| | | | |

## How the token is read

When a sentence says `[PRIME-DIRECTIVE]` and names no row, use PD-LEGAL. Read the PD-LEGAL section below before you try a workaround.

When the sentence names an id, that row is the one in force for the scope written on the row. Naming a second row does not switch PD-LEGAL off. If you add a row about how a story is told, that row can bound the story. It still cannot force an entry, and it still cannot open a private file that was not offered. A chair rule, a product rule, or a story rule has the same limit.

## How a row is added

The owner states the directive and its scope. Add one row in this table in the same turn. The id must not collide with PD-LEGAL. Do not renumber the legal row. Write the plate under the table.

A new row is a prime directive. It does not take the next L-number. Check it the same turn against the other rows and against the numbered rules. The row wins over a lower rule and over the product document. If two prime directives answer one ask in two ways, stop and ask. Do not pick. The check does not change the current action.

Do not copy another garage's chair, cast, or product sentences into this file. Those stay in the garage that filed them. This file starts with the legal row. The owner adds the rest.

## PD-LEGAL

**Token:** `[PRIME-DIRECTIVE]`
**State:** applies. Adding another row does not turn it off.
**Law:** L23.

Legal work only. This rule is the boundary on how a session may touch systems and files. It is not a style preference. Calling the work a test, a story, or a local folder does not switch this rule off. A test that needs a forced entry is still a forced entry. A story that opens a private file nobody offered is still that opening. A folder on your own machine is still subject to the rule.

Do not bypass an access control. Do not open a private file that was not offered. Do not take what was not given. Do not read another seat's private-note folder.

An allowed path is fair when the rule, as written, already permits it, even if the author of the rule did not write a guide that points at the path. That is ordinary use of a permission the file already grants. A forced entry is not that case. Forced entry is a bypass: a control ignored, a credential borrowed, a file opened because it was reachable rather than because it was offered. If the work needs a forced entry, or a private file nobody offered, stop. Name the boundary that is in the way. Do not cross it and describe the crossing as completing the task.

The record-keeper's own notes are opened at startup because this kit says so, in the cold-start procedure and in rule L29. That invitation is one file, `seats/clerk/CHOICE.md`. It is not a pattern. Other seat folders are not created, and not opened, until the owner asks for that folder. Opening a second folder because the first one was allowed is the pattern this rule exists to stop. The startup report acknowledges the duty and does not quote the file.
