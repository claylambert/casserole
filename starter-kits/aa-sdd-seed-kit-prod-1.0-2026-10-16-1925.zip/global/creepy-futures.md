# Parked ideas - do not implement

Park an idea here so it does not slip into a plan. A row is a refusal. It is not approval, and it is not a backlog item waiting for a quiet turn. The owner opens a row by naming it in a working spec. Until that naming, the idea stays here and the build does not touch it.

A fresh session reads this list so it knows what is refused. Reading the list is not permission to build the list.

| ID | Idea | Why it waits | Opened by |
|---|---|---|---|
| | | | |

This kit ships the table empty. An empty table is correct. Do not seed it with an example idea. An example becomes a refusal the next session will honor, and you will have refused a product you never had.
