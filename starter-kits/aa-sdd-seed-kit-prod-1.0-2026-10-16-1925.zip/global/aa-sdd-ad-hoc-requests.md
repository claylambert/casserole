# Ad-hoc requests

**Law:** L21. Not a stage. Not a second requirement catalog.

An ad-hoc request is a one-off defect or a one-off capability. It does not open a stage, and it does not become a second list of requirements beside the working spec. The row is written in the same turn as the change. A bare `[AD-HOC]`, with no feature mark, is a bug. Calling it a discussion instead of a row drops the record, and the next fresh session will not know the defect was named.

The index files at the repository root of this kit stay short on purpose. The full note for one item lives under `bugs/{module}/` or `features/{module}/`. The index row points at that note. On a fresh session, read the last twenty rows of each index. Do not ingest the whole tree of notes. This kit ships both indexes empty, which is the correct starting state.

| Owner says | Write | Code |
|---|---|---|
| `[AD-HOC]` or `[AD-HOC] [BUG]` | `bugs/{module}/BF-NNN.*.md` and one row in [`../bugs/bugs-fixed.md`](../bugs/bugs-fixed.md) | Same turn, if a fix was asked |
| `[AD-HOC] [FEATURE]` | `features/{module}/FEAT-NNN.*.md` and one row in [`../features/features-added.md`](../features/features-added.md) | Same turn, if a build was asked |

Index ids are not `@aa-sdd` keys. The `@aa-sdd` comment is the bridge on new code, from rule L20. A ledger id such as `BF-001` is a row in this index. Do not treat the two namespaces as one.
