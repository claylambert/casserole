# Spec manifest. Seed kit prod 1.0

**Cut:** 2026-10-16 19:25
**Status:** Prod 1.0. Cut 2026-10-16 19:25. GARAGE 1.0. Not a boot.
**Rule:** if the kernel and this file disagree on a head, this file wins. Rewrite the kernel the same turn.

Traversal follows the module name, not the row order.

## System

| Module | Head | State |
|---|---|---|
| Kernel | [`global/grok-ai-kernel.toon`](global/grok-ai-kernel.toon) | GARAGE: 1.0. NOW. ACTION is ASK-CAST. LOG is not a move. No resume card. |
| Boot | [`global/grok-ai-foundation-context.md`](global/grok-ai-foundation-context.md) | Why. Not a second procedure. |
| Laws | [`global/project-laws.md`](global/project-laws.md) | L1, L10, L14-L33. Product laws blank. |
| Prime directives | [`global/prime-directives.md`](global/prime-directives.md) | The list is a table. The legal row is the default. The owner adds rows. Not a new L-number. |
| Witness marks | [`aa-sdd/aa-sdd-witness-marks.md`](aa-sdd/aa-sdd-witness-marks.md) | Scribes. Not an L-number. Not opened on boot. |
| Glossary | [`global/project-glossary.md`](global/project-glossary.md) | Framework words. |
| Syntax | [`global/project-conceptual-syntax-reference.md`](global/project-conceptual-syntax-reference.md) | Tokens. |
| Cold start | [`aa-sdd/aa-sdd-cold-start.md`](aa-sdd/aa-sdd-cold-start.md) | Procedure. |
| Roster | [`aa-sdd/roster.md`](aa-sdd/roster.md) | Slots. Names UNNAMED until the owner fills them. |
| Seat | [`aa-sdd/aa-sdd-seat.md`](aa-sdd/aa-sdd-seat.md) | L29. Only the record-keeper's private notes. Opened, not quoted. |
| EN-IR baseline | [aa-sdd/aa-sdd-enir-spec.md](aa-sdd/aa-sdd-enir-spec.md) | EN-IR/1.0. Copied whole. Not the panel. |
| EN-IR manual | [aa-sdd/enir-suit-man.md](aa-sdd/enir-suit-man.md) | Explains the baseline. Does not win over it. |
| EN-IR pointer | [en-ir/EN-IR.handshake.md](en-ir/EN-IR.handshake.md) | Not the law. |

## Product heads

| Module | Head | State |
|---|---|---|
| Vision | [`VisionStatement.README.md`](VisionStatement.README.md) | Blank. Owner writes it. |
| Constitution | [`product/constitution.draft.001.md`](product/constitution.draft.001.md) | draft.001. Do not implement from it. |
| Working spec | [`product/working-spec.draft.001.md`](product/working-spec.draft.001.md) | draft.001. Stage 0 empty. |

## Closed on boot

Narrative manuscripts, event logs, other products' trees, seat folders other than the record-keeper's, and roles that are not on the roster. The record-keeper's private notes are opened and not quoted. The startup report still prints this closed set as: novels, event log, other products, other seat folders, cameos.
