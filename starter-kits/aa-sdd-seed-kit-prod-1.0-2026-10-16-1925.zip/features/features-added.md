# Features added - append-only index

**Process:** [`../global/aa-sdd-ad-hoc-requests.md`](../global/aa-sdd-ad-hoc-requests.md). **L21.**

This index is the recent edge of one-off capability work. A fresh session reads the last twenty rows. It does not ingest every note under `features/`. This kit starts empty. An empty table is correct. Do not seed it with a sample feature.

Append a row in the same turn as the change, and only when the owner marked the request as a feature. A bare `[AD-HOC]` is a bug and does not write here. The full note for one item lives at `features/{module}/FEAT-NNN.*.md`. The row points at that note. Index ids are not `@aa-sdd` keys.

| ID | When | Stage | Module | Reporter | Summary | Spec file |
|---|---|---|---|---|---|---|
