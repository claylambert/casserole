# Bugs fixed - append-only index

**Process:** [`../global/aa-sdd-ad-hoc-requests.md`](../global/aa-sdd-ad-hoc-requests.md). **L21.**

This index is the recent edge of defect work. A fresh session reads the last twenty rows before it invents a cause. It does not ingest every note under `bugs/`. This kit starts empty. An empty table is correct. Do not seed it with a sample defect.

Append a row in the same turn as the fix. A bare `[AD-HOC]` is a bug and writes here. The full note for one item lives at `bugs/{module}/BF-NNN.*.md`. The row points at that note. Index ids are not `@aa-sdd` keys.

| ID | When | Stage | Module | Reporter | Symptom | Cause | Fix | Spec? | Keys | Spec file |
|---|---|---|---|---|---|---|---|---|---|---|
